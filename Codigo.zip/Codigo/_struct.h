#pragma once
#define MAX_ITEM_INFO			12
#define MAX_BONES				200
#define MAX_MESH				50
#define MAX_VERTICES			15000
#define SERVER_LIST_SCENE		0
#define	NON_SCENE				0
#define WEBZEN_SCENE			1
#define LOG_IN_SCENE			2
#define LOADING_SCENE			3
#define CHARACTER_SCENE			4
#define MAIN_SCENE				5
#define RENDER_COLOR			0x00000001
#define RENDER_TEXTURE			0x00000002
#define RENDER_CHROME			0x00000004
#define RENDER_METAL			0x00000008
#define RENDER_LIGHTMAP			0x00000010
#define RENDER_SHADOWMAP		0x00000020

#define RENDER_BRIGHT			0x00000040
#define RENDER_DARK				0x00000080

#define RENDER_EXTRA			0x00000100
#define RENDER_CHROME2			0x00000200
#define RENDER_WAVE				0x00000400
#define RENDER_CHROME3			0x00000800
#define RENDER_CHROME4			0x00001000
#define RENDER_NODEPTH			0x00002000
#define RENDER_CHROME5			0x00004000
#define RENDER_OIL				0x00008000
#define RENDER_CHROME6			0x00010000
#define RENDER_CHROME7			0x00020000
#define RENDER_DOPPELGANGER		0x00040000

#define RENDER_CHROME8			0x00080000

#define MODEL_BODY_NUM			24
#define MODEL_BODY_HELM			9389 //-- 9389
#define MODEL_BODY_ARMOR		MODEL_BODY_HELM+MODEL_BODY_NUM //-- 9413
#define MODEL_BODY_PANTS		MODEL_BODY_ARMOR+MODEL_BODY_NUM //-- 9437
#define MODEL_BODY_GLOVES		MODEL_BODY_PANTS+MODEL_BODY_NUM //-- 9461
#define MODEL_BODY_BOOTS		MODEL_BODY_GLOVES+MODEL_BODY_NUM //-- 9485
#define MODEL_PLAYER			1163
#define MODEL_HELPER			7827
#define EQUIP_BODY_HELM			268 //-- 9389
#define EQUIP_BODY_ARMOR		304 //-- 9389
#define EQUIP_BODY_PANTS		340 //-- 9389
#define EQUIP_BODY_GLOVES		376 //-- 9389
#define EQUIP_BODY_BOOTS		412 //-- 9389

#define RENDER_WAVE_EXT			0x10000000
#define RENDER_BYSCRIPT			0x80000000
#define SOCKET_EMPTY			0xFF
#define RNDEXT_WAVE				1
#define RNDEXT_OIL				2
#define RNDEXT_RISE				4
#define MAX_MONSTER_SOUND		10//5
#define MODEL_ITEM				1171
#define MAX_ITEM_INDEX			512
#define ITEM_SWORD(x)			(0 + x)   //pal,etc
#define ITEM_AXE(x)				(1 * MAX_ITEM_INDEX + x)  //ran,dru
#define ITEM_MACE(x)			(2 * MAX_ITEM_INDEX + x)  //ran,nec
#define ITEM_SPEAR(x)			(3 * MAX_ITEM_INDEX + x)  //ama
#define ITEM_BOW(x)				(4 * MAX_ITEM_INDEX + x)  //ama
#define ITEM_STAFF(x)			(5 * MAX_ITEM_INDEX + x)  //soc
#define ITEM_SHIELD(x)			(6 * MAX_ITEM_INDEX + x) 
#define ITEM_HELM(x)			(7 * MAX_ITEM_INDEX + x)
#define ITEM_ARMOR(x)			(8 * MAX_ITEM_INDEX + x)
#define ITEM_PANTS(x)			(9 * MAX_ITEM_INDEX + x)
#define ITEM_GLOVES(x)			(10 * MAX_ITEM_INDEX + x)
#define ITEM_BOOTS(x)			(11 * MAX_ITEM_INDEX + x)
#define ITEM_WING(x)			(12 * MAX_ITEM_INDEX + x)
#define ITEM_HELPER(x)			(13 * MAX_ITEM_INDEX + x)
#define ITEM_POTION(x)			(14 * MAX_ITEM_INDEX + x)
#define ITEM_ETC(x)				(15 * MAX_ITEM_INDEX + x)
#define MAX_SOCKETS				5
#define MAX_ITEM_SPECIAL		8
#define MAX_CLASS				11
#define MAX_OLD_CLASS			7
#define MAX_RESISTANCE			7
#define BITMAP_LIGHT_RED		32431
#define BODYPART_HEAD			0
#define BODYPART_HELM			1
#define BODYPART_ARMOR			2
#define BODYPART_PANTS			3
#define BODYPART_GLOVES			4
#define BODYPART_BOOTS			5
#define MAX_BODYPART			6
#define MAX_PATH_FIND			15

enum
{
	CHARACTER_NONE = 0,
	CHARACTER_RENDER_OBJ,
	CHARACTER_ANIMATION
};

enum
{
	RENDER_TYPE_NONE = 0,
	RENDER_TYPE_ALPHA_BLEND,
	RENDER_TYPE_ALPHA_TEST,
	RENDER_TYPE_ALPHA_BLEND_MINUS,
	RENDER_TYPE_ALPHA_BLEND_OTHER,
};

enum CLASS_TYPE_4T
{
	//-- 1�� CLASS
	Dark_Wizard = 0,
	Dark_Knight,
	Fairy_Elf,
	Magic_Gladiator,
	Dark_Lord,
	Summoner1,
	Rage_Fighter,
	Grow_Lancer,
	Runer_Wizzard,
	Slayer,
	Gun_Crusher,
	//-- 2DA CLASS
	Soul_Master,
	Blade_Knight,
	Muse_Elf,
	Bloody_Summoner,
	Rune_Spell,
	Royal_Slayer,
	Gun_Breaker,
	//-- 3RA CLASS
	Grand_Master,
	Blade_Master,
	High_Elf,
	Duel_Master,
	Lord_Emperor,
	Dimension_Master,
	Fist_Master,
	Mirage_Lancer,
	Rune_Grand,
	Master_Slayer,
	Master_Gun_Breaker,
	//-- 4TA CLASS
	Soul_Wizard,
	Dragon_Knight,
	Noble_Elves,
	Magic_Knight,
	Empire_Road,
	Dimension_Summoner,
	Fist_Blazer,
	Shining_Lancer,
	Majestic_Rune,
	Slaughterer,
	Heist_Gun_Crasher,
};


enum TOOLTIP_TYPE
{
	UNKNOWN_TOOLTIP_TYPE = 0,
	TOOLTIP_TYPE_INVENTORY,
	TOOLTIP_TYPE_REPAIR,
	TOOLTIP_TYPE_NPC_SHOP,
	TOOLTIP_TYPE_MY_SHOP,
	TOOLTIP_TYPE_PURCHASE_SHOP,
};
enum EVENT_STATE
{
	EVENT_NONE = 0,
	EVENT_HOVER,
	EVENT_PICKING,
};

typedef float vec_t;
typedef vec_t vec2_t[2];
typedef vec_t vec3_t[3];
typedef vec_t vec4_t[4];
typedef vec_t vec34_t[3][4];

#define Vector(a,b,c,d) {(d)[0]=a;(d)[1]=b;(d)[2]=c;}
#define VectorAvg(a) ( ( (a)[0] + (a)[1] + (a)[2] ) / 3 )
#define VectorSubtract(a,b,c) {(c)[0]=(a)[0]-(b)[0];(c)[1]=(a)[1]-(b)[1];(c)[2]=(a)[2]-(b)[2];}
#define VectorAdd(a,b,c) {(c)[0]=(a)[0]+(b)[0];(c)[1]=(a)[1]+(b)[1];(c)[2]=(a)[2]+(b)[2];}
#define VectorCopy(a,b) {(b)[0]=(a)[0];(b)[1]=(a)[1];(b)[2]=(a)[2];}
#define QuaternionCopy(a,b) {(b)[0]=(a)[0];(b)[1]=(a)[1];(b)[2]=(a)[2];(b)[3]=(a)[3];}
#define VectorScale(a,b,c) {(c)[0]=(b)*(a)[0];(c)[1]=(b)*(a)[1];(c)[2]=(b)*(a)[2];}
#define DotProduct(x,y) ((x)[0]*(y)[0]+(x)[1]*(y)[1]+(x)[2]*(y)[2])
#define VectorFill(a,b) { (a)[0]=(b); (a)[1]=(b); (a)[2]=(b);}

typedef struct
{
	vec3_t StartPos;
	vec3_t XAxis;
	vec3_t YAxis;
	vec3_t ZAxis;
} OBB_t_ok;

typedef struct OBJECT_//-> InDev (size: 648)
{
	char			Ext[4];
	/*+4*/		bool			Live;
	/*+5*/		bool			bBillBoard;
	/*+6*/		bool			m_bCollisionCheck;
	/*+7*/		bool			m_bRenderShadow;
	/*+8*/		bool			EnableShadow;
	/*+9*/		bool			LightEnable;
	/*+10*/		bool			m_bActionStart;
	/*+11*/		bool			m_bRenderAfterCharacter;
	/*+12*/		bool			Visible;
	/*+13*/		bool			AlphaEnable;
	/*+14*/		bool			EnableBoneMatrix;
	/*+15*/		bool			ContrastEnable;
	/*+16*/		bool			ChromeEnable;
	/*+17*/		unsigned char	AI;
	/*+18*/		unsigned short	CurrentAction;
	/*+20*/		unsigned short	PriorAction;
	/*+22*/		BYTE			ExtState;
	/*+23*/		BYTE			Teleport;
	/*+24*/		BYTE			Kind;
	/*+26*/		WORD			Skill;
	/*+28*/		BYTE			m_byNumCloth;
	/*+29*/		BYTE			m_byHurtByOneToOne;
	/*+30*/		BYTE			WeaponLevel;
	/*+31*/		BYTE			DamageTime;
	/*+32*/		BYTE			m_byBuildTime;
	/*+33*/		BYTE			m_bySkillCount;
	/*+34*/		BYTE			m_bySkillSerialNum;
	/*+35*/		BYTE			Block;
	/*+36*/		void* m_pCloth;
	/*+40*/		short			ScreenX;
	/*+42*/		short			ScreenY;
	/*+44*/		short			PKKey;
	/*+46*/		short			Weapon;
	/*+48*/		int				Type;
	/*+52*/		int				SubType;
	/*+56*/		int				m_iAnimation;
	/*+60*/		int				HiddenMesh;
	/*+64*/		int				LifeTime;
	/*+68*/		int				BlendMesh;
	/*+72*/		int				AttackPoint[2];
	/*+80*/		int				RenderType;
	/*+84*/		int				InitialSceneFrame;
	/*+88*/		int				LinkBone;
	/*+92*/		DWORD			m_dwTime;
	/*+96*/		float			Scale;
	/*+100*/	float			BlendMeshLight;
	/*+104*/	float			BlendMeshTexCoordU;
	/*+108*/	float			BlendMeshTexCoordV;
	/*+112*/	float			Timer;
	/*+116*/	float			m_fEdgeScale;
	/*+120*/	float			Velocity;
	/*+124*/	float			CollisionRange;
	/*+128*/	float			ShadowScale;
	/*+132*/	float			Gravity;
	/*+136*/	float			Distance;
	/*+140*/	float			AnimationFrame;
	/*+144*/	float			PriorAnimationFrame;
	/*+148*/	float			AlphaTarget;
	/*+152*/	float			Alpha;
	/*+156*/	vec3_t			Light;
	/*+168*/	vec3_t			Direction;
	/*+180*/	vec3_t			m_vPosSword;
	/*+192*/	vec3_t			StartPosition;
	/*+204*/	vec3_t			BoundingBoxMin;
	/*+216*/	vec3_t			BoundingBoxMax;
	/*+228*/	vec3_t			m_vDownAngle;
	/*+240*/	vec3_t			m_vDeadPosition;
	/*+252*/	vec3_t			Position;
	/*+264*/	vec3_t			Angle;
	/*+276*/	vec3_t			HeadAngle;
	/*+288*/	vec3_t			HeadTargetAngle;
	/*+300*/	vec3_t			EyeLeft;
	/*+312*/	vec3_t			EyeRight;
	/*+324*/	vec3_t			EyeLeft2;
	/*+336*/	vec3_t			EyeRight2;
	/*+348*/	vec3_t			EyeLeft3;
	/*+360*/	vec3_t			EyeRight3;
	/*+372*/	vec34_t			Matrix;
	/*+420*/	vec34_t* BoneTrans;
	/*+424*/	OBB_t_ok		OBB;
	/*+472*/	OBJECT_* Owner;
	/*+476*/	OBJECT_* Prior;
	/*+480*/	OBJECT_* Next;
	/*+484*/	BYTE			m_BuffMap[36];
	/*+520*/	short int		m_sTargetIndex;
	/*+524*/	BOOL			m_bpcroom;
	/*+540*/	vec3_t			m_v3PrePos1;
	/*+552*/	vec3_t			m_v3PrePos2;
	/*+564*/	vec3_t			m_v3PrePos3;
	/*+576*/	BYTE			m_Interpolates[84];
} OBJECT;

typedef struct _PART_t //-> InDev (size: 36)
{
	/*+0*/	short Type;
	/*+2*/	BYTE  Level;
	/*+3*/	BYTE  Option1;
	/*+4*/	BYTE  ExtOption;
	/*+5*/	BYTE  LinkBone;
	/*+6*/	BYTE  CurrentAction;
	/*+8*/	unsigned short PriorAction;
	/*+12*/	float AnimationFrame;
	/*+16*/	float PriorAnimationFrame;
	/*+20*/	float PlaySpeed;
	/*+24*/	BYTE m_byNumCloth;
	/*+28*/	void* m_pCloth[2];

	_PART_t()
	{
		Type = 0;
		Level = 0;
		Option1 = 0;
		ExtOption = 0;
		LinkBone = 0;
		CurrentAction = 0;
		PriorAction = 0;
		AnimationFrame = 0;
		PriorAnimationFrame = 0;
		PlaySpeed = 0;
		m_byNumCloth = 0;
		m_pCloth[0] = NULL;
		m_pCloth[1] = NULL;
	}
} PART_t;

typedef struct _PATH_t //-> InDev (size: 44)
{
	/*+00*/		unsigned char CurrentPath;
	/*+01*/		unsigned char CurrentPathFloat;
	/*+02*/		unsigned char PathNum;
	/*+04*/		unsigned char PathX[MAX_PATH_FIND];
	/*+19*/		unsigned char PathY[MAX_PATH_FIND];
	/*+34*/		bool          Success;
	/*+35*/		bool          Error;
	/*+36*/		unsigned char x, y;
	/*+38*/		unsigned char Direction;
	/*+39*/		unsigned char Run;
	/*+40*/		int           Count;

	_PATH_t()
	{
		CurrentPath = 0;
		CurrentPathFloat = 0;
		PathNum = 0;

		for (int i = 0; i < MAX_PATH_FIND; ++i)
		{
			PathX[i] = 0;
			PathY[i] = 0;
		}

		Success = 0;
		Error = 0;
		x = 0, y = 0;
		Direction = 0;
		Run = 0;
		Count = 0;
	}

} PATH_t;

typedef struct //-> InDev (size: 24)
{
	/*+00*/		DWORD	m_dwPetType;
	/*+04*/		DWORD	m_dwExp1;
	/*+08*/		DWORD	m_dwExp2;
	/*+12*/		WORD	m_wLevel;
	/*+14*/		WORD	m_wLife;
	/*+16*/		WORD	m_wDamageMin;
	/*+18*/		WORD	m_wDamageMax;
	/*+20*/		WORD	m_wAttackSpeed;
	/*+22*/		WORD	m_wAttackSuccess;
}PET_INFO;

typedef struct //-> InDev (size: 1432)
{
	/*+00*/		BYTE	Ext[4];
	/*+04*/		bool	Blood;
	/*+05*/		bool	Ride;
	/*+06*/		bool	SkillSuccess;
	/*+08*/		BOOL	m_bFixForm;
	/*+12*/		bool	Foot[2];
	/*+14*/		bool	SafeZone;
	/*+15*/		bool	Change;
	/*+16*/		bool	HideShadow;
	/*+17*/		bool	m_bIsSelected;
	/*+18*/		bool	Decoy;
	/*+19*/		BYTE	Class;
	/*+20*/		BYTE	Skin;
	/*+21*/		BYTE	CtlCode;
	/*+22*/		BYTE	ExtendState;
	/*+23*/		BYTE	EtcPart;
	/*+24*/		BYTE	GuildStatus;
	/*+25*/		BYTE	GuildType;
	/*+26*/		BYTE	GuildRelationShip;
	/*+27*/		BYTE	GuildSkill;
	/*+28*/		BYTE	GuildMasterKillCount;
	/*+29*/		BYTE	BackupCurrentSkill;
	/*+30*/		BYTE	GuildTeam;
	/*+31*/		BYTE	m_byGensInfluence;	//0 - None, 1 - D, 2 - V
	/*+32*/		BYTE	PK;
	/*+33*/		BYTE	AttackFlag;
	/*+34*/		BYTE	AttackTime;
	/*+35*/		BYTE	TargetAngle;	//Personal Shop
	/*+36*/		BYTE	Dead;
	/*+37*/		BYTE	Run;
	/*+38*/		WORD	Skill;
	/*+40*/		BYTE	SwordCount;
	/*+41*/		BYTE	byExtensionSkill;
	/*+42*/		BYTE	m_byDieType;
	/*+43*/		BYTE	StormTime;
	/*+44*/		BYTE	JumpTime;
	/*+45*/		BYTE	Target_X;
	/*+46*/		BYTE	Target_y;
	/*+47*/		BYTE	SkillX;
	/*+48*/		BYTE	SkillY;
	/*+49*/		BYTE	Appear;
	/*+50*/		BYTE	CurrentSkill;
	/*+51*/		BYTE	CastRenderTime;
	/*+52*/		BYTE	m_byFriend;
	/*+54*/		WORD	MonsterSkill;
	/*+56*/		char	Name[64];
	/*+120*/	char	Movement;
	/*+121*/	char	MovementType;
	/*+122*/	char	CollisionTime;
	/*+124*/	short	GuildMarkIndex;
	/*+126*/	WORD	Key;
	/*+128*/	short	TargetCharacter;
	/*+130*/	WORD	Level;
	/*+132*/	WORD	MonsterIndex;
	/*+134*/	WORD	Damage;
	/*+136*/	WORD	Hit;
	/*+138*/	WORD	MoveSpeed;
	/*+140*/	int		Action;
	/*+144*/	int		ExtendStateTime;
	/*+148*/	int		LongRangeAttack;
	/*+152*/	int		SelectItem;
	/*+156*/	int		Item;
	/*+160*/	int		FreezeType;
	/*+164*/	int		PriorPositionX;
	/*+168*/	int		PriorPositionY;
	/*+172*/	int		PositionX;
	/*+176*/	int		PositionY;
	/*+180*/	int		m_iDeleteTime;
	/*+184*/	int		m_iFenrirSkillTarget;
	/*+188*/	float	ProtectGuildMarkWorldTime;
	/*+192*/	float	AttackRange;
	/*+196*/	float	Freeze;
	/*+200*/	float	Duplication;
	/*+204*/	float   Rot;
	/*+208*/	vec3_t  TargetPosition;
	/*+220*/	vec3_t  Light;
	/*+232*/	PART_t	BodyPart[MAX_BODYPART];
	/*+448*/	PART_t	Weapon[2];
	/*+520*/	PART_t	Wing;
	/*+556*/	PART_t	Helper_;
	/*+592*/	PART_t	Flag;
	/*+628*/	PATH_t	Path;
	/*+672*/	void* m_pParts;
	/*+676*/	void* m_pPet;
	/*+680*/	PET_INFO	m_PetInfo[2];
	/*+728*/	char	OwnerID[32];
	/*+760*/	DWORD	m_pPostMoveProcess;
	/*+764*/	void* m_pTempParts;
	/*+768*/	int		m_iTempKey;
	/*+772*/	WORD	m_CursedTempleCurSkill;
	/*+774*/	bool	m_CursedTempleCurSkillPacket;
	/*+776*/	OBJECT	Object;
	/*+1424*/	BYTE	m_byRankIndex;
	/*+1428*/	int		m_nContributionPoint;
} CHARACTER_PRE, * CHARACTER;



#pragma pack(push, 1)
typedef struct tagITEM	//-> Complete (size: 107)
{
	/*+0*/		WORD	Type;
	/*+2*/		int		Level;
	/*+6*/		BYTE	Part;
	/*+7*/		BYTE	Class;
	/*+8*/		bool	TwoHand;
	/*+9*/		WORD	DamageMin;
	/*+11*/		WORD	DamageMax;
	/*+13*/		BYTE	SuccessfulBlocking;
	/*+14*/		WORD	Defense;
	/*+16*/		WORD	MagicDefense;
	/*+18*/		BYTE	MagicPower;
	/*+19*/		BYTE	WeaponSpeed;
	/*+20*/		WORD	WalkSpeed;
	/*+22*/		BYTE	Durability;
	/*+23*/		BYTE	Option1;
	/*+24*/		BYTE	ExtOption;
	/*+25*/		WORD	RequireStrength;
	/*+27*/		WORD	RequireDexterity;
	/*+29*/		WORD	RequireEnergy;
	/*+31*/		WORD	RequireVitality;
	/*+33*/		WORD	RequireCharisma;
	/*+35*/		WORD	RequireLevel;
	/*+37*/		BYTE	SpecialNum;
	/*+38*/		WORD	Special[MAX_ITEM_SPECIAL];
	/*+54*/		BYTE	SpecialValue[MAX_ITEM_SPECIAL];
	/*+62*/		DWORD	Key;
	/*+66*/		BYTE	bySelectedSlotIndex;
	/*+67*/		BYTE	x;
	/*+68*/		BYTE	y;
	/*+69*/		WORD	Jewel_Of_Harmony_Option;
	/*+71*/		WORD	Jewel_Of_Harmony_OptionLevel;
	/*+73*/		bool	option_380;
	/*+74*/		BYTE	bySocketOption[MAX_SOCKETS];
	/*+79*/		BYTE	SocketCount;
	/*+80*/		BYTE	SocketSeedID[MAX_SOCKETS];
	/*+85*/		BYTE	SocketSphereLv[MAX_SOCKETS];
	/*+90*/		BYTE	SocketSeedSetOption;
	int		Number;
	BYTE	Color;
	/*+96*/		BYTE	byColorState;
	/*+97*/		bool	PeriodItem;
	/*+98*/		bool	ExpiredItem;
	/*+99*/		int		lExpireTime;
	/*+103*/	int		RefCount;
} ITEM;
#pragma pack(pop)

typedef std::map<int, ITEM*> type_vec_item;

typedef struct
{
	char Name[30];
	bool TwoHand;
	WORD Level;
	BYTE m_byItemSlot;
	WORD m_wSkillIndex;
	BYTE Width;
	BYTE Height;
	BYTE DamageMin;
	BYTE DamageMax;
	BYTE SuccessfulBlocking;
	BYTE Defense;
	BYTE MagicDefense;
	BYTE WeaponSpeed;
	BYTE WalkSpeed;
	BYTE Durability;
	BYTE MagicDur;
	BYTE MagicPower;
	WORD RequireStrength;
	WORD RequireDexterity;
	WORD RequireEnergy;
	WORD  RequireVitality;
	WORD RequireCharisma;
	WORD RequireLevel;
	BYTE Value;
	int  iZen;
	BYTE  AttType;
	BYTE RequireClass[MAX_RESISTANCE];
	BYTE Resistance[MAX_RESISTANCE];
} ITEM_ATTRIBUTE;

typedef struct
{
	/*+00*/	char Name[32];
	/*+32*/	WORD Level;
	/*+34*/	WORD Damage;
	/*+36*/	WORD Mana;
	/*+38*/	WORD AbilityGuage;
	/*+40*/	DWORD Distance;
	/*+44*/	int Delay;
	/*+48*/	int Energy;
	/*+52*/	WORD Charisma;
	/*+54*/	BYTE MasteryType;
	/*+55*/	BYTE SkillUseType;
	/*+56*/	DWORD SkillBrand;
	/*+60*/	BYTE KillCount;
	/*+61*/	BYTE RequireDutyClass[3];
	/*+64*/	BYTE RequireClass[MAX_OLD_CLASS];
	/*+71*/	BYTE SkillRank;
	/*+72*/	WORD Magic_Icon;
	/*+74*/	BYTE TypeSkill;
	/*+75*/	BYTE gap_4B;
	/*+76*/	int Strength;
	/*+80*/	int Dexterity;
	/*+84*/	BYTE ItemSkill;
	/*+85*/	BYTE IsDamage;
	/*+86*/	WORD Effect;
} SKILL_ATTRIBUTE;

typedef struct
{
	char    Name[11];
	BYTE    Number;
	BYTE    Map;
	BYTE    x;
	BYTE    y;
	int     currHP;
	int     maxHP;
	BYTE    stepHP;
	int     index;
} PARTY_t;

typedef struct
{
	/*+0*/	bool   Live;
	/*+1*/	int    Type;
	/*+2*/	int    TexType;
	/*+3*/	int    SubType;
	/*+4*/	float  Scale;
	/*+5*/	vec3_t Position;
	/*+8*/	vec3_t Angle;
	/*+11*/	vec3_t Light;
	/*+14*/	float  Alpha;
	/*+15*/	int    LifeTime;
	/*+16*/	int ObjTarget;
	/*+17*/	float  Rotation;
	/*+18*/	int    Frame;
	/*+19*/	bool   bEnableMove;
	/*+20*/	float  Gravity;
	/*+21*/	vec3_t Velocity;
	/*+24*/	vec3_t TurningForce;
	/*+27*/	vec3_t StartPosition;
	/*+30*/	int iNumBone;
	/*+31*/	bool bRepeatedly;
	/*+32*/	float fRepeatedlyHeight;
} PARTICLE;

typedef struct
{
	/*+0*/	bool		Live;
	/*+4*/	int			Type;
	/*+8*/	int         TexType;
	/*+12*/	int			SubType;
	/*+16*/	BYTE        RenderType;
	/*+17*/	BYTE        RenderFace;
	/*+20*/	float		Scale;
	/*+24*/	vec3_t		Position;
	/*+36*/	vec3_t      StartPosition;
	/*+48*/	vec3_t		Angle;
	/*+60*/	vec3_t		HeadAngle;
	/*+72*/	vec3_t		Light;
	/*+84*/	DWORD      ObjTarget;
	/*+88*/	vec3_t      TargetPosition;
	/*+100*/	BYTE        byOnlyOneRender;
	/*+104*/	int			NumTails;
	/*+108*/	int			MaxTails;
	/*+112*/	vec3_t		Tails[50][4];
	/*+2512*/	int  		LifeTime;
	/*+2516*/	bool        Collision;
	/*+2520*/	float		Velocity;
	/*+2524*/	vec3_t		Direction;
	/*+2536*/	short       PKKey;
	/*+2538*/	WORD		Skill;
	/*+2540*/	BYTE		Weapon;
	/*+2544*/		int			MultiUse;
	/*+2548*/		bool        bTileMapping;
	/*+2549*/	BYTE        m_byReverseUV;
	/*+2550*/	bool        m_bCreateTails;
	/*+2552*/	int			TargetIndex[5];
	/*+2572*/	BYTE		m_bySkillSerialNum;
	/*+2576*/	int			m_iChaIndex;
	/*+2580*/	short int	m_sTargetIndex;
} JOINT;


#define Information_ItemConvert							((char (__cdecl*)(ITEM *ip, unsigned __int8 Attribute1, unsigned __int8 Attribute2, unsigned __int8 Attribute3)) 0x0058B910)
#define IsCepterItem									((bool (__cdecl*)(int Type)) 0x0058B8D0)
#define ItemAttribute(ItemId)							(ITEM_ATTRIBUTE*)(*(DWORD*)0x008128AC0 + 84 * ItemId)
#define ItemAttribute1(ItemId)							(ITEM_ATTRIBUTE)(*(DWORD*)0x008128AC0 + 84 * ItemId)