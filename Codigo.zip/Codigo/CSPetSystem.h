#pragma once

#define SPetSystem_Create			((void(__thiscall*)(int This, int Type, unsigned char PositionX, unsigned char PositionY, float Rotation)) 0x004F0A40)

class CSPetSystem
{
public:
	CSPetSystem(void);
	virtual ~CSPetSystem(void);

	void Init();

	static void __thiscall CreatePetPointer(int This, int Type, unsigned char PositionX, unsigned char PositionY, float Rotation);
};

extern CSPetSystem g_PetSystem;