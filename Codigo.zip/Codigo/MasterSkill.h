


void InitMasterSkillEffect();