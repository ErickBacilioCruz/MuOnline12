#include "stdafx.h"
#include "Util.h"
#include "Defines.h"
#include "Protect.h"
#include "SEASON3B.h"
#include "UIControl.h"
#include "PrintPlayer.h"
#include "WideScremS6.h"
#include "CChatEx.h"

CNewUIMainFrame g_pNewUIMainFrame;
DWORD byColorState = -1; //-> Define check variable

int fScreenWin = 640;
float Higadd = 0.0;

CNewUIMainFrame::CNewUIMainFrame(void)
{
}

CNewUIMainFrame::~CNewUIMainFrame(void)
{
}

void CNewUIMainFrame::LoadImages()
{
	((void(__cdecl*)())0x0080EEF0)();
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )

	LoadBitmapA("Interface\\EX\\main_frame_left.tga", 31292, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_right.tga", 31294, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\main_frame_mana.tga", 31296, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_venom.tga", 31297, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_life.tga", 31298, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_stamina.jpg", 31299, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_shield.jpg", 31300, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\btn_shop.jpg", 31303, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_btn_character.jpg", 31304, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_btn_inventory.jpg", 31305, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_btn_guild.jpg", 31306, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\main_frame_btn_party.jpg", 31307, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\item_back01_v2.jpg", 931300, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\item_back02_v2.jpg", 931301, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\item_back02_v2.tga", 931302, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\points_v2.jpg", 931303, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\stats_v2.jpg", 931304, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\btn_plus_v2.jpg", 931305, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_close_v2.jpg", 931306, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_repair_v2.jpg", 931307, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_openstore_v2.jpg", 931308, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_mix_v2.jpg", 931309, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_deposit_v2.jpg", 931310, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_withdraw_v2.jpg", 931311, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_lock_v2.jpg", 931312, GL_LINEAR, GL_CLAMP, 1, 0);

	LoadBitmapA("Interface\\EX\\btn_lock2_v2.jpg", 931313, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\EX\\btn_closestore_v2.jpg", 931314, GL_LINEAR, GL_CLAMP, 1, 0);
	//--
	LoadBitmapA("Interface\\EX\\item_box_v2.jpg", 931315, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\item_money_v2.tga", 931316, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\btn_expande_v2.jpg", 931317, GL_LINEAR, GL_CLAMP, 1, 0);
	//-- msg box
	LoadBitmapA("interface\\EX\\messagebox_bot_v2.tga", 931318, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\messagebox_mid_v2.tga", 931319, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\messagebox_top_v2.tga", 931320, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\messagebox_top2_v2.tga", 931321, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\option_check.tga", 931322, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\none.tga", 931323, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\btn_menu_v2.jpg", 931324, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\btn_close_2_v2.jpg", 931325, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\btn_pause.jpg", 931335, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("interface\\EX\\btn_playt.jpg", 931336, GL_LINEAR, GL_CLAMP, 1, 0);
	//31325
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
#if ( EMULADOR_INTERFACE == 3 )
	LoadBitmapA("Custom\\InterfaceS2\\WDecorOld97.tga", 61548, GL_LINEAR, GL_CLAMP, 1, 0);
#else
	LoadBitmapA("Custom\\InterfaceS2\\WDecorOld.tga", 61548, GL_LINEAR, GL_CLAMP, 1, 0);
#endif
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_friend.jpg", 361548, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_guild.jpg", 361549, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_Inventory.jpg", 361550, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_Character.jpg", 361551, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_Party.jpg", 361552, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Custom\\InterfaceS2\\Boton\\Menu_fastmenu.jpg", 361553, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmap("Interface\\Item_Back02.jpg", 31055, 9728, 10496, 1, 0);
#else
	LoadBitmapA("Custom\\Decor.tga", 61548, GL_LINEAR, GL_CLAMP, 1, 0); //Cliente
#endif
}

__declspec(naked) void PhotoTranslatef()
{
	static DWORD main_addr = 0x0048E334;
	static float TranslateZ = 20;

	_asm
	{
		mov     eax, dword ptr ss : [ebp - 0xC]
		fld     dword ptr ds : [eax + 0x104]
		fchs
		fsub    dword ptr ds : [TranslateZ]
			fstp    dword ptr ss : [ebp - 0x20]
				fld     dword ptr ss : [ebp - 0x20]
				jmp[main_addr]
	}
}

void FixNumberPotion(float x, float y, int number)
{
	RenderNumber(x, y, number, 0.85f);
}

void FixNumberExperience(float x, float y, int iNum, float fScale)
{
	RenderNumber(x, y, iNum, 0.9f);
}

void CNewUIMainFrame::setFrameInfo()
{
	static float fSkillBAR[4];
	static float fSkillMOUSE[8];
	static float fSkillSWITCH[4];
	static float Interfacex[3];
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	fSkillBAR[1] = setPosDown(431.f);
	fSkillBAR[3] = setPosDown(448.f);
	fSkillBAR[0] = setPosMidRight(190.f);
	fSkillBAR[2] = setPosMidRight(310.5f);

	fSkillSWITCH[1] = setPosDown(390.f);
	fSkillSWITCH[3] = setPosDown(352.f);
	fSkillSWITCH[0] = setPosMidRight(385.f);
	fSkillSWITCH[2] = setPosMidRight(353.f);

	fSkillMOUSE[0] = setPosDown(448.f);
	fSkillMOUSE[1] = setPosDown(390.f);
	fSkillMOUSE[2] = setPosDown(352.f);
	fSkillMOUSE[3] = setPosMidRight(303.5f);
	fSkillMOUSE[4] = setPosMidRight(0.f);
	fSkillMOUSE[5] = setPosMidRight(0.f);
	fSkillMOUSE[6] = setPosMidRight(385.f);
	fSkillMOUSE[7] = setPosMidRight(353.f);
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	fSkillBAR[1] = setPosDown(431.f);
	fSkillBAR[3] = setPosDown(448.f);
	fSkillBAR[0] = setPosMidRight(190.f);
	fSkillBAR[2] = setPosMidRight(310.5f);

	fSkillSWITCH[1] = setPosDown(390.f);
	fSkillSWITCH[3] = setPosDown(352.f);
	fSkillSWITCH[0] = setPosMidRight(385.f);
	fSkillSWITCH[2] = setPosMidRight(353.f);

	fSkillMOUSE[0] = setPosDown(448.f);
	fSkillMOUSE[1] = setPosDown(390.f);
	fSkillMOUSE[2] = setPosDown(352.f);
	fSkillMOUSE[3] = setPosMidRight(303.5f);
	fSkillMOUSE[4] = setPosMidRight(0.f);
	fSkillMOUSE[5] = setPosMidRight(0.f);
	fSkillMOUSE[6] = setPosMidRight(385.f);
	fSkillMOUSE[7] = setPosMidRight(353.f);
#elif ( EMULADOR_INTERFACE == 5 || EMULADOR_INTERFACE == 6 )
	fSkillBAR[1] = setPosDown(438.f); //-- 565.4 = 572.4
	fSkillBAR[3] = setPosDown(444.f); //-- 582.4 = 578.4
	fSkillBAR[0] = setPosMidRight(306.f); //-- 414 = 530
	fSkillBAR[2] = setPosMidRight(307.f);//--534.5f = 531

	fSkillSWITCH[1] = setPosDown(390.f);
	fSkillSWITCH[3] = setPosDown(352.f);
	fSkillSWITCH[0] = setPosMidRight(385.f);
	fSkillSWITCH[2] = setPosMidRight(353.f);

	fSkillMOUSE[0] = setPosDown(448.f);
	fSkillMOUSE[1] = setPosDown(390.f);
	fSkillMOUSE[2] = setPosDown(352.f);
	fSkillMOUSE[3] = setPosMidRight(303.5f);
	fSkillMOUSE[4] = setPosMidRight(0.f);
	fSkillMOUSE[5] = setPosMidRight(0.f);
	fSkillMOUSE[6] = setPosMidRight(385.f);
	fSkillMOUSE[7] = setPosMidRight(353.f);
#else
	fSkillBAR[1] = setPosDown(431.f);
	fSkillBAR[3] = setPosDown(437.f);
	fSkillBAR[0] = setPosMidRight(190.f);
	fSkillBAR[2] = setPosMidRight(392.f);

	fSkillSWITCH[1] = setPosDown(390.f);
	fSkillSWITCH[3] = setPosDown(352.f);
	fSkillSWITCH[0] = setPosMidRight(385.f);
	fSkillSWITCH[2] = setPosMidRight(353.f);

	fSkillMOUSE[0] = setPosDown(431.f);
	fSkillMOUSE[1] = setPosDown(390.f);
	fSkillMOUSE[2] = setPosDown(352.f);
	fSkillMOUSE[3] = setPosMidRight(385.f);
	fSkillMOUSE[4] = setPosMidRight(222.f);
	fSkillMOUSE[5] = setPosMidRight(190.f);
	fSkillMOUSE[6] = setPosMidRight(385.f);
	fSkillMOUSE[7] = setPosMidRight(353.f);
#endif
	//--
	SetDword(0x0081271C + 2, (DWORD)&fSkillMOUSE[0]);
	SetDword(0x00812950 + 2, (DWORD)&fSkillMOUSE[0]);
	SetDword(0x00812A7F + 2, (DWORD)&fSkillMOUSE[0]);
	SetDword(0x00812CA2 + 2, (DWORD)&fSkillMOUSE[0]);
	SetDword(0x00812D48 + 2, (DWORD)&fSkillMOUSE[1]);
	SetDword(0x008130B3 + 2, (DWORD)&fSkillMOUSE[2]);
	SetDword(0x00812713 + 2, (DWORD)&fSkillMOUSE[3]);
	SetDword(0x00812947 + 2, (DWORD)&fSkillMOUSE[4]);
	SetDword(0x00812C99 + 2, (DWORD)&fSkillMOUSE[4]);
	SetDword(0x00812A76 + 2, (DWORD)&fSkillMOUSE[5]);
	SetDword(0x00812D63 + 2, (DWORD)&fSkillMOUSE[6]);
	SetDword(0x008130AA + 2, (DWORD)&fSkillMOUSE[7]);
	//--
	SetDword(0x00813779 + 2, (DWORD)&fSkillBAR[0]);
	SetDword(0x00813782 + 2, (DWORD)&fSkillBAR[1]);
	SetDword(0x008138DF + 2, (DWORD)&fSkillBAR[2]);
	SetDword(0x008138E8 + 2, (DWORD)&fSkillBAR[3]);
	SetDword(0x008139C4 + 2, (DWORD)&fSkillSWITCH[0]);
	SetDword(0x008139A9 + 2, (DWORD)&fSkillSWITCH[1]);

	SetDword(0x00813CC5 + 2, (DWORD)&fSkillSWITCH[3]);
	SetDword(0x00813CBC + 2, (DWORD)&fSkillSWITCH[2]);
	SetByte(0x00813C18 + 2, 40); //-- iPos_y tooltip skill

	//-- Interface Main
	Interfacex[0] = setPosMidRight(256.f);
	Interfacex[1] = setPosMidRight(384.f);
	Interfacex[2] = setPosMidRight(222.f);
	//--Tooltip
	SetDword(0x0080FF99 + 1, (int)setPosDown(390));
	SetDword(0x0081012C + 1, (int)setPosDown(390));
	SetDword(0x008103F7 + 1, (int)setPosDown(390));
	SetDword(0x008106D9 + 1, (int)setPosDown(390));
	//-- Interface Duel
	SetDword(0x007BF258 + 1, (int)(GetWindowsY - 29));
	SetDword(0x007BF289 + 1, (int)(GetWindowsY - 29));
	SetDword(0x007BF412 + 3, (int)(GetWindowsY - 51));
	SetDword(0x007BF28E + 1, (int)setPosMidRight(604));
	SetDword(0x007BF25D + 1, (int)setPosMidRight(604));
	SetDword(0x007BF47C + 2, (int)setPosMidRight(345));
	SetDword(0x007BF44A + 2, (int)setPosMidRight(240));
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	fProgress = 200.f;
	fExpHeight = 5.f;
	fExpBarX = setPosMidRight(221.f);
	fExpBarY = (float)GetWindowsY - 42.f;
	fExpBarNumX = setPosMidRight(426.f);
	fExpBarNumY = (float)GetWindowsY - 44.f;
	//-----------------------------------------------
	KeyCommon[0][3] = GetWindowsY - 27.f; //-- PosionY q number
	KeyCommon[1][3] = GetWindowsY - 27.f; //-- PosionY r number
	KeyCommon[2][3] = GetWindowsY - 27.f; //-- PosionY r number
	KeyCommon[3][3] = GetWindowsY - 27.f; //-- PosionY r number
	KeyCommon[0][2] = GetWindowsY - 35.f; //-- numberY q potion
	KeyCommon[1][2] = GetWindowsY - 35.f; //-- numberY w potion
	KeyCommon[2][2] = GetWindowsY - 35.f; //-- numberY e potion
	KeyCommon[3][2] = GetWindowsY - 35.f; //-- numberY r potion
	KeyCommon[0][0] = setPosMidRight(209.0f); //-- posionx q potion
	KeyCommon[0][1] = setPosMidRight(219.0f); //-- posionx q number
	KeyCommon[1][0] = setPosMidRight(241.0f); //-- posionx w potion
	KeyCommon[1][1] = setPosMidRight(251.0f); //-- posionx w number
	KeyCommon[2][0] = setPosMidRight(272.0f); //-- posionx e potion
	KeyCommon[2][1] = setPosMidRight(283.0f); //-- posionx e number
	KeyCommon[3][0] = setPosMidRight(124.f); //-- posionx r potion
	KeyCommon[3][1] = setPosMidRight(144.f); //-- posionx r number
	SetDword(0x0080F280 + 3, GetWindowsY); //-- buttons Y
#elif ( EMULADOR_INTERFACE == 5 || EMULADOR_INTERFACE == 6 )
	fProgress = 518.1f;
	fExpHeight = 4.f;
	fExpBarX = setPosMidRight(60.f);
	fExpBarY = setPosDown(474.f);
	fExpBarNumX = setPosMidRight(606.5f);
	fExpBarNumY = setPosDown(470.f);
	//-----------------------------------------------
	KeyCommon[0][3] = setPosDown(445.f); //-- PosionY q number
	KeyCommon[1][3] = setPosDown(445.f); //-- PosionY r number
	KeyCommon[2][3] = setPosDown(445.f); //-- PosionY r number
	KeyCommon[3][3] = setPosDown(445.f); //-- PosionY r number
	KeyCommon[0][2] = setPosDown(460.f); //-- numberY q potion
	KeyCommon[1][2] = setPosDown(460.f); //-- numberY w potion
	KeyCommon[2][2] = setPosDown(460.f); //-- numberY e potion
	KeyCommon[3][2] = setPosDown(460.f); //-- numberY r potion
	KeyCommon[0][0] = setPosMidRight(189.f); //-- posionx q potion
	KeyCommon[0][1] = setPosMidRight(206.f); //-- posionx q number
	KeyCommon[1][0] = setPosMidRight(217.f); //-- posionx w potion
	KeyCommon[1][1] = setPosMidRight(234.f); //-- posionx w number
	KeyCommon[2][0] = setPosMidRight(247.f); //-- posionx e potion
	KeyCommon[2][1] = setPosMidRight(261.f); //-- posionx e number
	KeyCommon[3][0] = setPosMidRight(277.f); //-- posionx r potion
	KeyCommon[3][1] = setPosMidRight(291.f); //-- posionx r number
	SetDword(0x0080F280 + 3, GetWindowsY); //-- buttons Y
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	fProgress = 198.f;
	fExpHeight = 5.8f;
	fExpBarX = setPosMidRight(221.f);
	fExpBarY = setPosDown(435.f);
	fExpBarNumX = setPosMidRight(425.f);
	fExpBarNumY = setPosDown(431.5f);
	//-----------------------------------------------
	KeyCommon[0][3] = setPosDown(453.f); //-- PosionY q number
	KeyCommon[1][3] = setPosDown(453.f); //-- PosionY r number
	KeyCommon[2][3] = setPosDown(453.f); //-- PosionY r number
	KeyCommon[3][3] = setPosDown(453.f); //-- PosionY r number
	KeyCommon[0][2] = setPosDown(445.f); //-- numberY q potion
	KeyCommon[1][2] = setPosDown(445.f); //-- numberY w potion
	KeyCommon[2][2] = setPosDown(445.f); //-- numberY e potion
	KeyCommon[3][2] = setPosDown(445.f); //-- numberY r potion
	KeyCommon[0][0] = setPosMidRight(210.f); //-- posionx q potion
	KeyCommon[0][1] = setPosMidRight(227.f); //-- posionx q number
	KeyCommon[1][0] = setPosMidRight(240.f); //-- posionx w potion
	KeyCommon[1][1] = setPosMidRight(257.f); //-- posionx w number
	KeyCommon[2][0] = setPosMidRight(270.f); //-- posionx e potion
	KeyCommon[2][1] = setPosMidRight(287.f); //-- posionx e number
	KeyCommon[3][0] = setPosMidRight(300.f); //-- posionx r potion
	KeyCommon[3][1] = setPosMidRight(317.f); //-- posionx r number
	SetDword(0x0080F280 + 3, GetWindowsY); //-- buttons Y
#else
	fProgress = 629.f;
	fExpHeight = 4.f;
	fExpBarX = setPosMidRight(2.f);
	fExpBarY = (float)GetWindowsY - 7.f;
	fExpBarNumX = setPosMidRight(635.f);
	fExpBarNumY = (float)GetWindowsY - 11.f;
	//-----------------------------------------------
	KeyCommon[0][3] = GetWindowsY - 37.f; //-- PosionY q number
	KeyCommon[1][3] = GetWindowsY - 37.f; //-- PosionY r number
	KeyCommon[2][3] = GetWindowsY - 37.f; //-- PosionY r number
	KeyCommon[3][3] = GetWindowsY - 37.f; //-- PosionY r number
	KeyCommon[0][2] = GetWindowsY - 23.f; //-- numberY q potion
	KeyCommon[1][2] = GetWindowsY - 23.f; //-- numberY w potion
	KeyCommon[2][2] = GetWindowsY - 23.f; //-- numberY e potion
	KeyCommon[3][2] = GetWindowsY - 23.f; //-- numberY r potion
	KeyCommon[0][0] = setPosMidRight(10.0f); //-- posionx q
	KeyCommon[0][1] = setPosMidRight(30.0f); //-- posionx q number
	KeyCommon[1][0] = setPosMidRight(48.0f); //-- posionx w
	KeyCommon[1][1] = setPosMidRight(68.0f); //-- posionx w number
	KeyCommon[2][0] = setPosMidRight(86.0f); //-- posionx e
	KeyCommon[2][1] = setPosMidRight(106.f); //-- posionx e number
	KeyCommon[3][0] = setPosMidRight(124.f); //-- posionx r
	KeyCommon[3][1] = setPosMidRight(144.f); //-- posionx r number
	SetDword(0x0080F280 + 3, (GetWindowsY - 51)); //-- buttons Y
#endif
	SetDword(0x00810FDD + 1, (DWORD)setPosDown(418));
	SetDword(0x00811886 + 1, (DWORD)setPosDown(418));
	SetDword(0x0080F279 + 3, (DWORD)setPosMidRight(489)); //-- Buttons X
	SetDword(0x00810FE2 + 1, (DWORD)setPosMidRight(280));
	SetDword(0x0081188B + 1, (DWORD)setPosMidRight(280));
	//-----------------------------------------------
	SetDword(0x00810985 + 2, (DWORD)&fExpBarY);
	SetDword(0x00810B50 + 2, (DWORD)&fExpBarY);
	SetDword(0x00810C94 + 2, (DWORD)&fExpBarY);
	SetDword(0x00810E5B + 2, (DWORD)&fExpBarY);
	SetDword(0x00810F58 + 2, (DWORD)&fExpBarY);
	SetDword(0x0081120E + 2, (DWORD)&fExpBarY);
	SetDword(0x008113E7 + 2, (DWORD)&fExpBarY);
	SetDword(0x00811531 + 2, (DWORD)&fExpBarY);
	SetDword(0x008116F8 + 2, (DWORD)&fExpBarY);
	SetDword(0x00811801 + 2, (DWORD)&fExpBarY);
	SetDword(0x0081097C + 2, (DWORD)&fExpBarX);
	SetDword(0x00810B47 + 2, (DWORD)&fExpBarX);
	SetDword(0x00810C8B + 2, (DWORD)&fExpBarX);
	SetDword(0x00810E52 + 2, (DWORD)&fExpBarX);
	SetDword(0x00810F4F + 2, (DWORD)&fExpBarX);
	SetDword(0x00811205 + 2, (DWORD)&fExpBarX);
	SetDword(0x008113DE + 2, (DWORD)&fExpBarX);
	SetDword(0x00811528 + 2, (DWORD)&fExpBarX);
	SetDword(0x008116EF + 2, (DWORD)&fExpBarX);
	SetDword(0x008117F8 + 2, (DWORD)&fExpBarX);
	SetDword(0x00810991 + 2, (DWORD)&fProgress);
	SetDword(0x00810B5C + 2, (DWORD)&fProgress);
	SetDword(0x00810CA3 + 2, (DWORD)&fProgress);
	SetDword(0x00810D43 + 2, (DWORD)&fProgress);
	SetDword(0x00810E67 + 2, (DWORD)&fProgress);
	SetDword(0x00810F61 + 2, (DWORD)&fProgress);
	SetDword(0x0081121D + 2, (DWORD)&fProgress);
	SetDword(0x008113F6 + 2, (DWORD)&fProgress);
	SetDword(0x00811540 + 2, (DWORD)&fProgress);
	SetDword(0x008115E0 + 2, (DWORD)&fProgress);
	SetDword(0x00811707 + 2, (DWORD)&fProgress);
	SetDword(0x0081180A + 2, (DWORD)&fProgress);
	SetDword(0x008107C6 + 2, (DWORD)&fExpHeight);
	SetDword(0x0081099A + 2, (DWORD)&fExpHeight);
	SetDword(0x00810B65 + 2, (DWORD)&fExpHeight);
	SetDword(0x00810CAC + 2, (DWORD)&fExpHeight);
	SetDword(0x00810E70 + 2, (DWORD)&fExpHeight);
	SetDword(0x00810F6A + 2, (DWORD)&fExpHeight);
	SetDword(0x0081100B + 2, (DWORD)&fExpHeight);
	SetDword(0x00811226 + 2, (DWORD)&fExpHeight);
	SetDword(0x008113FF + 2, (DWORD)&fExpHeight);
	SetDword(0x00811549 + 2, (DWORD)&fExpHeight);
	SetDword(0x00811710 + 2, (DWORD)&fExpHeight);
	SetDword(0x00811813 + 2, (DWORD)&fExpHeight);
	SetDword(0x00810F03 + 2, (DWORD)&fExpBarNumX);
	SetDword(0x00810F0C + 2, (DWORD)&fExpBarNumY);
	SetDword(0x008117A9 + 2, (DWORD)&fExpBarNumX);
	SetDword(0x008117B2 + 2, (DWORD)&fExpBarNumY);
	//----------------------------------------------------------------------------
	SetDword(0x0080F93E + 2, (DWORD)&Interfacex[0]); //-- Main [Interface Central]
	SetDword(0x0080F979 + 2, (DWORD)&Interfacex[1]); //-- Main [Interface Central]
	SetDword(0x0080F9D8 + 2, (DWORD)&Interfacex[2]); //-- Main [Interface Central]
	SetDword(0x00895A67 + 2, (DWORD)&KeyCommon[0][0]); //-- HotKeyCommon []
	SetDword(0x00895A53 + 2, (DWORD)&KeyCommon[0][1]); //-- HotKeyCommon []
	SetDword(0x00895ADC + 2, (DWORD)&KeyCommon[1][0]); //-- HotKeyCommon []
	SetDword(0x00895AC8 + 2, (DWORD)&KeyCommon[1][1]); //-- HotKeyCommon []
	SetDword(0x00895B51 + 2, (DWORD)&KeyCommon[2][0]); //-- HotKeyCommon []
	SetDword(0x00895B3D + 2, (DWORD)&KeyCommon[2][1]); //-- HotKeyCommon []
	SetDword(0x00895BC6 + 2, (DWORD)&KeyCommon[3][0]); //-- HotKeyCommon []
	SetDword(0x00895BB2 + 2, (DWORD)&KeyCommon[3][1]); //-- HotKeyCommon []
	SetDword(0x00895A49 + 2, (DWORD)&KeyCommon[0][2]); //-- HotKeyCommon [num potion]
	SetDword(0x00895ABE + 2, (DWORD)&KeyCommon[1][2]); //-- HotKeyCommon [num potion]
	SetDword(0x00895B33 + 2, (DWORD)&KeyCommon[2][2]); //-- HotKeyCommon [num potion]
	SetDword(0x00895BA8 + 2, (DWORD)&KeyCommon[3][2]); //-- HotKeyCommon [num potion]
	SetDword(0x00895A5D + 2, (DWORD)&KeyCommon[0][3]); //-- HotKeyCommon [model potion]
	SetDword(0x00895AD2 + 2, (DWORD)&KeyCommon[1][3]); //-- HotKeyCommon [model potion]
	SetDword(0x00895B47 + 2, (DWORD)&KeyCommon[2][3]); //-- HotKeyCommon [model potion]
	SetDword(0x00895BBC + 2, (DWORD)&KeyCommon[3][3]); //-- HotKeyCommon [model potion]
}

void CNewUIMainFrame::ButtonCashShop(BYTE* This, int x, int y, int sx, int sy)
{
	//if (gProtect->m_MainInfo.EnableShopX == 0)
	//{
	//	pChangeButtonInfo(This, 24, -100, 24, 24);
	//}
	//else
	//{
		pChangeButtonInfo(This, 24, 0, 24, 24);
	//}
}

void CNewUIMainFrame::ButtonCharacterInfo(BYTE* This, int x, int y, int sx, int sy)
{
	int frame_cx = GetCenterX(640);
	int frame_cy = setPosDown(0);

#if ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	x = frame_cx + 380;
	y = frame_cy + 451;
	sx = 23; sy = 25;
#elif ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	x = frame_cx + 412;
	y = frame_cy + 452;
	sx = 22; sy = 22;
#endif

	pChangeButtonInfo(This, x, y, sx, sy);
}

void CNewUIMainFrame::ButtonInventory(BYTE* This, int x, int y, int sx, int sy)
{
	int frame_cx = GetCenterX(640);
	int frame_cy = setPosDown(0);

#if ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	x = frame_cx + 410;
	y = frame_cy + 451;
	sx = 23; sy = 25;
#elif ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	x = frame_cx + 380;
	y = frame_cy + 452;
	sx = 22; sy = 22;
#endif

	pChangeButtonInfo(This, x, y, sx, sy);
}

void CNewUIMainFrame::ButtonFriend(BYTE* This, int x, int y, int sx, int sy)
{
	int frame_cx = GetCenterX(640);
	int frame_cy = setPosDown(0);

#if ( EMULADOR_INTERFACE == 4 )
	x = frame_cx + 581;
	y = frame_cy + 433;
	sx = 52; sy = 20;
#elif ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	x = frame_cx + 91;
	y = frame_cy + 452;
	sx = 22; sy = 22;
#endif

	pChangeButtonInfo(This, x, y, sx, sy);
}

void CNewUIMainFrame::ButtonMenuWindows(BYTE* This, int x, int y, int sx, int sy)
{
	int frame_cx = GetCenterX(640);
	int frame_cy = setPosDown(0);

#if ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	sx = 53; sy = 20;
	x = frame_cx + 6;
	y = frame_cy + 433;
#if ( EMULADOR_INTERFACE == 3 )
	x = frame_cx + 582;
	y = frame_cy + 458;
#endif
#elif ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	x = frame_cx + 349;
	y = frame_cy + 452;
	sx = 22; sy = 22;
#endif

	pChangeButtonInfo(This, x, y, sx, sy);
}

void CNewUIMainFrame::RenderFrame(int This)
{
	float frame_cx = GetCenterX(640);
	float frame_cy = (float)GetWindowsY - 51.f;

#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	frame_cy = (float)GetWindowsY - 60.f;

	RenderImageF(31292, frame_cx, frame_cy, 320.0, 60.0, 0.0, 0.0, 716.f, 134.f);
	frame_cx += 320.f;
	RenderImageF(31294, frame_cx, frame_cy, 320.0, 60.0, 0.0, 0.0, 717.f, 134.f);

	char szText[100] = { 0, };
	sprintf_s(szText, "%d %d", *(int*)(Hero + 172), *(int*)(Hero + 176));
	//--
	frame_cx = GetCenterX(640);
	g_pRenderText->SetBgColor(0);
	g_pRenderText->SetFont(g_hFixFont);
	g_pRenderText->SetTextColor(CLRDW_GRAY2);
	g_pRenderText->RenderText(frame_cx + 46, frame_cy + 46, szText, 35, 0, RT3_SORT_CENTER);

	sprintf_s(szText, "FPS: %d", AnimationFrameConstant);

	g_pRenderText->RenderText(frame_cx + 555, frame_cy + 46, szText, 35, 0, RT3_SORT_CENTER); //-- render fps
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	RenderImageB(31292, frame_cx, frame_cy, 256.0, 51.0);
	RenderImageB(31293, frame_cx + 256.f, frame_cy, 128.0, 51.0);
	RenderImageB(31294, frame_cx + 384.f, frame_cy, 256.0, 51.0);

	if (WindowWidth > 800)
	{
		RenderImageF(61548, frame_cx - 053.f, frame_cy - 13.f, 130.f, 64.f, 0.0, 0.0, 128.f, 64.f);
		RenderImageF(61548, frame_cx + 564.f, frame_cy - 13.f, 130.f, 64.f, 128.0, 0.0, -128.f, 64.f);
	}

	RenderNumber(frame_cx + 22, frame_cy + 32.f, *(int*)(Hero + 172), 1.f);
	RenderNumber(frame_cx + 46, frame_cy + 32.f, *(int*)(Hero + 176), 1.f);
#elif ( EMULADOR_INTERFACE == 5 || EMULADOR_INTERFACE == 6 )
	//-- Ex700
#else
	RenderImageB(31292, frame_cx, frame_cy, 256.0, 51.0);
	RenderImageB(31293, frame_cx + 256.f, frame_cy, 128.0, 51.0);
	RenderImageB(31294, frame_cx + 384.f, frame_cy, 256.0, 51.0);

	RenderImageF(61548, frame_cx - 70.f, frame_cy, 70.f, 51.f, 0.0, 0.0, 113.f, 82.f);
	RenderImageF(61548, frame_cx + 640.f, frame_cy, 70.f, 51.f, 113.f, 0.0, -113.f, 82.f);

	int v4 = getNewSkillList(GetInstance());
	if (((bool(__thiscall*)(int)) 0x00815000)(v4) == true)
	{
		RenderImageB(31295, 222.f + GetCenterX(640), GetWindowsY - (float)51.0, 160.0, 40.0);
	}
#endif
}

void CNewUIMainFrame::RenderHeroLifeMana(int This)
{
	float fLife = 0.f, fMana = 0.f;
	float u[2], v[2], uw[2], vh[2];
	float fY[2], fH[2], fV, X[2], Y[2], width, height;
	float frame_cx = GetCenterX(640);

	if (ViewMaxHP > 0)
	{
		if (ViewCurHP > 0 && (ViewCurHP / (float)ViewMaxHP) < 0.2f)
		{
			PlayBuffer(34, 0, 0);
		}
	}

	if (ViewMaxHP > 0)
	{
		fLife = (ViewMaxHP - ViewCurHP) / (float)ViewMaxHP;
	}
	if (ViewMaxMP > 0)
	{
		fMana = (ViewMaxMP - ViewCurMP) / (float)ViewMaxMP;
	}

#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	height = 43.f, width = 45.5f;
	//--
	int Anim = (int)(timeGetTime() * 0.5f) % 1200 / 100;
	int AnimX = (Anim % 3);
	int AnimY = (Anim / 3);
	//-- Life
	X[0] = frame_cx + 144.f; Y[0] = GetWindowsY - 49.f;
	X[1] = frame_cx + 451.f; Y[1] = GetWindowsY - 49.f;

	fY[0] = Y[0] + (fLife * height);
	fH[0] = height - (fLife * height);
	fV = fLife;
	//--
	u[0] = 0.0 + (128.f * AnimX); v[0] = fV * 96.f + (128.f * AnimY);
	uw[0] = 102.f; vh[0] = (1.0f - fV) * 96.f;

	//-- Mana
	fY[1] = Y[1] + (fMana * height);
	fH[1] = height - (fMana * height);
	fV = fMana;

	u[1] = 0.0 + (128.f * AnimX); v[1] = fV * 96.f + (128.f * AnimY);
	uw[1] = 102.f; vh[1] = (1.0f - fV) * 96.f;
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	height = 51.f, width = 52.5f;
	//-- Life
	X[0] = frame_cx + 98.f; Y[0] = GetWindowsY - 51.f;
	X[1] = frame_cx + 488.5f; Y[1] = GetWindowsY - 51.f;

	fY[0] = Y[0] + (fLife * height);
	fH[0] = 52.f - (fLife * 52.f);
	fV = fLife;
	//--
	u[0] = 0.0; v[0] = fV * width;
	uw[0] = width; vh[0] = (1.0f - fV) * width;
	//-- Mana
	fY[1] = Y[1] + (fMana * height);
	fH[1] = height - (fMana * height);
	fV = fMana;
	//--
	u[1] = 0.0; v[1] = fV * height;
	uw[1] = height; vh[1] = (1.0f - fV) * height;
#else
	height = 39.f, width = 45.f;
	//-- Life
	X[0] = frame_cx + 158.f; Y[0] = GetWindowsY - 48.f;
	X[1] = frame_cx + 437.f; Y[1] = GetWindowsY - 48.f;

	fY[0] = Y[0] + (fLife * height);
	fH[0] = height - (fLife * height);
	fV = fLife;

	u[0] = 0.0; v[0] = fV * 39.f;
	uw[0] = 45.f; vh[0] = (1.0f - fV) * 39.f;
	//-- blue 
	fY[1] = Y[0] + (fMana * height);
	fH[1] = height - (fMana * height);
	fV = fMana;
	//--
	u[1] = 0.0; v[1] = fV * 39.f;
	uw[1] = 45.f; vh[1] = (1.0f - fV) * 39.f;
#endif

	EnableAlphaTest(true);
	glColor4f(1.f, 1.f, 1.f, 1.f);

	if (g_isCharacterBuff((DWORD*)(Hero + 1260), 55))
		RenderImageF(31297, X[0], fY[0], width, fH[0], u[0], v[0], uw[0], vh[0]);
	else
		RenderImageF(31298, X[0], fY[0], width, fH[0], u[0], v[0], uw[0], vh[0]);

	RenderImageF(31296, X[1], fY[1], width, fH[1], u[1], v[1], uw[1], vh[1]);

	RenderNumber(X[0] + 25, GetWindowsY - 20.f, ViewCurHP, 0.9f);
	RenderNumber(X[1] + 30, GetWindowsY - 20.f, ViewCurMP, 0.9f);

	EnableAlphaTest(true);
	glColor4f(1.f, 1.f, 1.f, 1.f);

	char strTipText[256];
	if (pCheckInMouse(X[0], Y[0], width, height) == true)
	{
		sprintf_s(strTipText, iGlobalText(GlobalLine, 358), ViewCurHP, ViewMaxHP);
		RenderTipText((int)X[0], (int)Y[0] - 20, strTipText);
		glColor4f(1.f, 1.f, 1.f, 1.f);
	}

	if (pCheckInMouse((int)X[1], Y[1], width, height) == true)
	{
		sprintf_s(strTipText, iGlobalText(GlobalLine, 359), ViewCurMP, ViewMaxMP);
		RenderTipText((int)X[1], (int)Y[1] - 20, strTipText);
		glColor4f(1.f, 1.f, 1.f, 1.f);
	}
}

void CNewUIMainFrame::RenderHeroEnergy(int This)
{
	DWORD dwMaxSkillMana = ViewMaxBP;
	DWORD dwSkillMana = ViewCurBP;

	float fSkillMana = 0.0;

	if (dwMaxSkillMana > 0)
	{
		fSkillMana = (dwMaxSkillMana - dwSkillMana) / (float)dwMaxSkillMana;
	}

	float x, y, width, height;
	float fY, fH, fV, u, v, uw, vh;

	float frame_cx = GetCenterX(640);
	float frame_cy = (float)GetWindowsY - 51.f;
	float Sub = 28.f;

#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	frame_cy = (float)GetWindowsY - 60.f;

	y = frame_cy + 18.f;
	x = frame_cx + 506.f;
	width = 16.0f, height = 38.5f;

	fY = y + (fSkillMana * height);
	fH = height - (fSkillMana * height);
	fV = fSkillMana;

	v = fV * 86.f;
	u = 0.0; uw = 36.f;
	vh = (1.0f - fV) * 86.f;

	Sub = 10.f;
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	y = frame_cy + 6.5f;
	x = frame_cx + 551.5f;
	width = 15.0f, height = 36.f;

	fY = y + (fSkillMana * height);
	fH = height - (fSkillMana * height);
	fV = fSkillMana;

	v = fV * height;
	u = 0.0; uw = width;
	vh = (1.0f - fV) * height;

	Sub = 10.f;
#else
	y = frame_cy + 2.f;
	x = frame_cx + 420.f;
	width = 16.0f, height = 39.f;

	fY = y + (fSkillMana * height);
	fH = height - (fSkillMana * height);
	fV = fSkillMana;

	v = fV * height;
	u = 0.0; uw = width;
	vh = (1.0f - fV) * height;
#endif
	EnableAlphaTest(true);
	glColor4f(1.f, 1.f, 1.f, 1.f);

	RenderImageF(31299, x, fY, width, fH, u, v, uw, vh);

	RenderNumber(x + 8, GetWindowsY - Sub, dwSkillMana, 0.9f);

	char strTipText[256];

	if (pCheckInMouse((int)x, (int)y, (int)width, (int)height) == true)
	{
		sprintf_s(strTipText, iGlobalText(GlobalLine, 214), dwSkillMana, dwMaxSkillMana);
		RenderTipText((int)(x - 20), (int)y - 25, strTipText);
		glColor4f(1.f, 1.f, 1.f, 1.f);
	}
}

void CNewUIMainFrame::RenderHeroShield(int This)
{
	DWORD wMaxShield = ViewMaxSD;
	DWORD wShield = ViewCurSD;

	float fShieldHero = 0.0;

	if (wMaxShield > 0)
	{
		fShieldHero = (wMaxShield - wShield) / (float)wMaxShield;
	}

	float x, y, width, height;
	float fY, fH, fV, u, v, uw, vh;

	float frame_cx = GetCenterX(640);
	float frame_cy = (float)GetWindowsY - 51.f;
	float Sub = 28.f;
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	frame_cy = (float)GetWindowsY - 60.f;
	y = frame_cy + 18.f;

	width = 16.0f, height = 38.5f;
	x = frame_cx + 118.5f;

	fY = y + (fShieldHero * height);
	fH = height - (fShieldHero * height);
	fV = fShieldHero;

	v = fV * 86.f;
	u = 0.0; uw = 36.f;
	vh = (1.0f - fV) * 86.f;

	Sub = 10.f;
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	y = frame_cy + 6.5f;
	x = frame_cx + 73.f;
	width = 15.0f, height = 36.f;

	fY = y + (fShieldHero * height);
	fH = height - (fShieldHero * height);
	fV = fShieldHero;

	v = fV * height;
	u = 0.0; uw = width;
	vh = (1.0f - fV) * height;

	Sub = 10.f;
#else
	y = frame_cy + 2.f;
	x = frame_cx + 204.f;
	width = 16.0f, height = 39.f;

	fY = y + (fShieldHero * height);
	fH = height - (fShieldHero * height);
	fV = fShieldHero;

	v = fV * height;
	u = 0.0; uw = width;
	vh = (1.0f - fV) * height;
#endif
	if (wMaxShield > 0)
	{
		EnableAlphaTest(true);
		glColor4f(1.f, 1.f, 1.f, 1.f);

		RenderImageF(31300, x, fY, width, fH, u, v, uw, vh);

		RenderNumber(x + 8, GetWindowsY - Sub, wShield, 0.9f);

		char strTipText[256];
		if (pCheckInMouse((int)x, (int)y, (int)width, (int)height) == true)
		{
			sprintf_s(strTipText, iGlobalText(GlobalLine, 2037), wShield, wMaxShield);
			RenderTipText((int)(x - 20), (int)y - 25, strTipText);
		}
	}
	//-- aqu� se agrega numero shield = 0
	else
	{
		EnableAlphaTest(true);
		glColor4f(1.f, 1.f, 1.f, 1.f);
		RenderNumber(x + 8, GetWindowsY - Sub, wShield, 0.9f);
	}
}

void CNewUIMainFrame::RenderTipTextExp(int sx, int sy, LPCSTR Text)
{
	RenderTipText((int)sx + GetWindowsCX(640.f), (int)sy + (float)(GetWindowsY - 480.f), Text);
}

void BtnCha_ChangeButton(GLuint uiImageType, float x, float y, float width, float height, float su, float sv)
{
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	float frame_cx = GetCenterX(640);
	float frame_cy = (float)GetWindowsY - 60.f;

	if (uiImageType == 31304)
	{
		RenderImageF(31303, frame_cx + 410, frame_cy + 31.f, 24, 24, 0.0, 54.f, 54.f, 54.f);
	}
#else
	RenderImageD(uiImageType, x + GetCenterX(640), GetWindowsY - 51.f, width, height, su, sv);
#endif
}

void PopUpErrorCheckMsgBox(const char* szErrorMsg, bool bForceDestroy)
{
	MessageBox(NULL, szErrorMsg, NULL, MB_OK);
	SendMessage(NULL, WM_DESTROY, 0, 0);
}

void RenderImageBack(GLuint Image, float x, float y, float width, float height)
{
	if (Image == 31322)
	{
		if (width == 222.f)
		{
			width = 230.f;
		}
		if (height == 429.f)
		{
			RenderImageF(931300, x, y, width, 254.f, 0.0, 0.0, 420.f, 566.f);
			RenderImageF(931301, x, y + 253.5f, width, 175.f, 0.0, 0.0, 420.f, 391.f);
		}
		else if (height > 254.f)
		{
			float vh = ((height - 254.f) / 175.f) * 391.f;

			RenderImageF(931300, x, y, width, 254.f, 0.0, 0.0, 420.f, 566.f);
			RenderImageF(931301, x, y + 253.5f, width, (height - 254.f), 0.0, 0.0, 420.f, vh);
		}
		else
		{
			float vh = (height / 254.f) * 566.f;
			RenderImageF(931300, x, y, width, height, 0.0, 0.0, 420.f, vh);
		}
	}
	else if
		(Image == 31319 //-- newui_msgbox_top
			|| Image == 31320 //-- newui_msgbox_middle
			|| Image == 31321 //-- newui_msgbox_bottom
			|| Image == 31331 //-- newui_Message_03

			|| Image == 31353 //-- newui_item_back01
			|| Image == 31354 //-- newui_item_back04
			|| Image == 31355 //-- newui_item_back02-L
			|| Image == 31356 //-- newui_item_back02-R
			|| Image == 31357 //-- newui_item_back03
			|| Image == 31320 //-- newui_msgbox_middle
			|| Image == 31319 //-- newui_msgbox_top
			|| Image == 31588 //-- newui_option_top
			|| Image == 31589 //-- newui_option_back06(L)
			|| Image == 31590 //-- newui_option_back06(R)
			)
	{
		if (Image == 31357 && y < 384.f)
		{
			float vh = (height / 175.f) * 391.f;

			RenderImageF(931302, x, y, width, height, 0.0, 391.f - vh, 420.f, vh);
		}
		if (Image == 31321)
		{
			float vh = (height / 175.f) * 391.f;

			RenderImageF(931302, x, y, width, height, 0.0, 391.f - vh, 420.f, vh);
		}
	}
	else if (Image == 31339)
	{
		RenderImageF(931315, x, y, width, height, 0.0, 0.0, 44.f, 44.f);
	}
	else if (Image == 31369 || Image == 31374 || Image == 31393) //-- bar zen
	{
		RenderImageF(931316, x, y, 114.f, 21.f, 0.0, 0.0, 256.f, 46.5f);
	}
	else if (Image == 31594 || Image == 31595) //-- Effect
	{
		float uw = (width / 141.f) * 256.f;

		RenderImageF(Image, x, y, width, height, 0.0, 0.0, uw, 52.f);
	}
	else
	{
		BITMAP_t* pText = (BITMAP_t*)CGlobalBitmap(&*(LPVOID*)0x9816AA0, Image);
		float su = 0.5f / pText->Width;
		float sv = 0.5f / pText->Height;
		float v11 = (width - 0.5f) / pText->Width;
		float v12 = (height - 0.5f) / pText->Height;
		float vh = v12 - sv;
		float uw = v11 - su;

		CRenderBitmaps(Image, x, y, width, height, su, sv, uw, vh, 1, 1, 0.0);
	}
}

void RenderButtonV2(int Image, float x, float y, float width, float heith)
{
	float sv = 0.0;

	if (pCheckInMouse((int)x, (int)y, (int)width, (int)heith))
	{
		sv += (MouseLButton) ? 108.f : 54.f;
	}

	RenderImageF(Image, x, y, width, heith, 0.0, sv, 53.5f, 53.5f);
}

void CNewUIMainFrame::RenderCharFrame(int This)
{
	POINT m_Pos;
	m_Pos.x = *(DWORD*)(This + 16);
	m_Pos.y = *(DWORD*)(This + 20);

	RenderImageB(31322, m_Pos.x, m_Pos.y, 190.f, 429.f);
	//--
	if (ViewPoint > 0)
	{
		RenderImageF(931303, m_Pos.x + 100.f, m_Pos.y + 53.f, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	}
	RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + 53.f, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	//--
	RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + HEIGHT_STRENGTH, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + HEIGHT_DEXTERITY, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + HEIGHT_VITALITY, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + HEIGHT_ENERGY, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);

	int iBaseClass = GetBaseClass(*(BYTE*)(Hero + 19));

	if (iBaseClass == 4)
	{
		RenderImageF(931304, m_Pos.x + 11.f, m_Pos.y + HEIGHT_CHARISMA, 71.f, 18.f, 0.0, 0.0, 160.f, 40.f);
	}

	glColor4f(0.0f, 0.0f, 0.0f, 0.5f);
	int iH = (iFontSize / g_fScreenRate_y);

	//-- tableta
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 75.f, 150.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 88.f, 150.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 101.f, 150.f, iH, 0, 0.0);
	//-- fuerza
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 144.f, 129.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 158.f, 129.f, iH, 0, 0.0);
	//-- agilidad
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 199.f, 129.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 212.f, 129.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 225.f, 129.f, iH, 0, 0.0);
	//-- vitalidad
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 264.f, 129.f, iH, 0, 0.0);
	//-- energi
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 319.f, 129.f, iH, 0, 0.0);
	RenderColor1(m_Pos.x + 15.f, m_Pos.y + 332.f, 129.f, iH, 0, 0.0);
	//--
	EndRenderColor();
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	if (ViewPoint > 0)
	{
		RenderButtonV2(931305, m_Pos.x + 120.f, m_Pos.y + HEIGHT_STRENGTH - 2.f, 24.f, 24.f);
		RenderButtonV2(931305, m_Pos.x + 120.f, m_Pos.y + HEIGHT_DEXTERITY - 2.f, 24.f, 24.f);
		RenderButtonV2(931305, m_Pos.x + 120.f, m_Pos.y + HEIGHT_VITALITY - 2.f, 24.f, 24.f);
		RenderButtonV2(931305, m_Pos.x + 120.f, m_Pos.y + HEIGHT_ENERGY - 2.f, 24.f, 24.f);
		if (iBaseClass == 4)
		{
			RenderButtonV2(931305, m_Pos.x + 140.f, m_Pos.y + HEIGHT_CHARISMA - 2.f, 24.f, 24.f);
		}
	}
}

int ConvertTexture(int image)
{
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	switch (image)
	{
	case 31370: //-- exit
		image = 931306;
		break;
	case 31371: //-- repair
		image = 931307;
		break;
	case 31375:
		image = 931308;
		break;
	case 31376:
		image = 931314;
		break;
	case 31419: //-- mix
		image = 931309;
		break;
	case 31413: //-- setzen
		image = 931310;
		break;
	case 31414: //-- getzen
		image = 931311;
		break;
	case 31415: //-- lock
		image = 931312;
		break;
	case 31416: //-- lock
		image = 931313;
		break;
	case 31748: //-- expansion
		image = 931317;
		break;
	}
#else
	switch (image)
	{
	case 31303: //-- CashShop
		image = 361552;
		break;
	case 31304: //-- Character
		image = 361551;
		break;
	case 31305: //-- Inventory
		image = 361550;
		break;
	case 31306: //-- Friend
		image = 361548;
		break;
	case 31307: //-- Menu Windows
#if ( EMULADOR_INTERFACE == 3)
		image = 361549;
#else
		image = 361553;
#endif
		break;
	}
#endif
	return image;
}

void RnederButtonV1(GLuint uiImageType, float x, float y, float width, float height, float su, float sv, DWORD color)
{
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	if (uiImageType != ConvertTexture(uiImageType))
	{
		if (sv == 24.0)
		{
			sv = 108.f;
		}
		if (sv == 35.0)
		{
			sv = 108.f;
		}
		RenderImageF(ConvertTexture(uiImageType), x, y, width, height, 0.0, sv, 53.5f, 53.5f);
	}
	else if (uiImageType >= 31303 && uiImageType <= 31307) //-- button main interface
	{
		if (sv == 22.f || sv == 24.0) //-- fix button cashshop
		{
			sv = 54.f;
		}
		if (sv == 44.f || sv == 48.0) //-- fix button cashshop
		{
			sv = 110.f;
		}
		RenderImageF(uiImageType, x, y, width, height, su, sv, 52.f, 52.f);
	}
	else if (uiImageType == 31325) //-- boton cerrar
	{
		if (sv == 30.0)
		{
			sv = 54.f;
		}
		if (sv == 60.0)
		{
			sv = 108.f;
		}
		RenderImageF(931325, x, y, width, height, 0.0, sv, 122.f, 53.5f);
	}
	else if (uiImageType == 31326)
	{
		if (sv == 29.0)
		{
			sv = 54.f;
		}
		if (sv == 58.0)
		{
			sv = 108.f;
		}
		RenderImageF(931324, x, y, width, height, 0.0, sv, 294.5f, 53.5f);
	}
	else
	{
		RenderImageE(uiImageType, x, y, width, height, su, sv, color);
	}
#else
	if (uiImageType != ConvertTexture(uiImageType))
	{
		if (sv == 50 || sv == 44 || sv == 40)
		{
			RenderImage3F(ConvertTexture(uiImageType), x, y, width, height);
		}
	}
	else if (uiImageType == 31303 || uiImageType == 31304
		|| uiImageType == 31305 || uiImageType == 31306)
	{
		if (sv == 22.f)
		{
			sv = 54.f;
		}
		if (sv == 44.f)
		{
			sv = 110.f;
		}
		RenderImageF(uiImageType, x, y, width, height, su, sv, 52.f, 52.f);
	}
	else
	{
		RenderImageE(uiImageType, x, y, width, height, su, sv, color);
	}
#endif
}

void RenderMenuButton(int This)
{
	float m_x, m_y, m_w, m_h;

	m_x = *(float*)(This + 44);
	m_y = *(float*)(This + 48);
	m_w = *(float*)(This + 52);
	m_h = *(float*)(This + 56);

	int m_EventState = *(int*)(This + 80);

	RenderImageF(931324, m_x, m_y, m_w, m_h, 0.0, m_EventState * 54.f, 294.5f, 53.5f);
}

void CNewUIMainFrame::SystemMenuMsgBox_Render(int This)
{
	RenderMenuButton(This + 76);
	RenderMenuButton(This + 160);
	RenderMenuButton(This + 244);
	RenderMenuButton(This + 328);
	RenderMenuButton(This + 412);

	((void(__thiscall*)(int)) 0x007A84D0)(This);
}

void CNewUIMainFrame::ChangeButtonInfoD(BYTE* This, int x, int y, int sx, int sy)
{
	sub_778FA0(This, x, y);
	if ((sx == 36 && sy == 29) || (sx == 44 && sy == 35))
	{
		sub_778FD0(This, 24, 24);
	}
	else
	{
		sub_778FD0(This, sx, sy);
	}
}

__declspec(naked) void ShadowColorCheck()
{
	static DWORD jmpBack = 0x007DB30F;

	__asm
	{
		mov     eax, [ebp - 0x1C]
		movzx   ecx, byte ptr[eax + 0x60]
		mov     byColorState, ecx
		jmp[jmpBack]
	}
}

void ShadowColorChange(DWORD a, float x, float y, float w, float h)
{
	RenderImageB(a, x, y, w, h);

	if (byColorState > 0 && byColorState < 6)
	{
		if (byColorState == ITEM_COLOR_NORMAL)
		{
			glColor4f(0.3f, 0.5f, 0.5f, 0.11f);
		}
		else if (byColorState == ITEM_COLOR_DURABILITY_50)
		{
			glColor4f(1.0f, 1.0f, 0.f, 0.09f);
		}
		else if (byColorState == ITEM_COLOR_DURABILITY_70)
		{
			glColor4f(1.0f, 0.66f, 0.f, 0.09f);
		}
		else if (byColorState == ITEM_COLOR_DURABILITY_80)
		{
			glColor4f(1.0f, 0.33f, 0.f, 0.09f);
		}
		else if (byColorState == ITEM_COLOR_DURABILITY_100)
		{
			glColor4f(1.0f, 0.f, 0.f, 0.09f);
		}
		else if (byColorState == ITEM_COLOR_TRADE_WARNING)
		{
			glColor4f(1.0f, 0.2f, 0.1f, 0.09f);
		}
	}
	else if (byColorState != -1)
	{
		glColor4f(0.8f, 0.8f, 0.8f, 0.09f);
	}

	if (byColorState != -1)
	{
		RenderColor1(x + 1.f, y + 1.f, w, h + 2.f, 0.0, 0);
		EndRenderColor();
		glColor4f(1.f, 1.f, 1.f, 1.f);
	}

	byColorState = -1;
}

void RenderFrameControl(float x, float y, float w, int number, float space)
{
	float h = 80.f / (460.f / w);

	RenderImageF(931321, x, y, w, h, 0.0, 0.0, 460.f, 79.f);

	y += h;
	for (int i = 0; i < number; ++i)
	{
		float vh = (space / h) * 79.f;
		RenderImageF(931319, x, y, w, space, 0.0, vh, 460.f, vh);
		y += space;
	}
	RenderImageF(931318, x, y, w, h, 0.0, 2.0, 460.f, 77.f);
}

void CNewUIMainFrame::RenderOptFrame(int This)
{
	float x, y;
	x = (float)*(signed int*)(This + 16);
	y = (float)*(signed int*)(This + 20);

	RenderFrameControl(x, y, 190.f, 19, 10.f);
}

void CNewUIMainFrame::RenderMixFrame(int This)
{
	POINT m_Pos = MsgBox_GetPos(This);

	RenderFrameControl(m_Pos.x, m_Pos.y, 230.f, 11, 20.f);
}

void RenderCheckBox(int Image, float x, float y, float width, float height, float su, float sv)
{
	RenderImageF(931322, x, y, width, height, 0.0, (sv == 15.f) ? 29.5f : 0.0, 29.5f, 29.5f);
}

void Render_NextBack(GLuint uiImageType, float x, float y, float width, float height)
{
	RenderBitmap(31054, x, y, 190.0, 256.0, 0.0, 0.0, 0.7421875, 1.0, 1, 1, 0.0);
	y += 256;
	RenderBitmap(31055, x, y, 190.0, 177.0, 0.0, 0.0, 0.7421875, 0.69140625, 1, 1, 0.0);
}

void RenderMiddleBar(GLuint uiImageType, float x, float y, float width, float height)
{
}

void RenderNoImage(GLuint uiImageType, float x, float y, float width, float height)
{
}

__declspec(naked) void InventoryItemBox()
{
	static DWORD jmpBack = 0x007DB30F;

	__asm
	{
		mov     eax, [ebp - 0x1C]
		movzx   ecx, byte ptr[eax + 0x60]
		mov     byColorState, ecx
		jmp[jmpBack]
	}
}

void InventoryBoxPain(DWORD a, float x, float y, float w, float h)
{
	switch (byColorState)
	{
	case ITEM_COLOR_NORMAL:
		RenderImage3F(31072, x, y, w, h);
		break;
	case ITEM_COLOR_DURABILITY_50:
		RenderImageE(31072, x, y, w, h, 1.0f, 1.0f, Color4f(255, 255, 0, 102));
		break;
	case ITEM_COLOR_DURABILITY_70:
		RenderImageE(31072, x, y, w, h, 1.0f, 1.0f, Color4f(255, 168, 0, 102));
		break;
	case ITEM_COLOR_DURABILITY_80:
		RenderImageE(31072, x, y, w, h, 1.0f, 1.0f, Color4f(255, 84, 0, 102));
		break;
	case ITEM_COLOR_DURABILITY_100:
		RenderImageE(31072, x, y, w, h, 1.0f, 1.0f, Color4f(255, 0, 0, 102));
		break;
	case ITEM_COLOR_TRADE_WARNING:
		RenderImageE(31072, x, y, w, h, 1.0f, 1.0f, Color4f(255, 51, 0, 102));
		break;
	default:
		RenderImage3F(31071, x, y, w, h);
		break;
	}

	byColorState = -1;
}

void CNewUIMainFrame::Guild_OpenProcess(int This)
{
	((void(__thiscall*)(int)) 0x007CA4D0)(This);

	MainFrame_SetBtnState(*(DWORD*)(GetInstance() + 28), 3, 1);
}

void CNewUIMainFrame::Guild_CloseProcess(int This)
{
	((void(__thiscall*)(int)) 0x007CA560)(This);

	MainFrame_SetBtnState(*(DWORD*)(GetInstance() + 28), 3, 0);
}

void CNewUIMainFrame::Party_OpenProcess(int This)
{
	((void(__thiscall*)(int)) 0x0084A1E0)(This);
	MainFrame_SetBtnState(*(DWORD*)(GetInstance() + 28), 0, 1);
}

void CNewUIMainFrame::Party_CloseProcess(int This)
{
	((void(__thiscall*)(int)) 0x0084A260)(This);
	MainFrame_SetBtnState(*(DWORD*)(GetInstance() + 28), 0, 0);
}

void CNewUIMainFrame::Init(void)
{
	SetCompleteHook(0xE9, 0x00895600, &FixNumberPotion);
	SetCompleteHook(0xE9, 0x00895600, &FixNumberPotion);
	SetCompleteHook(0xE8, 0x00810F45, &FixNumberExperience);
	SetCompleteHook(0xE8, 0x008117EE, &FixNumberExperience);
	SetCompleteHook(0xE8, 0x008119E6, &BtnCha_ChangeButton); //-- character
	SetCompleteHook(0xE8, 0x00811B1A, &BtnCha_ChangeButton); //-- friend
	SetCompleteHook(0xE8, 0x00811B61, &BtnCha_ChangeButton); //-- friend
	SetCompleteHook(0xE8, 0x0080F250, &CNewUIMainFrame::LoadImages);
	SetCompleteHook(0xE9, 0x0080F8E0, &CNewUIMainFrame::RenderFrame);
	//--
	SetCompleteHook(0xE8, 0x00810FE7, &CNewUIMainFrame::RenderTipTextExp);
	SetCompleteHook(0xE8, 0x00811890, &CNewUIMainFrame::RenderTipTextExp);
	SetCompleteHook(0xE8, 0x0080F855, &CNewUIMainFrame::RenderHeroEnergy);
	SetCompleteHook(0xE8, 0x0080F84D, &CNewUIMainFrame::RenderHeroShield);
	SetCompleteHook(0xE8, 0x0080F845, &CNewUIMainFrame::RenderHeroLifeMana);
	//-- finish customcape
	SetCompleteHook(0xE8, 0x00614AEF, &PopUpErrorCheckMsgBox);//-- open texture model
	SetCompleteHook(0xE8, 0x00772460, &PopUpErrorCheckMsgBox);//-- open texture

#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	SetCompleteHook(0xE9, 0x00849757, 0x00849872);
	SetCompleteHook(0xE8, 0x00849A52, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x00849AAD, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x00849B10, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x00849B6C, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x00849BD0, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x00849C2C, &RenderCheckBox);
	SetCompleteHook(0xE8, 0x007A9F8E, &CNewUIMainFrame::RenderMixFrame);
	SetCompleteHook(0xE8, 0x008491AE, &CNewUIMainFrame::RenderOptFrame);

	SetDword(0x007A866D + 1, 931323); //-- Change Texture Menu System
	SetDword(0x007A86C4 + 1, 931323); //-- Change Texture Menu System
	SetDword(0x007A8721 + 1, 931323); //-- Change Texture Menu System
	SetDword(0x007A877E + 1, 931323); //-- Change Texture Menu System
	SetDword(0x007A87DB + 1, 931323); //-- Change Texture Menu System
	SetCompleteHook(0xE8, 0x007A8316, &CNewUIMainFrame::SystemMenuMsgBox_Render);

	//SetByte(0x00811AC7 + 1, 6); //-- change open friend -> open guild
	//SetByte(0x00811E3C + 1, 6); //-- change open friend -> open guild
	//SetDword(0x0080F625 + 1, 129);//-- Change Tooltip Fried > Guild
	//SetByte(0x00811E7D + 1, 3); //-- change open Menu -> open Party
	//SetDword(0x0080F710 + 1, 128);//-- Change Tooltip Menu > Party
	//SetCompleteHook(0xE8, 0x0080F2E8, &CNewUIMainFrame::BtnCShopChangeButtonInfo);
	//SetCompleteHook(0xE8, 0x0080F3D3, &CNewUIMainFrame::BtnChaInfoChangeButtonInfo);
	//SetCompleteHook(0xE8, 0x0080F4C7, &CNewUIMainFrame::BtnMyInvenChangeButtonInfo);
	//SetCompleteHook(0xE8, 0x0080F5BB, &CNewUIMainFrame::BtnFriendChangeButtonInfo);
	//SetCompleteHook(0xE8, 0x0080F6AF, &CNewUIMainFrame::BtnWindowChangeButtonInfo);

	SetDword(0x0040A7A9 + 3, 1);//-- remove buttom menu & credit
	SetByte(0x0040A7BB + 3, 0); //-- remove buttom menu & credit
	SetByte(0x0040A7BB + 3, 0); //-- remove buttom menu & credit
	SetByte(0x0040A978 + 3, 0); //-- remove buttom menu & credit
	SetByte(0x0086850E + 1, 120); //-- Disable FastMenu (Key U)
	SetByte(0x00834D93 + 1, 0x52); // REPARAR (R)
	SetCompleteHook(0xE9, 0x00895B8D, 0x00895C02); //Disable R poption
	SetCompleteHook(0xE9, 0x00895B8D, 0x00895C0C); //Disable R poption
	SetCompleteHook(0xE9, 0x007D399F, 0x007D39D8); //Disable Quest (T)
	SetCompleteHook(0xE9, 0x0077EB65, 0x0077EC0E); //Disable Quest in character status
	SetCompleteHook(0xE9, 0x007A830B, 0x007A8313); //-- MENU ESC TRANSPARENTE
	//--
	if (gProtect->m_MainInfo.RemoveItem380 == 1)
	{
		MemorySet(0x007AA3BA, 0x90, 0x5); // item 380
		MemorySet(0x007AA39C, 0x90, 0x5); // item 380
		MemorySet(0x007AA9B3, 0x90, 0x5); // item 380
	}
	//-- point level
	SetByte(0x0077FCEB + 2, 18); //-- pos x
	//-- attribute str
	SetByte(0x007801D9 + 1, RT3_SORT_LEFT); //-- iSort
	SetByte(0x00780205 + 2, 15); //-- pos x
	//-- point str
	SetByte(0x0078021B + 1, 60); //-- size
	SetByte(0x0078023A + 2, 18); //-- pos x
	SetByte(0x00780217 + 1, RT3_SORT_RIGHT); //-- iSort
	//-- attribute agi
	SetByte(0x0078190D + 1, RT3_SORT_LEFT); //-- iSort
	SetByte(0x0078193C + 2, 15); //-- pos x
	//-- point agi
	SetByte(0x00781952 + 1, 60); //-- size
	SetByte(0x00781973 + 2, 18); //-- pos x
	SetByte(0x0078194E + 1, RT3_SORT_RIGHT); //-- iSort
	//-- attribute vit
	SetByte(0x00782D15 + 1, RT3_SORT_LEFT); //-- iSort
	SetByte(0x00782D44 + 2, 15); //-- pos x
	//-- point vit
	SetByte(0x00782D5A + 1, 60); //-- size
	SetByte(0x00782D7C + 2, 18); //-- pos x
	SetByte(0x00782D56 + 1, RT3_SORT_RIGHT); //-- iSort
	//-- attribute Ene
	SetByte(0x007830EF + 1, RT3_SORT_LEFT); //-- iSort
	SetByte(0x0078311E + 2, 15); //-- pos x
	//-- point Ene
	SetByte(0x00783134 + 1, 60); //-- size
	SetByte(0x00783155 + 2, 18); //-- pos x
	SetByte(0x00783130 + 1, RT3_SORT_RIGHT); //-- iSort
	//-- attribute Cmd
	SetByte(0x00784B6D + 1, RT3_SORT_LEFT); //-- iSort
	SetByte(0x00784B9C + 2, 15); //-- pos x
	//-- point Cmd
	SetByte(0x00784BB2 + 1, 60); //-- size
	SetByte(0x00784BD4 + 2, 18); //-- pos x
	SetByte(0x00784BAE + 1, RT3_SORT_RIGHT); //-- iSort
	//--
	SetByte(0x0077E94A + 1, 24); //-- Size Button char
	SetByte(0x0077E94C + 1, 24); //-- Size Button char
	SetByte(0x0077E996 + 1, 24); //-- Size Button char
	SetByte(0x0077E998 + 1, 24); //-- Size Button char
	SetByte(0x0077E9E9 + 1, 24); //-- Size Button char
	SetByte(0x0077E9EB + 1, 24); //-- Size Button char
	SetByte(0x0077EA3B + 1, 24); //-- Size Button char
	SetByte(0x0077EA3D + 1, 24); //-- Size Button char
	SetByte(0x0077EA8D + 1, 24); //-- Size Button char
	SetByte(0x0077EA8F + 1, 24); //-- Size Button char
	SetDword(0x0077E964 + 1, 120); //-- PosX Button char
	SetDword(0x0077E9B3 + 2, 120); //-- PosX Button char
	SetDword(0x0077EA05 + 2, 120); //-- PosX Button char
	SetDword(0x0077EA58 + 1, 120); //-- PosX Button char
	SetDword(0x0077EAAA + 2, 120); //-- PosX Button char
	SetDword(0x00784C3B + 3, 0); //-- Render Button
	SetDword(0x00784C44 + 3, 0); //-- Render Button
	SetByte(0x00837942 + 2, 42); //-- posx zen
	SetByte(0x00841F76 + 2, 42); //-- posx store name
	SetByte(0x0084F533 + 2, 38); //-- posx store name
	SetByte(0x0084733C + 2, 15); //-- posx zen Shop
	//--
	SetCompleteHook(0xE9, 0x00790B50, &RenderImageBack); //-- all back
	SetCompleteHook(0xE9, 0x007DB308, &ShadowColorCheck); //Get Slot Type
	SetCompleteHook(0xE8, 0x007DB5D0, &ShadowColorChange); //Draw Inventory Box
	SetCompleteHook(0xE9, 0x00779410, &CNewUIMainFrame::ChangeButtonInfoD);
	SetCompleteHook(0xE8, 0x0077F7EE, &CNewUIMainFrame::RenderCharFrame);
	//--
	SetDword(0x0084936A + 1, (DWORD) & "interface\\EX\\option_effect03.tga");
	SetDword(0x0084938A + 1, (DWORD) & "interface\\EX\\option_effect04.tga");
	//--
	SetDword(0x00836B7A + 1, (DWORD) & "interface\\EX\\item_boots_v2.jpg");
	SetDword(0x00836B9A + 1, (DWORD) & "interface\\EX\\item_cap_v2.jpg");
	SetDword(0x00836BBA + 1, (DWORD) & "interface\\EX\\item_fairy_v2.jpg");
	SetDword(0x00836BDA + 1, (DWORD) & "interface\\EX\\item_wing_v2.jpg");
	SetDword(0x00836BFA + 1, (DWORD) & "interface\\EX\\item_weapon01_v2.jpg");
	SetDword(0x00836C1A + 1, (DWORD) & "interface\\EX\\item_weapon02_v2.jpg");
	SetDword(0x00836C3A + 1, (DWORD) & "interface\\EX\\item_upper_v2.jpg");
	SetDword(0x00836C5A + 1, (DWORD) & "interface\\EX\\item_gloves_v2.jpg");
	SetDword(0x00836C7A + 1, (DWORD) & "interface\\EX\\item_lower_v2.jpg");
	SetDword(0x00836C9A + 1, (DWORD) & "interface\\EX\\item_ring_v2.jpg");
	SetDword(0x00836CBA + 1, (DWORD) & "interface\\EX\\item_necklace_v2.jpg");
#if (EMULADOR_INTERFACE == 1)
	SetCompleteHook(0xE9, 0x0080F84A, 0x0080F852);
#endif
#elif ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	SetDword(0x0080EF6A + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");

#if (EMULADOR_INTERFACE == 3)
	SetCompleteHook(0xE9, 0x0080F84A, 0x0080F852);
	SetDword(0x0080EF0A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_left97.jpg");
	SetDword(0x0080EF4A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_right97.jpg");
#else
	SetDword(0x0080EF0A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_left.jpg");
	SetDword(0x0080EF4A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_right.jpg");
#endif
	SetDword(0x0080EF2A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_middle.jpg");
	SetDword(0x0080EF8A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_Blue.jpg");
	SetDword(0x0080EFAA + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_Green.jpg");
	SetDword(0x0080EFCA + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_Red.jpg");
	SetDword(0x0080EFEA + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_AG.jpg");
	SetDword(0x0080F00A + 1, (DWORD) & "Custom\\InterfaceS2\\Menu_SD.jpg");
	SetDword(0x0080F06A + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");
	SetDword(0x0080F08A + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");
	SetDword(0x0080F0AA + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");
	SetDword(0x0080F0CA + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");
	SetDword(0x0080F0EA + 1, (DWORD) & "Custom\\InterfaceS2\\none.tga");
	SetCompleteHook(0xE9, 0x007DB308, &InventoryItemBox); //Get Slot Type
	SetCompleteHook(0xE8, 0x007DB5D0, &InventoryBoxPain); //Draw Inventory Box
#else
#endif

#if ( EMULADOR_INTERFACE >= 1 && EMULADOR_INTERFACE <= 4 )

#if (EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2)
	SetByte(0x00811AC7 + 1, 6); //-- change open friend -> open guild
	SetByte(0x00811E3C + 1, 6); //-- change open friend -> open guild
	SetByte(0x00811E7D + 1, 3); //-- change open Menu -> open Party
	//--
	SetByte(0x0086014A + 1, 9); //-- Remove Change Button Party
	SetByte(0x0085F2DB + 1, 9); //-- Remove Change Button Party
	SetByte(0x0085EC8C + 1, 9); //-- Remove Change Button Guild
	SetByte(0x0085F9BD + 1, 9); //-- Remove Change Button Guild
	SetDword(0x0080F625 + 1, 129); //-- Change Tooltip Fried > Guild
	SetDword(0x0080F710 + 1, 128); //-- Change Tooltip Menu > Party
	//--
	SetCompleteHook(0xE8, 0x0085F071, &CNewUIMainFrame::Guild_OpenProcess);
	SetCompleteHook(0xE8, 0x0086023B, &CNewUIMainFrame::Guild_CloseProcess);
	SetCompleteHook(0xE8, 0x0085F223, &CNewUIMainFrame::Party_OpenProcess);
	SetCompleteHook(0xE8, 0x00860016, &CNewUIMainFrame::Party_CloseProcess);
#endif
	//--
	SetByte(0x008137AF + 3, 0); //-- remove skill
	SetByte(0x00812AD2 + 3, 0); //-- remove skill

	SetByte(0x0081517A + 1, 2); //-- Activar siempre [0]
	SetByte(0x00815241 + 1, 2); //-- Activar siempre [1]
	SetByte(0x00815320 + 1, 2); //-- Activar siempre [2]
	SetByte(0x008153FF + 1, 2); //-- Activar siempre [3]
	SetByte(0x008154DE + 1, 2); //-- Activar siempre [4]
	//-- inventory
	SetByte(0x007F041C + 1, 0); //-- Remove Border
	SetByte(0x0082C6FC + 1, 0); //-- Remove Border
	SetByte(0x0083513C + 1, 0); //-- Remove Border
	SetByte(0x00842492 + 1, 0); //-- Remove Border
	SetByte(0x00847054 + 1, 0); //-- Remove Border
	SetByte(0x0084F9F4 + 1, 0); //-- Remove Border
	SetByte(0x008575E3 + 1, 0); //-- Remove Border
	SetByte(0x008578A9 + 1, 0); //-- Remove Border
	SetByte(0x008642B9 + 1, 0); //-- Remove Border
	SetByte(0x008642D5 + 1, 0); //-- Remove Border
	SetCompleteHook(0xE8, 0x00779A02, &RnederButtonV1);
	SetCompleteHook(0xE8, 0x0080F5BB, &CNewUIMainFrame::ButtonFriend);
	SetCompleteHook(0xE8, 0x0080F2E8, &CNewUIMainFrame::ButtonCashShop);
	SetCompleteHook(0xE8, 0x0080F4C7, &CNewUIMainFrame::ButtonInventory);
	SetCompleteHook(0xE8, 0x0080F6AF, &CNewUIMainFrame::ButtonMenuWindows);
	SetCompleteHook(0xE8, 0x0080F3D3, &CNewUIMainFrame::ButtonCharacterInfo);
#endif

#if ( EMULADOR_INTERFACE == 3 || EMULADOR_INTERFACE == 4 )
	SetCompleteHook(0xE8, 0x00836EF6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x00836F2A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00836F67, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00836FB0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00836FEF, &RenderNoImage);
	//-- NPC Jerint 70:
	SetCompleteHook(0xE8, 0x00892D64, &RenderMiddleBar);
	SetCompleteHook(0xE8, 0x00894226, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0089425A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00894297, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0089431F, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008942E0, &RenderNoImage);
	//-- NPC Lugar 66:
	SetCompleteHook(0xE8, 0x00893102, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0089313C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00893185, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008931E0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0089322B, &RenderNoImage);
	//-- Desconocido 25:
	SetCompleteHook(0xE8, 0x00884512, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0088454C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00884595, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008845F0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0088463B, &RenderNoImage);
	//-- Desconocido 24:
	SetCompleteHook(0xE8, 0x00882F52, &Render_NextBack);
	SetCompleteHook(0xE8, 0x00882F8C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00882FD5, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00883030, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0088307B, &RenderNoImage);
	//-- Desconocido 26:
	SetCompleteHook(0xE8, 0x008812A2, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008812DC, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00881325, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00881380, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008813CB, &RenderNoImage);
	//-- Desconocido 23:
	SetCompleteHook(0xE8, 0x0087F886, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0087F8BA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0087F8F7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0087F940, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0087F97F, &RenderNoImage);
	//-- Desconocido 19:
	SetCompleteHook(0xE8, 0x00879EE2, &Render_NextBack);
	SetCompleteHook(0xE8, 0x00879F1C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00879F65, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00879FC0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0087A00B, &RenderNoImage);
	//-- Desconocido 20:
	SetCompleteHook(0xE8, 0x008781BC, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008781F0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00878230, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00878282, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008782C8, &RenderNoImage);
	//-- Desconocido 75:
	SetCompleteHook(0xE8, 0x00868052, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0086808C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008680D5, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00868130, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0086817B, &RenderNoImage);
	//-- Desconocido 7:
	SetCompleteHook(0xE8, 0x008643B6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008643EA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00864427, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00864470, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008644AF, &RenderNoImage);
	//-- Desconocido 8:
	SetCompleteHook(0xE8, 0x00857946, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0085797A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008579B7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00857A00, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00857A3F, &RenderNoImage);
	//-- Desconocido 78:
	SetCompleteHook(0xE8, 0x008567E6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0085681A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00856857, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008568A0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008568DF, &RenderNoImage);
	//-- Desconocido 60:
	SetCompleteHook(0xE8, 0x008540B6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008540EA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00854127, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00854170, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008541AF, &RenderNoImage);
	//-- Desconocido 69:
	SetCompleteHook(0xE8, 0x008525B7, &RenderMiddleBar);
	SetCompleteHook(0xE8, 0x00852476, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008524AA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008524E7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00852530, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0085256F, &RenderNoImage);
	//-- Desconocido 68:
	SetCompleteHook(0xE8, 0x00850AA7, &RenderMiddleBar);
	SetCompleteHook(0xE8, 0x00850966, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0085099A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008509D7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00850A20, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00850A5F, &RenderNoImage);
	//-- Desconocido 15:
	SetCompleteHook(0xE8, 0x0084F406, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0084F43A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084F477, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084F4C0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084F4FF, &RenderNoImage);
	//-- Desconocido 11:
	SetCompleteHook(0xE8, 0x0084D01A, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0084D05A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084D0AC, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084D116, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084D16E, &RenderNoImage);
	//-- Desconocido 3:
	SetCompleteHook(0xE8, 0x0084A546, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0084A57A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084A5BA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084A60C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084A652, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x008470A6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x008470DA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00847117, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00847160, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084719F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x00845956, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0084598A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008459C7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00845A10, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00845A4F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x00843826, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0084385A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00843897, &RenderNoImage);
	SetCompleteHook(0xE8, 0x008438E0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0084391F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x00841E49, &Render_NextBack);
	SetCompleteHook(0xE8, 0x00841E7D, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00841EBA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00841F03, &RenderNoImage);
	SetCompleteHook(0xE8, 0x00841F42, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x0083EA46, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0083EA7A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0083EAB7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0083EB00, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0083EB3F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x0082CA22, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0082CA5C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0082CAA5, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0082CB00, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0082CB4B, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x0080C848, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0080C87C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0080C8BC, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0080C90E, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0080C954, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007F65A6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007F65E6, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007F6638, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007F66A2, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007F66FA, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007D55A6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007D55DA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D5617, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D5660, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D569F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007D1786, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007D17BA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D17F7, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D1840, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007D187F, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007CB6F6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007CB72A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007CB767, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007CB7B0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007CB7EF, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007C7D0C, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007C7D46, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C7D89, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C7DD8, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C7E1D, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007C6BCC, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007C6C06, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C6C49, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C6C98, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C6CDD, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007C46E6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007C471A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C4757, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C47A0, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C47DF, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007C2676, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007C26AA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C26EA, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C273C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C2782, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x007C1872, &Render_NextBack);
	SetCompleteHook(0xE8, 0x007C18AC, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C18F5, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C1950, &RenderNoImage);
	SetCompleteHook(0xE8, 0x007C199B, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x0078E6D6, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0078E70A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0078E74A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0078E79C, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0078E7E2, &RenderNoImage);
	//-- Desconocido:
	SetCompleteHook(0xE8, 0x0077F209, &Render_NextBack);
	SetCompleteHook(0xE8, 0x0077F23D, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0077F27A, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0077F2C3, &RenderNoImage);
	SetCompleteHook(0xE8, 0x0077F302, &RenderNoImage);
#endif

}