#include "StdAfx.h"
#include "Util.h"
#include "Protocol.h"
#include "SEASON3B.h"
#include "PetHook.h"
#include "UIControl.h"
#include "CustomPet.h"
#include "NewUIButton.h"
#include "wsclientline.h"
#include "GIPetManager.h"
#include "Protect.h"
#include "NewUIPetInfoWindow.h"
//#include "NewUIInventoryCtrl.h"
#include "NewUIMyInventory.h"
#include "CChatEx.h"

int TypeInventory = 1;
int TimerPost = 0;
EQUIPMENT_ITEM m_Slots[MAX_SLOT_MACHINE - MAX_EQUIPMENT_INDEX];
//--
CNewUIButton m_ChangeNext;
CNewUIButton m_ChangeBack;
CNewUIMyInventory g_pMyInventory;
CCharacterMachine* Character_Machin;

CNewUIMyInventory::CNewUIMyInventory()
{
}

CNewUIMyInventory::~CNewUIMyInventory()
{
}

void SetVirtualKey()
{
	//--
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	SetDword(0x008367B4 + 6, 0x14);
	SetDword(0x008367C1 + 6, 0x14);
	SetDword(0x008367FF + 6, 0x14);
	SetDword(0x0083680C + 6, 0x14);
	SetDword(0x0083684D + 6, 0x14);
	SetDword(0x0083685A + 6, 0x14); //-- 0x1C
#else
	SetDword(0x008367B4 + 6, 0x16);
	SetDword(0x008367C1 + 6, 0x16);
	SetDword(0x008367FF + 6, 0x16);
	SetDword(0x0083680C + 6, 0x16);
	SetDword(0x0083684D + 6, 0x16);
	SetDword(0x0083685A + 6, 0x16); //-- 0x1C
#endif
	//--
	SetByte(0x008367DE + 2, 0x3A); //-- 0x1C //-- posicionx
	SetByte(0x00836829 + 2, 0x3A); //-- 0x1C //-- posicionx
	SetByte(0x00836790 + 2, 0x76); //-- 0x1C //-- posicionx
}


void CNewUIMyInventory::LoadImages()
{
	((void(__cdecl*)())0x00836A60)();

	LoadBitmapA("Interface\\InGameShop\\ingame_Bt_page_L.tga", 32342, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\InGameShop\\ingame_Bt_page_R.tga", 32343, GL_LINEAR, GL_CLAMP, 1, 0);

	//#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )
	LoadBitmapA("Interface\\item_elementslot2_v2.jpg", 65535, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\item_elementslot3_v2.tga", 65536, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\item_earring_v2.tga", 65537, GL_LINEAR, GL_CLAMP, 1, 0);
	LoadBitmapA("Interface\\item_amulet_v2.jpg", 65538, GL_LINEAR, GL_CLAMP, 1, 0);
	//#else
	//		LoadBitmapA("Interface\\inventory_elementslot2.jpg", 65535, GL_LINEAR, GL_CLAMP, 1, 0);
	//		LoadBitmapA("Interface\\inventory_elementslot3.jpg", 65536, GL_LINEAR, GL_CLAMP, 1, 0);
	//		LoadBitmapA("Interface\\newui_item_earring.tga", 65537, GL_LINEAR, GL_CLAMP, 1, 0);
	//		LoadBitmapA("Interface\\inventory_amulet.tga", 65538, GL_LINEAR, GL_CLAMP, 1, 0);
	//#endif

	//g_pBitmap.OpenBitMapTexture();  //--Rune Efectos Via Pentagrama

	Character_Machin = new CCharacterMachine;
}




void SetCharacterEffectEquip(int c)
{
	char v5; // [sp+3h] [bp-5h]@14
	int v3;
	int v6;

	if (*(DWORD*)(c + 824) == 1163)
	{
		int pt = 0; int dt = 0;

		for (int i = 0; i < 3; i++)
		{
			if (i == 0 || i == 1)
			{
				v6 = (DWORD)&Character_Machin->Equipment[i];
			}
			else
			{
				v6 = (DWORD)&Character_Machin->Equipment[EQUIPMENT_WING];
			}
			if (*(WORD*)v6 == 0xFFFF)
			{
				if (i == 0 || i == 1)
				{
					v6 = CharacterMachine_Equipment(i);
				}
				else
				{
					v6 = CharacterMachine_Equipment(EQUIPMENT_WING);
				}
			}
			if (*(WORD*)v6 == 0xFFFF)
				*(WORD*)(c + (pt * 36) + 448) = 0xFFFF;
			else
				*(WORD*)(c + (pt * 36) + 448) = *(WORD*)v6 + 1171;

			*(BYTE*)(c + (pt * 36) + 450) = (*(DWORD*)(v6 + 2) >> 3) & 0xF;
			if (i == 0 || i == 1)
			{
				*(BYTE*)(c + (pt * 36) + 451) = *(BYTE*)(v6 + 23);
				*(BYTE*)(c + (pt * 36) + 452) = *(BYTE*)(v6 + 24);
			}
			pt++;
		}
		v6 = CharacterMachine_Equipment(EQUIPMENT_HELPER);
		if (*(WORD*)v6 == 0xFFFF)
			*(WORD*)(c + 556) = 0xFFFF;
		else
			*(WORD*)(c + 556) = *(WORD*)v6 + 1171;

		v6 = (DWORD)&Character_Machin->Equipment[EQUIPMENT_STONE_MAGIC];

		if (*(WORD*)v6 == 0xFFFF)
		{
			*(WORD*)(c + 592) = 0xFFFF;
		}
		else
		{
			*(WORD*)(c + 592) = *(WORD*)v6 + 1171;
		}
		//--
		v5 = 1;
		if (InChaosCastle(World) == 1)
			v5 = 0;
		if ((signed int)*(WORD*)(c + 794) >= 233 && (signed int)*(WORD*)(c + 794) <= 240)
			v5 = 0;
		if ((signed int)*(WORD*)(c + 794) >= 38 && (signed int)*(WORD*)(c + 794) <= 155)
			v5 = 0;
		if (v5)
			SetPlayerStop(c);
		//--
		pt = 0;
		for (int i = EQUIPMENT_HELM; i <= EQUIPMENT_BOOTS; i++)
		{
			v3 = (DWORD)&Character_Machin->Equipment[i];

			if (*(WORD*)v3 == 0xFFFF)
			{
				v3 = CharacterMachine_Equipment(i);
			}
			if (*(WORD*)v3 == 0xFFFF)
			{
				*(WORD*)(c + (pt * 36) + EQUIP_BODY_HELM) = (unsigned __int8)_GetSkinModelIndex(*(BYTE*)(c + 19)) + (pt * MODEL_BODY_NUM) + MODEL_BODY_HELM;
				*(BYTE*)(c + (pt * 36) + 270) = 0;
				*(BYTE*)(c + (pt * 36) + 271) = 0;
				*(BYTE*)(c + (pt * 36) + 272) = 0;
			}
			else
			{
				*(WORD*)(c + (pt * 36) + EQUIP_BODY_HELM) = *(WORD*)v3 + 1171;
				*(BYTE*)(c + (pt * 36) + 270) = (*(DWORD*)(v3 + 2) >> 3) & 0xF;
				*(BYTE*)(c + (pt * 36) + 271) = *(BYTE*)(v3 + 23);
				*(BYTE*)(c + (pt * 36) + 272) = *(BYTE*)(v3 + 24);
			}
			pt++;
		}
		((void(__cdecl*)(int)) 0x004E6670)(c);
		ZzzCharacter_SetCharacterScale(c);
		if (c == Hero)
			((bool(__cdecl*)(int)) 0x00560D80)(Hero);
		((void(__thiscall*)(int)) 0x005958E0)(*(DWORD*)0x8128AC4);
	}
}

char ResetEquipmentLevel(int This)
{
	int v3; // ST08_4@1

	int pt = 0;
	for (int i = EQUIPMENT_WEAPON_RIGHT; i <= EQUIPMENT_BOOTS; i++)
	{
		v3 = (DWORD)&Character_Machin->Equipment[i];

		if (*(WORD*)v3 == 0xFFFF)
		{
			v3 = CharacterMachine_Equipment(i);
		}
		if (i >= EQUIPMENT_HELM)
		{
			if (*(WORD*)v3 == 0xFFFF)
			{
				*(BYTE*)(Hero + (pt * 36) + 270) = 0;
			}
			else
			{
				*(BYTE*)(Hero + (pt * 36) + 270) = (*(DWORD*)(v3 + 2) >> 3) & 0xF;
			}
			pt++;
		}
		else
		{
			if (*(WORD*)v3 == 0xFFFF)
			{
				*(BYTE*)(Hero + (i * 36) + 450) = 0;
			}
			else
			{
				*(BYTE*)(Hero + (i * 36) + 450) = (*(DWORD*)(v3 + 2) >> 3) & 0xF;
			}
		}
	}
	return ((bool(__cdecl*)(int)) 0x00560D80)(Hero);
}

void CNewUIMyInventory::ReceiveInventory(BYTE* ReceiveBuffer)
{
	Character_Machin->UnequipAllItems();

	LPPHEADER_DEFAULT_SUBCODE_WORD DataRecv = (LPPHEADER_DEFAULT_SUBCODE_WORD)ReceiveBuffer;

	int Offset = sizeof(PHEADER_DEFAULT_SUBCODE_WORD);

	for (int i = 0; i < DataRecv->Value; i++)
	{
		LPPRECEIVE_INVENTORY Data = (LPPRECEIVE_INVENTORY)(ReceiveBuffer + Offset);

		Character_Machin->EquipItem(Data->Index, Data->Item);
		Offset += sizeof(PRECEIVE_INVENTORY);
	}
}

void CNewUIMyInventory::ReceiveDurability(BYTE* ReceiveBuffer)
{
	LPPHEADER_DEFAULT_VALUE_DUR Data = (LPPHEADER_DEFAULT_VALUE_DUR)ReceiveBuffer;
	if (Data->Key != 0xFF)
	{
		zITEM* ip = &Character_Machin->Equipment[Data->Key];
		if (ip->Type != 65535)
		{
			ip->Durability = Data->Value;
		}
	}
}

void CNewUIMyInventory::ReceiveDeleteInventory(BYTE* ReceiveBuffer)
{
	LPPHEADER_DEFAULT_SUBCODE Data = (LPPHEADER_DEFAULT_SUBCODE)ReceiveBuffer;

	if (Data->SubCode != 0xff)
	{
		if (ms_pPickedItem)
		{
			DeletePickedItem();
			return;
		}
		Character_Machin->Unequip_Item(Data->SubCode);
	}

	if (Data->Value)
	{
		//EnableUse = 0;
	}
}

void CNewUIMyInventory::ReceiveItemChange(BYTE* ReceiveBuffer)
{
	LPPSCHANGE_CHARACTER Data = (LPPSCHANGE_CHARACTER)ReceiveBuffer;

	int Key = ((int)(Data->KeyH) << 8) + Data->KeyL;

	int c = CharactersClient(CList(), FindCharacterIndex(Key));

	if (c == NULL) { return; }

	int Type = ConvertItemType(Data->Item);
	BYTE Level = Data->Item[1] & 0xF;
	BYTE Option = Data->Item[3] & 63;
	BYTE ExtOption = Data->Item[4];

	switch (Data->Item[1] >> 4)
	{
	case EQUIPMENT_PENTAGRAM1:
		if (Type == 0x1FFF)
		{
			if (*(DWORD*)(c + 676))
			{
				if (*(WORD*)(c + 484) != 7832)
				{
					giPetManager::DeletePet(c);
				}
			}
			else
			{
				DelectMuunBug(c + 776);
			}
		}
		else
		{
			int Helper_Type = MODEL_ITEM + Type;

			if (gCustomPet2.GetInfoPetType(Type) == 10)
			{
				giPetManager::Create_PetDarkSpirit(c, Helper_Type);
			}
			else
			{
				DelectMuunBug(c + 776);
				CreateMuunBug(Helper_Type, c + 1028, c + 776, 0, 0);
			}
		}
		break;
	case EQUIPMENT_PENTAGRAM2:
		if (Type == 0x1FFF)
		{
			DelectFlyBug(c + 776);
		}
		else
		{
			//DelectFlyBug(c + 776);
			int Helper_Type = MODEL_ITEM + Type;
			DelectFlyBug(c + 776);
			CreateFlyBug(Helper_Type, c + 1028, c + 776, 0, 0);
		}
		break;
	case EQUIPMENT_STONE_MAGIC:
		if (Type == 0x1FFF)
		{
			*(WORD*)(c + 592) = 0xFFFF;
		}
		else
		{
			*(WORD*)(c + 592) = MODEL_ITEM + Type;
		}
		break;
	}

	ChangeChaosCastleUnit(c);
	ZzzCharacter_SetCharacterScale(c);
}

void ButtonSetText(BYTE* This, char* btname)
{
	int std_String[7];
	ChartoString(&std_String, btname);
	NewUIButtonChangeText(This, std_String[0], std_String[1], std_String[2], std_String[3], std_String[4], std_String[5], std_String[6]);
}

void CNewUIMyInventory::SetButtonInfo(DWORD* This)
{
	((void(__thiscall*)(DWORD*))0x00836880)(This);

	UIMyInventory* t = (UIMyInventory*)This;
	int x = t->m_Pos.x;
	int y = t->m_Pos.y;

	m_ChangeBack.Construct();
	m_ChangeNext.Construct();
	//--
	m_ChangeBack.ChangeButtonImgState(1, 32342, 1, 0, 0);
	m_ChangeNext.ChangeButtonImgState(1, 32343, 1, 0, 0);
	m_ChangeBack.CButtonInfo(t->m_Pos.x + 30, t->m_Pos.y + 5, 20, 23);
	m_ChangeNext.CButtonInfo(t->m_Pos.x + 140, t->m_Pos.y + 5, 20, 23);
}

void CNewUIMyInventory::SetEquipmentSlotInfo(UIMyInventory* This)
{
	POINT m_Pos = { This->m_Pos.x, This->m_Pos.y };
	m_ChangeBack.CButtonInfo(m_Pos.x + 30, m_Pos.y + 5, 20, 23);
	m_ChangeNext.CButtonInfo(m_Pos.x + 140, m_Pos.y + 5, 20, 23);

	MyInventory_SetEquipmentSlotInfo(This);
	//-- nuevo
#if (MAX_SLOT_MACHINE > EQUIPMENT_PENTAGRAM1)
	m_Slots[EQUIPMENT_PENTAGRAM1 - 12].x = m_Pos.x + 58;
	m_Slots[EQUIPMENT_PENTAGRAM1 - 12].y = m_Pos.y + 45;
	m_Slots[EQUIPMENT_PENTAGRAM1 - 12].width = 18;
	m_Slots[EQUIPMENT_PENTAGRAM1 - 12].height = 18;
	m_Slots[EQUIPMENT_PENTAGRAM1 - 12].dwBgImage = 65535;
#endif
	//-- nuevo
#if (MAX_SLOT_MACHINE > EQUIPMENT_PENTAGRAM2)
	m_Slots[EQUIPMENT_PENTAGRAM2 - 12].x = m_Pos.x + 118;
	m_Slots[EQUIPMENT_PENTAGRAM2 - 12].y = m_Pos.y + 175;
	m_Slots[EQUIPMENT_PENTAGRAM2 - 12].width = 20;
	m_Slots[EQUIPMENT_PENTAGRAM2 - 12].height = 20;
	m_Slots[EQUIPMENT_PENTAGRAM2 - 12].dwBgImage = 65536;
#endif
	//--
#if (MAX_SLOT_MACHINE > EQUIPMENT_ERRING_RIGHT)
	m_Slots[EQUIPMENT_ERRING_RIGHT - 12].x = m_Pos.x + 58;
	m_Slots[EQUIPMENT_ERRING_RIGHT - 12].y = m_Pos.y + 129;
	m_Slots[EQUIPMENT_ERRING_RIGHT - 12].width = 20;
	m_Slots[EQUIPMENT_ERRING_RIGHT - 12].height = 20;
	m_Slots[EQUIPMENT_ERRING_RIGHT - 12].dwBgImage = 65537;
#endif
	//--
#if (MAX_SLOT_MACHINE > EQUIPMENT_ERRING_LEFT)
	m_Slots[EQUIPMENT_ERRING_LEFT - 12].x = m_Pos.x + 118;
	m_Slots[EQUIPMENT_ERRING_LEFT - 12].y = m_Pos.y + 129;
	m_Slots[EQUIPMENT_ERRING_LEFT - 12].width = 20;
	m_Slots[EQUIPMENT_ERRING_LEFT - 12].height = 20;
	m_Slots[EQUIPMENT_ERRING_LEFT - 12].dwBgImage = 65537;
#endif
	//--
#if (MAX_SLOT_MACHINE > EQUIPMENT_STONE_MAGIC)
	m_Slots[EQUIPMENT_STONE_MAGIC - 12].x = m_Pos.x + 58;
	m_Slots[EQUIPMENT_STONE_MAGIC - 12].y = m_Pos.y + 175;
	m_Slots[EQUIPMENT_STONE_MAGIC - 12].width = 18;
	m_Slots[EQUIPMENT_STONE_MAGIC - 12].height = 18;
	m_Slots[EQUIPMENT_STONE_MAGIC - 12].dwBgImage = 65538;
#endif
}

void CNewUIMyInventory::RenderFrame(UIMyInventory* This)
{
	float x, y;
	x = This->m_Pos.x;
	y = This->m_Pos.y;
	//--
	MyInventory_RenderFrame(This);
	m_ChangeBack.Render();
	m_ChangeNext.Render();
}

void CNewUIMyInventory::RenderEquipped(GLuint uiImageType, float x, float y, float width, float height)
{
#if ( EMULADOR_INTERFACE == 1 || EMULADOR_INTERFACE == 2 )

	if (uiImageType == 31358 || uiImageType == 31359 || uiImageType == 31360
		|| uiImageType == 31365 || uiImageType == 31366 || uiImageType == 61550)
	{
		RenderImage3F(uiImageType, x, y, width - 2, height - 3); //-- cuadrados
	}
	else if (uiImageType == 31362 || uiImageType == 31363 || uiImageType == 31364)
	{
		RenderImage3F(uiImageType, x, y, width - 2, height - 4); //-- centrales
	}
	else if (uiImageType == 31367 || uiImageType == 31368) //-- ring pendals
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
	else if (uiImageType == 31361)
	{
		RenderImage3F(uiImageType, x, y, width - 2, height - 3); //--  wings
	}
	else
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
#else
	if (uiImageType == 31358 || uiImageType == 31359 || uiImageType == 31360
		|| uiImageType == 31365 || uiImageType == 31366 || uiImageType == 61550)
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
	else if (uiImageType == 31362 || uiImageType == 31363 || uiImageType == 31364)
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
	else if (uiImageType == 31361)
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
	else
	{
		RenderImage3F(uiImageType, x, y, width, height);
	}
#endif
}

void CNewUIMyInventory::RenderEquippedItem(UIMyInventory* This)
{
	int  InitPointed = (TypeInventory == 1) ? EQUIPMENT_WEAPON_RIGHT : EQUIPMENT_HELPER;
	int m_iPointedSlot = This->m_iPointedSlot;

	int v32 = (int)This;
	float cx, cy, width, height;
	BYTE byFirstClass = GetBaseClass(*(BYTE*)(Hero + 19));

	for (int i = 0; i < MAX_SLOT_MACHINE; i++)
	{
		if ((i == EQUIPMENT_HELM && byFirstClass == 3)
			|| (i == EQUIPMENT_GLOVES && byFirstClass == 6))
		{
			continue;
		}

		EnableAlphaTest(true);
		if (i < MAX_EQUIPMENT_INDEX)
		{
			height = (double)*((signed int*)v32 + 5 * i + 14);
			width = (double)*((signed int*)v32 + 5 * i + 13);
			cy = (double)*((signed int*)v32 + 5 * i + 12);
			cx = (double)*((signed int*)v32 + 5 * i + 11);
			RenderEquipped(*((DWORD*)v32 + 5 * i + 15), cx, cy, width, height);
		}
		else
		{
			height = (double)m_Slots[i - MAX_EQUIPMENT_INDEX].height;
			width = (double)m_Slots[i - MAX_EQUIPMENT_INDEX].width;
			cy = (double)m_Slots[i - MAX_EQUIPMENT_INDEX].y;
			cx = (double)m_Slots[i - MAX_EQUIPMENT_INDEX].x;
			RenderEquipped(m_Slots[i - MAX_EQUIPMENT_INDEX].dwBgImage, cx, cy, width, height);
		}
		DisableAlphaBlend();

		int v41;
		if ((i >= EQUIPMENT_WEAPON_RIGHT && i < InitPointed) || i >= MAX_EQUIPMENT_INDEX)
		{
			v41 = (DWORD)&Character_Machin->Equipment[i];
		}
		else
		{
			v41 = CharacterMachine_Equipment(i);
		}

		if (*(WORD*)v41 != 0xFFFF)
		{
			ITEM_ATTRIBUTE* pItemAttr = ItemAttribute(*(WORD*)v41);
			int iLevel = (*(DWORD*)(v41 + 2) >> 3) & 15;
			int iMaxDurability = calcMaxDurability(v41, pItemAttr, iLevel);

			if (i != 11 && i != 10 || (*(WORD*)v41 != 6676 || iLevel != 1) && iLevel != 2)
			{
				if (*(BYTE*)(v41 + 97) != 1 || *(BYTE*)(v41 + 98))
				{
					if ((signed int)*(BYTE*)(v41 + 22) > 0)
					{
						if ((double)iMaxDurability * 0.2f < (double)*(BYTE*)(v41 + 22))
						{
							if ((double)iMaxDurability * 0.3f < (double)*(BYTE*)(v41 + 22))
							{
								if ((double)iMaxDurability * 0.5 < (double)*(BYTE*)(v41 + 22))
								{
									if ((i >= EQUIPMENT_WEAPON_RIGHT && i < InitPointed)
										|| i >= MAX_EQUIPMENT_INDEX)
									{
										if (Character_Machin->IsEquipable(i, (zITEM*)v41))
											continue;
									}
									else
									{
										if (Is_EquipItem(i, v41))
											continue;
									}
									glColor4f(1.0, 0.0, 0.0, 0.25);
								}
								else
								{
									glColor4f(1.0, 1.0, 0.0, 0.25);
								}
							}
							else
							{
								glColor4f(1.0, 0.5, 0.0, 0.25);
							}
						}
						else
						{
							glColor4f(1.f, 0.15f, 0.f, 0.25f);
						}
					}
					else
					{
						glColor4f(1.0, 0.0, 0.0, 0.25);
					}
					EnableAlphaTest(true);
					RenderColor1(cx + 1, cy + 1, width - 4, height - 4, 0.0, 0);
					EndRenderColor();
				}
			}
		}
	}

	int pPickedItem = GetPickedItem();

	if (pPickedItem)
	{
		if (m_iPointedSlot != -1)
		{
			int v23 = pPicked_GetItem(pPickedItem); int v24;

			if (v23)
			{
				bool equipa = false;
				if ((m_iPointedSlot >= EQUIPMENT_WEAPON_RIGHT && m_iPointedSlot < InitPointed) || m_iPointedSlot >= MAX_EQUIPMENT_INDEX)
				{
					equipa = Character_Machin->IsEquipable(m_iPointedSlot, (zITEM*)v23);
					v24 = (DWORD)&Character_Machin->Equipment[m_iPointedSlot];
				}
				else
				{
					equipa = Is_EquipItem(m_iPointedSlot, v23);
					v24 = CharacterMachine_Equipment(m_iPointedSlot);
				}

				if ((*(WORD*)v24 != 0xFFFF || !equipa)
					&& ((byFirstClass != 6 || m_iPointedSlot != 5) && (byFirstClass != 3 || m_iPointedSlot != 2)))
				{
					glColor4f(0.89999998, 0.1, 0.1, 0.40000001);

					if (m_iPointedSlot >= MAX_EQUIPMENT_INDEX)
					{
						height = (double)m_Slots[m_iPointedSlot - 12].height;
						width = (double)m_Slots[m_iPointedSlot - 12].width;
						cy = (double)m_Slots[m_iPointedSlot - 12].y;
						cx = (double)m_Slots[m_iPointedSlot - 12].x;
					}
					else
					{
						height = (double)(*(DWORD*)(v32 + 20 * m_iPointedSlot + 56));
						width = (double)(*(DWORD*)(v32 + 20 * m_iPointedSlot + 52));
						cy = (double)*(signed int*)(v32 + 20 * m_iPointedSlot + 48);
						cx = (double)(*(DWORD*)(v32 + 20 * m_iPointedSlot + 44));
					}
					EnableAlphaTest(true);
					RenderColor1(cx + 1, cy + 1, width - 4, height - 4, 0.0, 0);
					EndRenderColor();
				}
			}
		}
	}
	else
	{
		if (m_iPointedSlot != -1 && *(DWORD*)(v32 + 20))
		{
			if (m_iPointedSlot != *(DWORD*)(v32 + 1032))
			{
				if (m_iPointedSlot == 8)
				{
					if (*(WORD*)(*(DWORD*)0x8128AC4 + 5528) == 6660)
					{
						CStreamPacketEngine spe;
						spe.Init(0xC1, 0xA9);
						spe.Rightshift1(1);
						spe.Rightshift1(0);
						spe.Rightshift1(8);
						spe.Send(0, 0);
					}
				}
				else if (m_iPointedSlot == 1 && TypeInventory == 1)
				{
					if (*(WORD*)(*(DWORD*)0x8128AC4 + 4779) == 6661)
					{
						CStreamPacketEngine spe;
						spe.Init(0xC1, 0xA9);
						spe.Rightshift1(01);
						spe.Rightshift1(0);
						spe.Rightshift1(1);
						spe.Send(0, 0);
					}
				}
			}
			RenderUI2DEffect(*(DWORD*)(v32 + 20), 5.5, UI2DEffectCallEquip, (LPVOID)v32, m_iPointedSlot, 0);
		}
	}
}

void CNewUIMyInventory::RenderItemToolTip(int This, int iSlotIndex)
{
	int InitPointed = (TypeInventory == 1) ? EQUIPMENT_WEAPON_RIGHT : EQUIPMENT_HELPER;
	int m_iPointedSlot = *(DWORD*)(This + 284);

	if (m_iPointedSlot != -1)
	{
		int v24;
		if ((m_iPointedSlot >= EQUIPMENT_WEAPON_RIGHT && m_iPointedSlot < InitPointed) || m_iPointedSlot >= MAX_EQUIPMENT_INDEX)
		{
			v24 = (DWORD)&Character_Machin->Equipment[m_iPointedSlot];
		}
		else
		{
			v24 = CharacterMachine_Equipment(m_iPointedSlot);
		}

		int targetcx, targetcy;
		if (*(WORD*)v24 != 0xFFFF)
		{
			*(BYTE*)(v24 + 66) = iSlotIndex;
			if (m_iPointedSlot >= MAX_EQUIPMENT_INDEX)
			{
				targetcx = m_Slots[m_iPointedSlot - 12].x + m_Slots[m_iPointedSlot - 12].width / 2;
				targetcy = m_Slots[m_iPointedSlot - 12].y + m_Slots[m_iPointedSlot - 12].height / 2;
			}
			else
			{
				targetcx = *(DWORD*)(This + 20 * m_iPointedSlot + 44) + (*(DWORD*)(This + 20 * m_iPointedSlot + 52) / 2);
				targetcy = *(DWORD*)(This + 20 * m_iPointedSlot + 48) + (*(DWORD*)(This + 20 * m_iPointedSlot + 56) / 2);
			}

			if (*(DWORD*)(This + 1020))
			{
				RenderRepairInfo(targetcx, targetcy, v24, false);
			}
			else
			{
				RenderItemInfo_(GetUI3D(GetInstance()), targetcx, targetcy, v24, false, 0, false);
			}
		}
	}
}

bool CNewUIMyInventory::EquipmentWindowProcess(UIMyInventory* This)
{
	if (m_ChangeBack.UpdateMouseEvent())
	{
		TypeInventory = (TypeInventory == 1) ? 2 : 1;
		PlayBuffer(25, 0, 0);
		return true;
	}
	if (m_ChangeNext.UpdateMouseEvent())
	{
		TypeInventory = (TypeInventory == 2) ? 1 : 2;
		PlayBuffer(25, 0, 0);
		return true;
	}
	int m_iPointedSlot = This->m_iPointedSlot;
	int InitPointed = (TypeInventory == 1) ? EQUIPMENT_WEAPON_RIGHT : EQUIPMENT_HELPER;

	if (Character_Machin->UnEquipmentWindowProcess(m_iPointedSlot, TypeInventory))
	{
		return true;
	}

	if ((m_iPointedSlot >= EQUIPMENT_WEAPON_RIGHT && m_iPointedSlot < InitPointed) || m_iPointedSlot >= MAX_EQUIPMENT_INDEX)
	{
		if (Character_Machin->EquipmentWindowProcess())
		{
			return true;
		}
	}
	else
	{
		if (m_iPointedSlot != -1 && IsRelease(VK_LBUTTON))
		{
			int pPickedItem = GetPickedItem();

			if (pPickedItem)
			{
				int pOwner = GetOwnerInventory(pPickedItem);
				if (pOwner == NULL)
				{
					zITEM* ip = (zITEM*)pPicked_GetItem(pPickedItem);

					if (ip->ex_src_type == ITEM_EX_SRC_EQUIPMENT2 && EquipmentItem == false)
					{
						if (Is_EquipItem(m_iPointedSlot, (int)ip))
						{
							if (GetSourceLinealPos(GetPickedItem()) == m_iPointedSlot)
							{
								SendRequestEquipment(40, ip->lineal_pos, (int)ip, 0, m_iPointedSlot);
								return true;
							}
							BackupPickedItem();
						}
					}
				}
			}
		}
		return MyInventory_EquipmentWindowProcess(This);
	}
	return false;
}



void CNewUIMyInventory::Render3D(signed int* This)  //--renderisa los item en el inventario
{
	float height; // ST0C_4@7
	float width; // ST08_4@7
	float x; // ST00_4@7
	float y; // [sp+34h] [bp-Ch]@5
	signed int* v5; // [sp+30h] [bp-10h]@1
	int v7; // [sp+38h] [bp-8h]@3
	signed int i; // [sp+3Ch] [bp-4h]@1

	v5 = This;
	int  InitPointed = (TypeInventory == 1) ? EQUIPMENT_WEAPON_RIGHT : EQUIPMENT_HELPER;

	for (i = 0; i < MAX_SLOT_MACHINE; ++i)
	{
		if (i < MAX_EQUIPMENT_INDEX)
		{
			v7 = (i < InitPointed) ? (DWORD)&Character_Machin->Equipment[i] : CharacterMachine_Equipment(i);
			
			if ((signed int)*(WORD*)v7 >= 0)
			{
				y = (i == 3) ? ((double)v5[24] - 10.0) : ((double)v5[5 * i + 9]);
			
				glColor4f(1.0, 1.0, 1.0, 1.0);
				height = (double)(v5[5 * i + 11] - 4);
				width = (double)(v5[5 * i + 10] - 4);
				x = (double)(v5[5 * i + 8] + 1);
				CRenderItem3D(x, y, width, height, *(WORD*)v7, *(DWORD*)(v7 + 2), *(BYTE*)(v7 + 23), *(BYTE*)(v7 + 24), 0);
			}
		}
		else
		{
			v7 = (DWORD)&Character_Machin->Equipment[i];
		
			if ((signed int)*(WORD*)v7 >= 0)
			{
				int j = i - MAX_EQUIPMENT_INDEX;
				y = (double)m_Slots[j].y;
				glColor4f(1.0, 1.0, 1.0, 1.0);
				height = (double)(m_Slots[j].height - 4);
				width = (double)(m_Slots[j].width - 4);
				x = (double)m_Slots[j].x + 1;
				CRenderItem3D(x, y, width, height, *(WORD*)v7, *(DWORD*)(v7 + 2), *(BYTE*)(v7 + 23), *(BYTE*)(v7 + 24), 0);
			}
		}

	}



}



void CNewUIMyInventory::RenderDetailsText(int This, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{
	char pszText_1[256];

	if (TypeInventory == 2)
	{
		sprintf_s(pszText_1, "Visual", pszText);
	}
	else
	{
		sprintf_s(pszText_1, "%s", pszText);
	}

	((void(__thiscall*)(int, int, int, LPCSTR, int, int, int, OUT SIZE*))0x00420150)(
		This, iPos_x, iPos_y, pszText_1, iBoxWidth, iBoxHeight, iSort, lpTextSize);
}

bool CNewUIMyInventory::Update(DWORD* a1)
{
	int i, v5;
	DWORD* v3; signed int j;

	v3 = a1; v5 = 0;
	for (i = sub_83CBE0(a1); v5 < i; i = sub_83CBE0(v3))
	{
		if (v3[v5 + 6] && !MyInventory_Update((void*)v3[v5 + 6]))
			return 0;
		++v5;
	}
	if ((unsigned __int8)(*(int(__thiscall**)(DWORD*))(*v3 + 24))(v3))
	{
		v3[71] = -1;
		for (j = 0; j < MAX_SLOT_MACHINE; ++j)
		{

			if (j >= MAX_EQUIPMENT_INDEX)
			{
				if (pCheckInMouse(m_Slots[j - MAX_EQUIPMENT_INDEX].x + 1, m_Slots[j - MAX_EQUIPMENT_INDEX].y,
					m_Slots[j - MAX_EQUIPMENT_INDEX].width - 4, m_Slots[j - MAX_EQUIPMENT_INDEX].height - 4))
				{
					v3[71] = j;
					return 1;
				}
			}
			else
			{
				if (pCheckInMouse(v3[5 * j + 11] + 1, v3[5 * j + 12], v3[5 * j + 13] - 4, v3[5 * j + 14] - 4))
				{
					v3[71] = j;
					return 1;
				}
			}
			v3[71] = -1;
		}
	}
	return 1;
}

void CNewUIMyInventory::Backup_PickedItem()
{
	if (ms_pPickedItem && EquipmentItem == false)
	{
		int pOwner = GetOwnerInventory(ms_pPickedItem);
		int v9 = (int)GetMouseItem(ms_pPickedItem);
		if (pOwner)
		{
			pOwner_AddItem(pOwner, *(BYTE*)(v9 + 67), *(BYTE*)(v9 + 68), v9);
			DeletePickedItem();
		}
		else if (*(BYTE*)(v9 + 68) == ITEM_EX_SRC_EQUIPMENT1)
		{
			char* v8 = (char*)(*(DWORD*)0x8128AC4 + 107 * *(BYTE*)(v9 + 67) + 4672);
			memcpy(v8, (const void*)v9, 0x6Bu);
			gObjCreatePetEx((int)v8);

			if (*(WORD*)v8 == 6661 && !InChaosCastle(World))
			{
				CStreamPacketEngine spe;
				spe.Init(0xC1, 0xA9);
				spe.Rightshift1(0);
				spe.Rightshift1(0);
				spe.Rightshift1(1);
				spe.Send(0, 0);

				PET_INFO* pPetInfo = giPetManager::GetPetInfo((int)v8);
				giPetManager::CreatePetDarkSpirit_Now(Hero);
				giPetManager::SetPetInfo(*(DWORD*)(Hero + 676), pPetInfo);
			}
			if (*(WORD*)v8 == 6660 && !InChaosCastle(World))
			{
				CStreamPacketEngine spe;
				spe.Init(0xC1, 0xA9);
				spe.Rightshift1(1);
				spe.Rightshift1(0);
				spe.Rightshift1(8);
				spe.Send(0, 0);
			}
			DeletePickedItem();
		}
		else if (*(BYTE*)(v9 + 68) == ITEM_EX_SRC_EQUIPMENT2)
		{
			BYTE lineal_pos = *(BYTE*)(v9 + 67);
			char* v8 = (char*)&Character_Machin->Equipment[lineal_pos];

			memcpy(v8, (const void*)v9, 0x6Bu);
			EffectEquiping(lineal_pos, (zITEM*)v8);
			DeletePickedItem();
			((void(__cdecl*)(int)) 0x0057F410)(Hero);
		}
	}
}

__declspec(naked) void Inventory_Process()
{
	static DWORD ex_src_type = -1;
	static DWORD addrjmp = 0x00838E7E;
	_asm
	{
		mov     edx, dword ptr ss : [ebp - 0x20]
		movzx   eax, byte ptr ds : [edx + 0x44]
		mov     ex_src_type, eax
	}

	if (ex_src_type == ITEM_EX_SRC_EQUIPMENT1 || ex_src_type == ITEM_EX_SRC_EQUIPMENT2)
	{
		addrjmp = 0x00838E7E;
	}
	else
	{
		addrjmp = 0x00838F24;
	}

	_asm
	{
		jmp[addrjmp]
	}
}

bool SendInventoryEquip(BYTE iSrcType, BYTE iSrcIndex, int ip, BYTE iDstType, BYTE iDstIndex)
{
	zITEM* IP = (zITEM*)ip;
	if (IP->ex_src_type == ITEM_EX_SRC_PETINVENTORY)
	{
		iSrcType = 22;
	}
	else if (IP->ex_src_type == ITEM_EX_SRC_EQUIPMENT2)
	{
		iSrcType = REQUEST_EQUIPMENT;
	}
	return SendRequestEquipment(iSrcType, iSrcIndex, ip, iDstType, iDstIndex);
}

int FindItemOwner(void* This, int v24)
{
	if (v24 == NULL)
	{
		return -1;
	}
	signed int i; // eax@1
	int v9; // [sp+0h] [bp-8h]@1
	int v10;

	v10 = 0; v9 = -1;
	int a7 = 0;
	for (i = sub_83CBE0(This); a7 < i; i = sub_83CBE0(This))
	{
		if (FindItemAtPt_ctrl(*((DWORD**)This + a7 + 6), MouseX, MouseY) == v24)
		{
			v9 = (int)(*((DWORD**)This + a7 + 6));
			break;
		}
		++a7;
	}
	return v9;
}

BOOL right_click_send(void* control, int iSrcType, int iDstType)
{
	BOOL Arc = !TRUE;

	if (IsPress(VK_RBUTTON) && GetRepairMode() != REPAIR_MODE_ON && EquipmentItem == false)
	{
		ResetMouseRButton();

		int owner = 0;
		int cItem, iSrcIndex, iDstIndex = -1;
		int This = GetUINewMyInventory();

		cItem = (iSrcType != 0) ? (FindItemAtPt_ctrl(control, MouseX, MouseY)) : (FindItemAtPt((void*)This, MouseX, MouseY, &owner));

		if (cItem)
		{

			if (iDstType == LuckyItemWnd_SetWndAction(Get_NewUILuckyItemWnd(GetInstance()), 1) && !LuckyItemWnd_Check_LuckyItem(Get_NewUILuckyItemWnd(GetInstance()), cItem))
			{
				return TRUE;
			}

			if (iDstType == GetMixInventoryEquipmentIndex(g_MixRecipeMgr) && !IsMixSource(g_MixRecipeMgr, cItem))
			{
				return TRUE;
			}

			if (iSrcType != 0)
			{
				iSrcIndex = FindBaseIndexByITEM(control, cItem);
			}
			else
			{
				iSrcIndex = FindBaseIndexByITEM(*(void**)(This + 4 * *(DWORD*)(This + 984) + 24), cItem);
				iSrcIndex = GetInventSTargetLinealPos(This, iSrcIndex, *(DWORD*)(This + 984));
			}

			if (iSrcType != 0)
			{
				iDstIndex = MyFindEmptySlot(This, cItem, 0);
				owner = (int)control;
			}
			else
			{
				ITEM_ATTRIBUTE* tk = ItemAttribute(*(WORD*)cItem);
				iDstIndex = FindEmptySlot_ctrl(control, tk->Width, tk->Height);
				owner = FindItemOwner((void*)This, cItem);
			}

			if (iDstIndex >= 0 && iSrcIndex >= 0)
			{
				if (CreatePickedItem(owner, (const void*)cItem))
				{
					if (iSrcType != 0)
					{
						RemoveItem_ctrl((int)control, cItem);
					}
					else
					{
						RemoveItemForSlot(This, iSrcIndex);
					}

					if (iDstType == 0) iDstIndex += 12;

					if (iSrcType == 0) iSrcIndex += 12;

					SendRequestEquipment(iSrcType, iSrcIndex, pPicked_GetItem(GetPickedItem()), iDstType, iDstIndex);
					HidePickedItem(GetPickedItem());

					Arc = TRUE;
				}
			}
		}
	}
	return Arc;
}

bool CNewUIMyInventory::InventoryProcess(int This)
{
	if (g_pNewUISystem->IsVisible(7) || g_pNewUISystem->IsVisible(8)) //-- bauls
	{
		goto LABEL_45;
	}

	if (g_pNewUISystem->IsVisible(9))
	{
		int Machine = pGetUIChaosMachine(GetInstance());
		int MixRecipe = GetMixInventoryEquipmentIndex(g_MixRecipeMgr);

		if (pCheckInMouse(*(DWORD*)(Machine + 20), *(DWORD*)(Machine + 24), 190, 429))
		{
			if (right_click_send((void*)*(DWORD**)(Machine + 16), MixRecipe, 0))
			{
				return true;
			}
		}
		else
		{
			if (right_click_send((void*)*(DWORD**)(Machine + 16), 0, MixRecipe))
			{
				return true;
			}
		}
	}
	else if (g_pNewUISystem->IsVisible(76))
	{
		int LuckyThis = Get_NewUILuckyItemWnd(GetInstance());

		int LuckyActive = LuckyItemWnd_SetWndAction(LuckyThis, 1);

		if (pCheckInMouse(*(DWORD*)(LuckyThis + 888), *(DWORD*)(LuckyThis + 892), 190, 429))
		{
			if (LuckyItemWnd_Check_LuckyItem_InWnd(LuckyThis))
			{
				if (right_click_send((void*)*(DWORD**)(LuckyThis + 16), LuckyActive, 0))
				{
					return 0;
				}
			}
		}
		else
		{
			if (right_click_send((void*)*(DWORD**)(LuckyThis + 16), 0, LuckyActive))
			{
				return 0;
			}
		}
	}

	if (!pCheckInMouse(0, 0, CGetScreenWidth2(), 429))
	{
		if (IsRepeat(VK_CONTROL) && IsPress(VK_RBUTTON) && GetRepairMode() != REPAIR_MODE_ON && EquipmentItem == false)
		{
			if (g_pNewUISystem->IsVisible(7) || g_pNewUISystem->IsVisible(8) || g_pNewUISystem->IsVisible(9)
				|| g_pNewUISystem->IsVisible(12) || g_pNewUISystem->IsVisible(14) || g_pNewUISystem->IsVisible(15)
				|| g_pNewUISystem->IsVisible(78)) //-- bauls
			{
				goto LABEL_45;
			}
	
			if (GetPickedItem() == NULL)
			{
				ResetMouseRButton();
	
				if (GetTickCount() >= (TimerPost + 500))
				{
	
					int iSrcIndex, v7; zITEM* ip;
	
					ip = (zITEM*)FindItemAtPt((void*)This, MouseX, MouseY, &v7);
	
					if (ip != NULL)
					{
						iSrcIndex = GetSlotIndexAtPt(ip->x, ip->y, v7);
	
						//if (gJewelsBank.IsOpen())
						//{
						//	//MessageBox(0,"Joyas Enviadas","Error",MB_OK | MB_ICONERROR);
						//	SendRequestEquipment(60, iSrcIndex + 12, (int)ip, 60, iSrcIndex + 12);
						//}
						//else
						//{
						//	SendRequestEquipment(50, iSrcIndex + 12, (int)ip, 50, iSrcIndex + 12);
						//}
						TimerPost = GetTickCount();
					}
				}
				return true;
			}
		}
		else
		{
			if (IsRelease(VK_LBUTTON) && EquipmentItem == false)
			{
	
				if (g_pNewUISystem->IsVisible(7) || g_pNewUISystem->IsVisible(8) || g_pNewUISystem->IsVisible(9)
					|| g_pNewUISystem->IsVisible(12) || g_pNewUISystem->IsVisible(14) || g_pNewUISystem->IsVisible(15)
					|| g_pNewUISystem->IsVisible(78)) //-- bauls
				{
					goto LABEL_45;
				}
			}
			else if (IsPress(VK_RBUTTON) && GetRepairMode() != REPAIR_MODE_ON && EquipmentItem == false)
			{
				if (GetPickedItem() == NULL)
				{
					int v24, v7; int iSrcType, iSrcIndex, iDstType, nDstIndex;
					bool bEquipable = false;
	
					if (g_pNewUISystem->IsVisible(7) || g_pNewUISystem->IsVisible(8)) //-- bauls
					{
						goto LABEL_45;
					}
					else
					{
						ResetMouseRButton(); v7 = -1;
						zITEM* ip;
						int Machine = pGetUIChaosMachine(GetInstance());
						bEquipable = false; int pOwner = NULL;
						int MixRecipe = GetMixInventoryEquipmentIndex(g_MixRecipeMgr);
	
						if (g_pNewUISystem->IsVisible(9)) //-- chaos machine
						{
							if (pCheckInMouse(*(DWORD*)(Machine + 20), *(DWORD*)(Machine + 24), 190, 429))
							{
								ip = (zITEM*)FindItemAtPt_ctrl((void*)*(DWORD**)(Machine + 16), MouseX, MouseY);
								if (ip)
								{
									iSrcType = MixRecipe;
									iSrcIndex = ip->x + ip->y * 8;
									iDstType = REQUEST_INVENTORY;
									nDstIndex = MyFindEmptySlot(This, (int)ip, 0);
	
									if (nDstIndex != -1)
									{
										bEquipable = true;
										pOwner = (int)(*(DWORD**)(Machine + 16));
									}
								}
							}
							else
							{
								ip = (zITEM*)FindItemAtPt((void*)This, MouseX, MouseY, &v7);
	
								if (ip)
								{
									if (IsMixSource(g_MixRecipeMgr, (int)ip))
									{
										ITEM_ATTRIBUTE* pItemAttr = ItemAttribute(ip->Type);
										iSrcType = REQUEST_INVENTORY;
										iSrcIndex = GetSlotIndexAtPt(ip->x, ip->y, v7);
										iDstType = MixRecipe;
										nDstIndex = FindEmptySlot_ctrl((void*)*(DWORD*)(Machine + 16), pItemAttr->Width, pItemAttr->Height);
	
										if (nDstIndex != -1)
										{
											bEquipable = true;
											pOwner = FindItemOwner((void*)This, (int)ip);
										}
									}
								}
							}
						}
						else
						{
							ip = (zITEM*)FindItemAtPt((void*)This, MouseX, MouseY, &v7);
	
							if (ip)
							{
								iSrcType = REQUEST_INVENTORY;
								iSrcIndex = GetSlotIndexAtPt(ip->x, ip->y, v7);
								ITEM_ATTRIBUTE* pItemAttr = ItemAttribute(ip->Type);
	
								nDstIndex = pItemAttr->m_byItemSlot;
	
								if ((nDstIndex >= 0 && nDstIndex < 12) || Character_Machin->isSlotSecond1(nDstIndex))
								{
									if (TypeInventory == 1)
										iDstType = (Character_Machin->isSlotSecond1(nDstIndex)) ? REQUEST_EQUIPMENT : REQUEST_INVENTORY;
									else
										iDstType = (Character_Machin->isSlotSecond1(nDstIndex)) ? REQUEST_EQUIPMENT : REQUEST_INVENTORY;
	
									if (iDstType == REQUEST_INVENTORY)
									{
										bEquipable = Is_EquipItem(nDstIndex, (int)ip);
										v24 = CharacterMachine_Equipment(nDstIndex);
	
										if (*(WORD*)v24 != 0xFFFF && ((nDstIndex == 0 && !pItemAttr->TwoHand) || nDstIndex == 10))
										{
											nDstIndex += 1;
											v24 = CharacterMachine_Equipment(nDstIndex);
										}
	
										if (*(WORD*)v24 != 0xFFFF)
										{
											bEquipable = false;
										}
									}
									else if (iDstType == REQUEST_EQUIPMENT)
									{
										nDstIndex = Character_Machin->SlotConvert(nDstIndex);
	
										bEquipable = Character_Machin->IsEquipable(nDstIndex, ip);
	
										v24 = (DWORD)&Character_Machin->Equipment[nDstIndex];
	
										if (*(WORD*)v24 != 0xFFFF && nDstIndex == 0 && !pItemAttr->TwoHand)
										{
											nDstIndex += 1;
											v24 = (DWORD)&Character_Machin->Equipment[nDstIndex];
										}
	
										if (*(WORD*)v24 != 0xFFFF)
										{
											bEquipable = false;
										}
									}
								}
								else
								{
									bEquipable = false;
								}
	
								if (bEquipable == true)
								{
									pOwner = FindItemOwner((void*)This, (int)ip);
								}
							}
						}
	
						if (bEquipable == true)
						{
							if (pOwner)
							{
								if (CreatePickedItem(pOwner, ip))
								{
									if (iSrcType == REQUEST_INVENTORY || iSrcType == REQUEST_EQUIPMENT)
									{
										RemoveItemForSlot(This, iSrcIndex);
										SendRequestEquipment(iSrcType, iSrcIndex + 12, (int)ip, iDstType, nDstIndex);
									}
									else if (iSrcType == MixRecipe)
									{
										RemoveItem_ctrl(pOwner, (int)ip);
										SendRequestEquipment(iSrcType, iSrcIndex, (int)ip, iDstType, nDstIndex + 12);
									}
									HidePickedItem(GetPickedItem());
									playSound(29, 0, 0);
									return true;
								}
							}
						}
					}
				}
			}
		}
	}
LABEL_45:
	return ((bool(__thiscall*)(int)) 0x00838240)(This);
}

bool CNewUIMyInventory::NewUIManager_Render(int thls)
{
	bool ActiveObject = false;
	glAlphaFunc(GL_GREATER, 0.0f);

	ActiveObject = ((bool(__thiscall*)(int)) 0x00815DB0)(thls);

	glAlphaFunc(GL_GREATER, 0.25f);

	return ActiveObject;
}

void CNewUIMyInventory::Init()
{
	//--
	SetVirtualKey();
	SetCompleteHook(0xE9, 0x00838E6E, &Inventory_Process);
	SetCompleteHook(0xE8, 0x00838F15, &SendInventoryEquip);
	//--
	SetCompleteHook(0xE9, 0x00834FD0, &CNewUIMyInventory::Update);
	SetCompleteHook(0xE9, 0x008353D0, &CNewUIMyInventory::Render3D);       //-- inventori 2 crea item //--renderisa los item
	SetCompleteHook(0xE8, 0x008337B8, &CNewUIMyInventory::SetButtonInfo);  //--botones
	SetCompleteHook(0xE8, 0x00835CDB, &CNewUIMyInventory::RenderItemToolTip);
	SetCompleteHook(0xE8, 0x00837902, &CNewUIMyInventory::RenderDetailsText);
	SetCompleteHook(0xE8, 0x0083514C, &CNewUIMyInventory::RenderEquippedItem);
	//--
	SetCompleteHook(0xE8, 0x00834682, &CNewUIMyInventory::EquipmentWindowProcess);
	//SetCompleteHook(0xE8, 0x0083469C, &CNewUIMyInventory::InventoryProcess); //--Bug Post Item
	//--
	SetCompleteHook(0xE8, 0x008337A8, &CNewUIMyInventory::LoadImages);
	SetCompleteHook(0xE8, 0x0083510E, &CNewUIMyInventory::RenderFrame);
	SetCompleteHook(0xE8, 0x008370EE, &CNewUIMyInventory::RenderEquipped);
	SetCompleteHook(0xE8, 0x008337B0, &CNewUIMyInventory::SetEquipmentSlotInfo);
	SetCompleteHook(0xE8, 0x0083443C, &CNewUIMyInventory::SetEquipmentSlotInfo);
	//--
	SetCompleteHook(0xE8, 0x007850BA, &ResetEquipmentLevel);
	SetCompleteHook(0xE9, 0x0057F410, &SetCharacterEffectEquip);
	SetCompleteHook(0xE9, 0x007DD230, &CNewUIMyInventory::Backup_PickedItem);  //--botar El item
	//SetCompleteHook(0xE8, 0x00860B2F, &CNewUIMyInventory::NewUIManager_Render);
}