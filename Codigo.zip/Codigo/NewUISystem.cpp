#include "StdAfx.h"
#include "Util.h"
#include "SEASON3B.h"
#include "NewUISystem.h"

CNewUISystem::CNewUISystem()
{
}

CNewUISystem::~CNewUISystem()
{
}

bool CNewUISystem::IsVisible(DWORD dwKey)
{
	return CNewUISystem_IsVisible(GetInstance(), dwKey);
}

void CNewUISystem::Hide(DWORD dwKey)
{
	CNewUISystem_HideSystem(GetInstance(), dwKey);
}

void CNewUISystem::Show(DWORD dwKey)
{
	CNewUISystem_ShowSystem(GetInstance(), dwKey);
}

void CNewUISystem::ShowInterface(DWORD dwKey, bool bShow)
{
	CNewUIManager_ShowInterface(GetNewUIManager((void*)GetInstance()), dwKey, bShow);
}

void CNewUISystem::Toggle(DWORD dwKey)	//. Show <-> Hide
{
	CNewUISystem_ToggleSystem(GetInstance(), dwKey);
}

void CNewUISystem::HideAll()
{
	CNewUISystem_HideAll(GetInstance());
}

int CNewUISystem::GetUI_NewMyInventory()
{
	return CNewUISystem_GetUI_NewMyInventory(GetInstance());
}

int CNewUISystem::GetOwnerMyInventory()
{
	return CNewUISystem_GetInventoryCtrl((void*)*(DWORD*)(GetInstance() + 40), GetOwnerInventory(GetPickedItem()));
}

int CNewUISystem::GetTargetOwnerMyInventory()
{
	return CNewUISystem_GetTargetInventoryCtrl((void*)*(DWORD*)(GetInstance() + 40), (WORD**)GetPickedItem());
}

int CNewUISystem::GetOwnerShopInventory()
{
	return MyShop_pNewInventoryCtrl(*(DWORD*)(GetInstance() + 84));
}

int CNewUISystem::GetOwnerMyTrade()
{
	return Trade_pNewInventoryCtrl(*(DWORD*)(GetInstance() + 124));
}

int CNewUISystem::GetOwnerMixInventory()
{
	return MyMix_pNewInventoryCtrl(*(DWORD*)(GetInstance() + 52));
}

//bool OpenWindowKey(int iVirtKey)
//{
//	if (IsPress('J'))
//	{
//		if (*(BYTE*)(Hero + 21) == 32 || *(BYTE*)(Hero + 21) == 8)
//		{
//			ToggleGui(INTERFACE_GUI_MAKE);
//			PlayBuffer(25, 0, 0);
//		}
//	}
//	return IsPress(VK_TAB);
//}
//
//bool CNewUISystem::Create(int* This)
//{
//	CNewGUISystem::Instance()->Create();
//
//
//
//	return CNewUISystem_Create(This);
//}
//
//bool CNewUISystem::LoadMainSceneInterface(int* This)
//{
//	bool Arc = CNewUISystem_LoadMainSceneInterface(This);
//
//	CNewGUISystem::Instance()->InitMainScene();
//
//	return Arc;
//}
//
//void CNewUISystem::NewUIManager_HideAll(int This)
//{
//	CNewGUISystem::Instance()->HideAll();
//
//	((void(__thiscall*)(int)) 0x008606B0)(This);
//}
//
//bool CNewUISystem::NewUIManager_CheckMouseUse(int This)
//{
//	bool Arc;
//
//	Arc = ((bool(__thiscall*)(int)) 0x00860A60)(This);
//
//	if (Arc == false)
//	{
//		Arc = CNewGUISystem::Instance()->CheckMouseUse();
//	}
//
//	return Arc;
//}
//
//bool CNewUISystem::NewUIManager_CheckKeyUse(int This)
//{
//	bool Arc;
//
//	Arc = ((bool(__thiscall*)(int)) 0x00860A90)(This);
//
//	if (!Arc)
//	{
//		Arc = CNewGUISystem::Instance()->CheckKeyUse();
//	}
//
//	return Arc;
//}
//
//bool CNewUISystem::NewUIManager_Update(int This)
//{
//	bool Arc, Arc2;
//
//	Arc = ((bool(__thiscall*)(int)) 0x00860AC0)(This);
//
//	Arc2 = CNewGUISystem::Instance()->Update();
//
//	if (!Arc)
//	{
//		Arc = Arc2;
//	}
//
//	return Arc;
//}
//
//bool CNewUISystem::NewUIManager_Render(int This)
//{
//	bool Arc = false;
//
//	glAlphaFunc(GL_GREATER, 0.0f);
//
//	Arc = ((bool(__thiscall*)(int)) 0x00860B10)(This);
//
//	CNewGUISystem::Instance()->Render();
//
//	glAlphaFunc(GL_GREATER, 0.25f);
//
//	return Arc;
//}
//
//bool CNewUISystem::CanUpdateKeyEvent(int This)
//{
//	if (GetUI_NewGuiMake->RemoveKeyDown())
//	{
//		return false;
//	}
//
//	return ((bool(__thiscall*)(int)) 0x007D4250)(This);
//}
//
//LONG FAR PASCAL SendCrcOfFunction(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
//{
//
//
//	return ((LONG(__stdcall*)(HWND, UINT, WPARAM, LPARAM)) 0x004D0030)(hwnd, uMsg, wParam, lParam);
//}

void CNewUISystem::Init()
{

	//SetByte(0x008606D3 + 3, 111); //--revisar
	//SetCompleteHook(0xE8, 0x007D35A8, &OpenWindowKey);
	//SetDword(0x004D0E14 + 3, (DWORD)&SendCrcOfFunction);
	//SetCompleteHook(0xE8, 0x004D2A04, &CNewUISystem::Create);
	//SetCompleteHook(0xE8, 0x007D378E, &CNewUISystem::CanUpdateKeyEvent);
	//SetCompleteHook(0xE8, 0x00811C42, &CNewUISystem::CanUpdateKeyEvent);
	//SetCompleteHook(0xE8, 0x004D9344, &CNewUISystem::NewUIManager_Update);
	//SetCompleteHook(0xE8, 0x004D9CC2, &CNewUISystem::NewUIManager_Render);
	//SetCompleteHook(0xE8, 0x004D58A0, &CNewUISystem::LoadMainSceneInterface);
	//SetCompleteHook(0xE8, 0x004D935C, &CNewUISystem::NewUIManager_CheckMouseUse);
	//SetCompleteHook(0xE8, 0x005B67B9, &CNewUISystem::NewUIManager_CheckMouseUse);
	//SetCompleteHook(0xE8, 0x005B832F, &CNewUISystem::NewUIManager_CheckMouseUse);
	//SetCompleteHook(0xE8, 0x005CF380, &CNewUISystem::NewUIManager_CheckMouseUse);
	//--
	//SetCompleteHook(0xE8, 0x004D6CF7, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x004E14F3, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0063E4C9, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0063EF07, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00641021, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0064BE83, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0064BF85, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0064C566, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0064C6CD, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00654255, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00654D25, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00659051, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x006595BD, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00659618, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00659ED8, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0065F55C, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0065F63A, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0065F706, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00666D16, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0085F7EF, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x00872549, &CNewUISystem::NewUIManager_HideAll);
	//SetCompleteHook(0xE8, 0x0091CC15, &CNewUISystem::NewUIManager_HideAll);
}