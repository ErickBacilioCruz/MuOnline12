#include "StdAfx.h"
#include "zzCharacter.h"


zzCharacter::zzCharacter(void)
{
}


zzCharacter::~zzCharacter(void)
{
}
