#include "StdAfx.h"
#include "_struct.h"
#include "SEASON3B.h"
#include "NewUISystem.h"
#include "wsclientline.h"
#include "PrintPlayer.h"
#include "zzCharacter.h"
#include "CustomPet.h"
#include "GIPetManager.h"
#include "NewUIPetInfoWindow.h"
#include "CharacterMachine.h"

CCharacterMachine::CCharacterMachine(void)
{
}

CCharacterMachine::~CCharacterMachine(void)
{
}

int GetUINewChatLogWindow()
{
	return ((int(__thiscall*)(int))0x00861180)(GetInstance());
}

int GetUINewMyInventory()
{
	return ((int(__thiscall*)(int))0x00861260)(GetInstance());
}

int GetRepairMode()
{
	return ((int(__thiscall*)(int))0x00834550)(GetUINewMyInventory());
}

zITEM* CreateItem(void* lp)
{
	return CreateItemConvert(*(DWORD*)(GetInstance() + 36), lp);
}

void SendRequest_Dismantle(char p_Index, char p_AddGold)
{
	CStreamPacketEngine spe; \
		spe.Init(0xC1, 0x29); \
		spe.Rightshift1((BYTE)(p_Index)); \
		spe.Rightshift1((BYTE)(p_AddGold)); \
		spe.Send(0, 0); \
}

void SendRequest_Repair(char p_Index, char p_AddGold)
{
	CStreamPacketEngine spe; \
		spe.Init(0xC1, 0x35); \
		spe.Rightshift1((BYTE)(p_Index)); \
		spe.Rightshift1((BYTE)(p_AddGold)); \
		spe.Send(0, 0); \
}

void AddTextChatList(char* strID, char* strText, int MsgType)
{
	BYTE str_ID[28];
	BYTE str_Text[28];

	CharToString(&str_ID, strID);
	CharToString(&str_Text, strText);
	ChatLog_AddText(GetUINewChatLogWindow(), str_ID, str_Text, MsgType, 0);
}

int CCharacterMachine::SlotConvert(int nDstIndex)
{
	if (nDstIndex >= 20 && nDstIndex < 28)
	{
		nDstIndex -= 20;
	}
	else if (nDstIndex == 35)
	{
		return EQUIPMENT_ERRING_RIGHT;
	}
	else if (nDstIndex == 36)
	{
		return EQUIPMENT_ERRING_LEFT;
	}
	else if (nDstIndex == 39)
	{
		return EQUIPMENT_PENTAGRAM1;
	}
	else if (nDstIndex == 40)
	{
		return EQUIPMENT_PENTAGRAM2;
	}
	else if (nDstIndex == 41)
	{
		return EQUIPMENT_STONE_MAGIC;
	}
	else
	{
		return -1;
	}

	return nDstIndex;
}

bool CCharacterMachine::isSlotSecond1(int nDstIndex)
{
	return (nDstIndex >= 20 && nDstIndex < 28)
		|| nDstIndex == 35 || nDstIndex == 36
		|| nDstIndex == 39 || nDstIndex == 40
		|| nDstIndex == 41;
}

bool CCharacterMachine::isSlotSecond2(int nDstIndex)
{
	return  nDstIndex == 35 || nDstIndex == 36
		|| nDstIndex == 39 || nDstIndex == 40
		|| nDstIndex == 41;
}

void EffectEquiping(int iIndex, zITEM* ip)
{
	((void(__cdecl*)(int)) 0x0057F410)(Hero);

	int o = Hero + 776;

	if (!InChaosCastle(World1))
	{
		switch (iIndex)
		{
		case EQUIPMENT_PENTAGRAM1:
		{
			int Helper_Type = 1171 + ip->Type;

			if (gCustomPet2.GetInfoPetType(ip->Type) == 10)
			{
				PET_INFO* pPetInfo = giPetManager::GetPetInfo((int)ip);
				giPetManager::Create_PetDarkSpirit(Hero, Helper_Type);
				giPetManager::SetPetInfo(*(DWORD*)(Hero + 676), pPetInfo);
			}
			else
			{
				CreateMuunBug(Helper_Type, o + 252, o, 0, 0);
			}
		}
		break;
		case EQUIPMENT_PENTAGRAM2:
		{
			int Helper_Type = 1171 + ip->Type;
			CreateFlyBug(Helper_Type, o + 252, o, 0, 0);
		}
		break;
		}
	}
}

void DeleteEquiping(int iIndex)
{
	((void(__cdecl*)(int)) 0x0057F410)(Hero);

	int o = Hero + 776;

	switch (iIndex)
	{
	case EQUIPMENT_PENTAGRAM1:
		DelectMuunBug(o);
		break;
	case EQUIPMENT_PENTAGRAM2:
		DelectFlyBug(o);
		break;
	}
}



void CCharacterMachine::EquipItem(int iIndex, BYTE* pbyItemPacket)
{
	if (iIndex < 0 || iIndex >= MAX_SLOT_MACHINE) { return; }

	zITEM* ip = &this->Equipment[iIndex];

	if (ip->Type != 0xFFFF || ip->Type != -1)
	{
		this->Unequip_Item(iIndex);
	}

	zITEM* TempIp = CreateItem(pbyItemPacket);


	if (NULL != TempIp)
	{
		TempIp->lineal_pos = iIndex;
		TempIp->ex_src_type = ITEM_EX_SRC_EQUIPMENT2;
		memcpy(ip, TempIp, sizeof(zITEM));
		DeletePickedItem();
		EffectEquiping(iIndex, ip);
	}
}

void CCharacterMachine::Unequip_Item(int iIndex)
{
	if (iIndex < 0 || iIndex >= MAX_SLOT_MACHINE) { return; }

	zITEM* ip = &this->Equipment[iIndex];

	int Helper_Type = ip->Type;

	ip->Type = -1;
	ip->Level = 0;
	ip->Number = -1;
	ip->Option1 = 0;
	ip->ExtOption = 0;
	ip->SocketCount = 0;
	for (int j = 0; j < MAX_SOCKETS_; ++j)
	{
		ip->SocketSeedID[j] = SOCKET_EMPTY_;
		ip->SocketSphereLv[j] = 0;
	}
	ip->SocketSeedSetOption = 0;

	if (gCustomPet2.GetInfoPetType(Helper_Type) == 10)
	{
		if (*(DWORD*)(Hero + 676))
		{
			if (*(WORD*)(Hero + 484) != 7832)
			{
				giPetManager::DeletePet(Hero);
			}
		}
	}
	else
	{
		DeleteEquiping(iIndex);
	}

	((void(__cdecl*)(int)) 0x0057F410)(Hero);
}

void CCharacterMachine::UnequipAllItems()
{
	for (int i = 0; i < MAX_SLOT_MACHINE; i++)
	{
		this->Unequip_Item(i);
	}
}

bool CCharacterMachine::IsEquipable(int iIndex, zITEM* pItem)
{
	if (pItem == NULL)
		return false;

	ITEM_ATTRIBUTE* pItemAttr = ItemAttribute(pItem->Type);
	BYTE byFirstClass = GetBaseClass(*(BYTE*)(Hero + 19));
	bool bEquipable = false;

	if (pItemAttr->RequireClass[byFirstClass])
	{
		bEquipable = true;
	}
	else if (byFirstClass == CLASS_DARK && pItemAttr->RequireClass[CLASS_WIZARD]
		&& pItemAttr->RequireClass[CLASS_KNIGHT])
	{
		bEquipable = true;
	}

	BYTE byStepClass = GetStepClass(*(BYTE*)(Hero + 19));
	if (pItemAttr->RequireClass[byFirstClass] > byStepClass)
	{
		return false;
	}

	if (bEquipable == false)
		return false;

	bEquipable = false;

	int m_byItemSlot = this->SlotConvert(pItemAttr->m_byItemSlot);
	if (m_byItemSlot == iIndex)
	{
		bEquipable = true;
	}
	else if (m_byItemSlot || iIndex != 1)
	{
		if (m_byItemSlot == 10 && iIndex == 11)
			bEquipable = true;
	}
	else if (byFirstClass != CLASS_KNIGHT
		&& byFirstClass != CLASS_DARK
		&& byFirstClass != CLASS_RAGEFIGHTER)
	{
		if (byFirstClass == CLASS_SUMMONER &&
			(pItem->Type < 2560 || pItem->Type > 2560 + MAX_ITEM_INDEX))
		{
			bEquipable = true;
		}
	}
	else
	{
		if (pItemAttr->TwoHand)
		{
			bEquipable = false;
			return false;
		}
		bEquipable = true;
	}

	if (byFirstClass == CLASS_ELF)
	{
		zITEM* l = &this->Equipment[1];
		if (iIndex == 0 && l->Type != 2048 + 7
			&& (l->Type >= 2048 && l->Type < 2048 + MAX_ITEM_INDEX))
		{
			if (pItem->Type != 2048 + 15)
				bEquipable = false;
		}
	}

	if (byFirstClass == CLASS_RAGEFIGHTER)
	{
		if (iIndex == 5)
		{
			bEquipable = false;
		}
		else if (pItemAttr->m_byItemSlot == 0)
		{
			bEquipable = RageEquipmentWeapon((int)&*(LPVOID*)0xEBCD98, iIndex, pItem->Type);
		}
	}

	if (bEquipable == false)
		return false;

	DWORD wStrength = ViewStrength + ViewAddStrength;
	DWORD wDexterity = ViewDexterity + ViewAddDexterity;
	DWORD wEnergy = ViewEnergy + ViewAddEnergy;
	DWORD wVitality = ViewVitality + ViewAddVitality;
	DWORD wCharisma = ViewLeadership + ViewAddLeadership;

	DWORD wLevel = *(WORD*)(*(DWORD*)0x8128AC8 + 14);

	if (pItem->RequireStrength > wStrength)
		return false;
	if (pItem->RequireDexterity > wDexterity)
		return false;
	if (pItem->RequireEnergy > wEnergy)
		return false;
	if (pItem->RequireVitality > wVitality)
		return false;
	if (pItem->RequireCharisma > wCharisma)
		return false;
	if (pItem->RequireLevel > wLevel)
		return false;

	return bEquipable;
}

bool CCharacterMachine::UnEquipmentWindowProcess(int m_iPointedSlot, int TypeInventory)
{
	if (m_iPointedSlot == -1)
	{
		return false;
	}
	int InitPointed = (TypeInventory == 1) ? 0 : 8;

	if (IsPress(VK_RBUTTON) && GetRepairMode() != REPAIR_MODE_ON && EquipmentItem == false)
	{
		ResetMouseRButton();

		if (GetPickedItem() == NULL)
		{
			int v24; int iSrcType, nDstIndex;

			if ((m_iPointedSlot >= 0 && m_iPointedSlot < InitPointed) || m_iPointedSlot >= 12)
			{
				iSrcType = 40;
				v24 = (DWORD)&this->Equipment[m_iPointedSlot];
			}
			else
			{
				iSrcType = 0;
				v24 = CharacterMachine_Equipment(m_iPointedSlot);
			}

			if (*(WORD*)v24 != 0xFFFF)
			{
				nDstIndex = MyFindEmptySlot(GetUINewMyInventory(), v24, 0);

				if (-1 != nDstIndex)
				{
					if (CreatePickedItem(NULL, (const void*)v24))
					{
						if (iSrcType == 40)
						{
							Unequip_Item(m_iPointedSlot);
						}
						else
						{
							UnequipItem((void*)GetUINewMyInventory(), m_iPointedSlot);
						}
						((void(__cdecl*)(int)) 0x0057F410)(Hero);
						SendRequestEquipment(iSrcType, m_iPointedSlot, v24, 0, nDstIndex + 12);
						HidePickedItem(GetPickedItem());
						playSound(29, 0, 0);
					}
					return true;
				}
			}
		}
	}
	return false;
}

bool CCharacterMachine::EquipmentWindowProcess()
{
	int v16 = GetUINewMyInventory();
	int m_iPointedSlot = *(int*)(v16 + 284);

	if (m_iPointedSlot == -1)
	{
		return 0;
	}
	if (IsRelease(VK_LBUTTON))
	{
		int pPickedItem = GetPickedItem();
		if (pPickedItem)
		{
			zITEM* pItemObj = (zITEM*)pPicked_GetItem(pPickedItem);

			if (pItemObj->bPeriodItem && pItemObj->bExpiredPeriod)
			{
				AddTextChatList("", GlobalText(22859), 4);
				BackupPickedItem();
				ResetMouseLButton();
				return false;
			}

			zITEM* pItemSlot = &this->Equipment[m_iPointedSlot];
			if (pItemSlot && pItemSlot->Type != 65535)
			{
				return true;
			}

			if (this->IsEquipable(m_iPointedSlot, pItemObj))
			{
				int InOwoner = g_pNewUISystem->GetOwnerMyInventory();

				if (InOwoner != -1)
				{
					int iSourceIndex = GetInventSourceLinealPos(GetSourceLinealPos(GetPickedItem()), InOwoner);
					int iTargetIndex = m_iPointedSlot;
					SendRequestEquipment(REQUEST_INVENTORY, iSourceIndex + 12, (int)pItemObj, REQUEST_EQUIPMENT, iTargetIndex);
					return true;
				}
				else if (GetOwnerInventory(GetPickedItem()) == g_pNewUISystem->GetOwnerMixInventory())
				{
					int iSourceIndex = GetSourceLinealPos(GetPickedItem());
					int iTargetIndex = m_iPointedSlot;
					SendRequestEquipment(GetMixInventoryEquipmentIndex(g_MixRecipeMgr), iSourceIndex, (int)pItemObj, 40, iTargetIndex);
					return true;
				}
				else if (GetOwnerInventory(GetPickedItem()) == g_pNewUISystem->GetOwnerShopInventory())
				{
					int iSourceIndex = GetSourceLinealPos(GetPickedItem());
					int iTargetIndex = m_iPointedSlot;
					SendRequestEquipment(4, iSourceIndex + 204, (int)pItemObj, 40, iTargetIndex);
					return true;
				}
				else if (GetOwnerInventory(GetPickedItem()) == g_pNewUISystem->GetOwnerMyTrade())
				{
					int iSourceIndex = GetSourceLinealPos(GetPickedItem());
					int iTargetIndex = m_iPointedSlot;
					SendRequestEquipment(1, iSourceIndex, (int)pItemObj, 40, iTargetIndex);

					int myTrade = *(DWORD*)(GetInstance() + 124);
					if (*(BYTE*)(myTrade + 3841))
						AlertTrade(myTrade);
					*(DWORD*)(myTrade + 3844) = 150;
					return true;
				}
				else if (pItemObj->ex_src_type == ITEM_EX_SRC_EQUIPMENT1 && EquipmentItem == false)
				{
					if (GetSourceLinealPos(GetPickedItem()) == m_iPointedSlot)
					{
						SendRequestEquipment(0, pItemObj->lineal_pos, (int)pItemObj, 40, m_iPointedSlot);
						return true;
					}
					BackupPickedItem();
				}
				else if (pItemObj->ex_src_type == ITEM_EX_SRC_EQUIPMENT2 && EquipmentItem == false)
				{
					if (GetSourceLinealPos(GetPickedItem()) == m_iPointedSlot)
					{
						BackupPickedItem();
					}
				}
			}
		}
		else
		{
			if (GetRepairMode() != REPAIR_MODE_ON)
			{
				zITEM* pEquippedItem = &this->Equipment[m_iPointedSlot];

				if (pEquippedItem->Type != 65535)
				{
					if (CreatePickedItem(NULL, pEquippedItem))
					{
						Unequip_Item(m_iPointedSlot);
						((void(__cdecl*)(int)) 0x0057F410)(Hero);
					}
				}
			}
			else
			{
				zITEM* pEquippedItem = &this->Equipment[m_iPointedSlot];

				if (pEquippedItem->Type != 65535)
				{
					if (*(bool*)(v16 + 1028) == true)
					{
						SendRequest_Repair(m_iPointedSlot, 1);
					}
				}
			}
		}
	}
	else if (IsPress(VK_RBUTTON) && GetRepairMode() != REPAIR_MODE_ON && EquipmentItem == false)
	{
		ResetMouseRButton();

		if (GetPickedItem() == NULL)
		{
			zITEM* pItemObj = &this->Equipment[m_iPointedSlot];

			if (pItemObj->Type != 0xFFFF)
			{
				int nDstIndex = MyFindEmptySlot(GetUINewMyInventory(), (int)pItemObj, 0);

				if (-1 != nDstIndex)
				{
					if (CreatePickedItem(NULL, pItemObj))
					{
						Unequip_Item(m_iPointedSlot);
					}

					SendRequestEquipment(40, m_iPointedSlot, (int)pItemObj, 0, nDstIndex + 12);
					playSound(29, 0, 0);
				}
			}
			return true;
		}
	}
	return false;
}