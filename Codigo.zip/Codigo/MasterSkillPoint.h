//#define sub_819D60			((char(__thiscall*)(char a5, char a6, float a7, float a8)) 0x00819D60)

void initMasterPoint();