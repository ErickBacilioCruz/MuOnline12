#include "StdAfx.h"
#include "CustomMessage.h"
#include "SEASON3B.h"
#include "NewUISystem.h"

char* GlobalText(int iNum, bool custom)
{
	if (custom == false)
	{
		return iGlobalText(GlobalLine, iNum);
	}
	else
	{
		return gCustomMessage.GetMessage(iNum);
	}
}

void RenderImageF(GLuint Image, float x, float y, float width, float height, float su, float sv, float uw, float vh)
{
	BITMAP_t* pText = (BITMAP_t*)CGlobalBitmap(&*(LPVOID*)0x9816AA0, Image);
	CRenderBitmaps(Image, x, y, width, height, su / pText->Width, sv / pText->Height, uw / pText->Width, vh / pText->Height, 1, 1, 0.0);
}

void RenderImage3F(GLuint Image, float x, float y, float width, float height)
{
	BITMAP_t* pText = (BITMAP_t*)CGlobalBitmap(&*(LPVOID*)0x9816AA0, Image);

	float uw, vh;

	uw = (float)pText->output_width / (float)pText->Width;
	vh = (float)pText->output_height / (float)pText->Height;

	CRenderBitmaps(Image, x, y, width, height, 0.0, 0.0, uw, vh, true, true, 0.0);
}

int GetUI_NewChatLogWindow()
{
	return ((int(__thiscall*)(int))0x00861180)(GetInstance());
}

