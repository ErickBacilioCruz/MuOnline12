#include "StdAfx.h"
#include "Util.h"
#include "UIControl.h"

CTextFont::CTextFont()
{
}

CTextFont::~CTextFont()
{
}

HDC CTextFont::GetFontHDC()
{
	return hFontDC(g_Fontthis());
}

DWORD CTextFont::GetTextColor() const
{
	return pRender_GetTextColor(g_Fontthis());
}
DWORD CTextFont::GetBgColor() const
{
	return pRender_GetBGColor(g_Fontthis());
}

void CTextFont::SetTextColor(BYTE byRed, BYTE byGreen, BYTE byBlue, BYTE byAlpha)
{
	pRender_SetTextColor1(g_Fontthis(), byRed, byGreen, byBlue, byAlpha);
}

void CTextFont::SetTextColor(DWORD dwColor)
{
	pRender_SetTextColor2(g_Fontthis(), dwColor);
}

void CTextFont::SetBgColor(BYTE byRed, BYTE byGreen, BYTE byBlue, BYTE byAlpha)
{
	pRender_SetBGColor1(g_Fontthis(), byRed, byGreen, byBlue, byAlpha);
}

void CTextFont::SetBgColor(DWORD dwColor)
{
	pRender_SetBGColor2(g_Fontthis(), dwColor);
}

void CTextFont::SetFont(HFONT hFont)
{
	SelectObject(this->GetFontHDC(), hFont);
}

void CTextFont::RenderText(int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{
	pRender_rendertext(g_Fontthis(), iPos_x, iPos_y, pszText, iBoxWidth, iBoxHeight, iSort, lpTextSize);
}