#pragma once
typedef float vec_t;

typedef vec_t vec2_t[2];
typedef vec_t vec3_t[3];
typedef vec_t vec4_t[4];
typedef vec_t vec34_t[3][4];
typedef unsigned long dword;

#define MAX_BITMAP_FILE_NAME					256

//--WideScrem
#define WindowWidth								*(GLsizei*)0x00E61E58
#define WindowHeight							*(GLsizei*)0x00E61E5C
#define g_WindowWidth							0xE61E58
#define g_WindowHeight							0xE61E5C
#define g_fScreenRate_x							*(float*)0x00E7C3D4
#define g_fScreenRate_y							*(float*)0x00E7C3D8
// ----------------------------------------------------------------------------------------------
#define GetWindowsY							(WindowHeight / g_fScreenRate_y)
#define GetWindowsX							(WindowWidth  / g_fScreenRate_x)


//--
#define GetWindowsX							    (WindowWidth  / g_fScreenRate_x)
#define GetWindowsY							    (WindowHeight / g_fScreenRate_y)
#define GetCenterX(x)							((GetWindowsX - x) / 2.f)
#define GetCenterY(x)							(((GetWindowsY - x) /  2.f) - 51.f)
#define GetSubCenterY(x)						(((GetWindowsY - x) /  2.f) - 51.f)
#define setPosCenterX(x)						((GetWindowsX - x) / 2.f)
#define setPosCenterY(x)						(((GetWindowsY - x) /  2.f) - 51.f)
#define setPosRight(x)							(GetWindowsX - 640.f + x )
#define setPosDown(x)							(GetWindowsY - 480.f + x )
#define setPosMidRight(x)						((GetWindowsX - 640.f) / 2.f + x )
#define setPosMidDown(x)						((GetWindowsY - 480.f) / 2.f + x )
#define SubWindowsY(x)							(GetWindowsY - x )
#define SubWindowsX(x)							(GetWindowsX - x )

#define m_Resolution							*(int*)0xE8C240
#define CGetScreenWidth3						((int(*)()) 0x005C6E80)

#define GetWindowsCX(x)							(float)((*(int*)0x00E61E58 / *(float*)0x00E7C3D4 /2.f) - (x / 2.f))
#define GetWindowsCY(x)							(float)(((*(int*)0x00E61E5C / *(float*)0x00E7C3D8 /2.f) - (x / 2.f))-51.f)

#define RenderImageB							((void(__cdecl*)(GLuint uiImageType, float x, float y, float width, float height)) 0x00790B50)
#define RenderImageE							((void(__cdecl*)(GLuint uiImageType, float x, float y, float width, float height, float su, float sv, DWORD color)) 0x00790F20)
#define CRenderItem3D							((int(__cdecl*)(float sx,float sy,float Width,float Height,int Type,int Level,int Option1,int ExtOption,bool PickUp)) 0x005CF310)
#define RenderColor1							((void(__cdecl*)(float x,float y,float Width,float Height, float Alpha, int Flag)) 0x006378A0)
#define EndRenderColor							((void(__cdecl*)())0x00637A30)
#define pCheckInMouse							((bool(__cdecl*)(int x, int y, int w, int h)) 0x00790B10)
#define CRenderBitmaps							((void(__cdecl*)(int Texture,float x,float y,float Width,float Height,float u,float v,float uWidth,float vHeight,bool Scale,bool StartScale,float Alpha)) 0x00637C60)

#define CHARACTER_SCENE			4
#define MAIN_SCENE				5
#define LoadBitmapA								((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)
#define RenderNumber							((float(__cdecl*)(float x, float y, int iNum, float fScale)) 0x00791000)
#define CGlobalBitmap							((void *(__thiscall*)(LPVOID Screen, int a1)) 0x0042CFE0)
#define g_isCharacterBuff						((bool(__thiscall*)(DWORD * thisa, int bufftype)) 0x004C8640)
#define Hero									*(DWORD*)0x007BC4F04
#define iGlobalText									((char*(__thiscall*)(LPVOID thisa, int LineNumber)) 0x00402320)
#define GlobalLine									(LPVOID)0x008128ADC
#define RenderTipText							((void(__cdecl*)(int sx, int sy, LPCSTR Text)) 0x00597220)
#define RenderImageD							((void(__cdecl*)(int ModelID, float X, float Y, float W, float H, float CurrentX, float CurrentY)) 0x00790E40)
#define MouseLButton								*(bool*)0x8793386
#define GetBaseClass							((BYTE(__cdecl*)(BYTE iClass)) 0x00405230)


//enum VERTEX_POS { LT, LB, RB, RT, POS_MAX };
#pragma pack(push, 1)
typedef struct
{
	GLuint	BitmapIndex;
	char	FileName[MAX_BITMAP_FILE_NAME];
	float	Width;
	float	Height;
	unsigned int output_width;
	unsigned int output_height;
	char	Components;
	GLuint	TextureNumber;
	BYTE	Ref;
	BYTE* Buffer;
private:
	friend class CBitmapCache;
	DWORD	dwCallCount;
} BITMAP_t;
#pragma pack(pop)

void RenderImageF(GLuint Image, float x, float y, float width, float height, float su, float sv, float uw, float vh);
void RenderImage3F(GLuint Image, float x, float y, float width, float height);


//--Movimiento de Ventana
#define resizeGuiRate				1.875
#define resizeGuiScaleRateX			(float)*(DWORD*)MAIN_RESOLUTION_X / 800.0f
#define resizeGuiScaleRateY			(float)*(DWORD*)MAIN_RESOLUTION_Y / 600.0f



//--SlotMuun
#define CharacterMachine_Equipment( x )			*(DWORD*)0x8128AC4 + 107 * x + 4672
#define InChaosCastle							((bool(__cdecl*)(int a1)) 0x004E65A0)
#define SetPlayerStop							((void(__cdecl*)(int c)) 0x0054EA80)
#define _GetSkinModelIndex						((char(__cdecl*)(char byClass)) 0x00587500)
#define ZzzCharacter_SetCharacterScale			((void(__cdecl*)(int Character)) 0x0057F020)
#define ms_pPickedItem							*(DWORD*)0x9816F7C
#define DeletePickedItem						((void  (*)( )) 0x007DD1B0)
#define CharactersClient						((int   (__thiscall*)(int List, int num)) 0x0096A4C0)
#define CList									((int   (*)( )) 0x00402BC0)
#define FindCharacterIndex						((int   (__cdecl*)(int Key)) 0x0057D9A0)
#define ConvertItemType							((int   (__cdecl*)(BYTE* Item)) 0x0058AA80)
#define ChangeChaosCastleUnit					((void(__cdecl*)(int Character)) 0x004E6670)
#define EnableAlphaTest							((void(__cdecl*)(BYTE Mode)) 0x00635FD0)
#define DisableAlphaBlend						((void(__cdecl*)( )) 0x00635F50)
#define GetPickedItem							((int   (*)( )) 0x007DD0F0)
#define RenderUI2DEffect						((void(__thiscall*)(int thisa, float fZOrder, void (__thiscall *)(LPVOID, DWORD ,DWORD), LPVOID pClass, DWORD dwParamA, DWORD dwParamB)) 0x00772EA0)
#define UI2DEffectCallEquip						((void(__thiscall*)(LPVOID pClass, DWORD dwParamA, DWORD dwParamB)) 0x00835C70)
#define GetUI3D									((int(__thiscall*)(int thisa))0x00861AA0)
#define IsRelease								((bool  (__cdecl*)(int iVirtKey))0x00791050)
#define GetOwnerInventory						((int (__thiscall*)(int Picket)) 0x007D9410)
#define EquipmentItem							*(bool*)0x81F6BEF
#define GetSourceLinealPos						((int(__thiscall*)(int thisa))0x007D94E0)
#define BackupPickedItem						((void (__thiscall*)( )) 0x007DD230)
#define GetMouseItem							((ITEM* (__thiscall*)(int thisa)) 0x007D9430)
#define pOwner_AddItem							((int (__thiscall*)(int thisa, int iColumnX, int iRowY, int pItem)) 0x007DA1F0)
#define MouseX									*(int*)0x879340C
#define MouseY									*(int*)0x8793410
#define IsPress									((bool  (__cdecl*)(int iVirtKey))0x00791070)
#define IsRepeat								((bool  (__cdecl*)(int iVirtKey))0x00791090)
#define ResetMouseRButton						((void(__cdecl*)()) 0x0083C0A0)
#define GetMixInventoryEquipmentIndex			((int(__thiscall*)(void *thisa)) 0x0050B840)
#define g_MixRecipeMgr							&*(LPVOID*)0xEBB848
#define GetInventSTargetLinealPos				((int(__thiscall*)(int thisa, int a2, int a3))0x0083C440)
#define CreatePickedItem						((bool(__cdecl*)(int a4, const void *a5)) 0x007DD100)
#define RemoveItemForSlot						((void(__thiscall*)(int thisa, int slot)) 0x00834320)
#define HidePickedItem							((void (__thiscall*)(int pPickedItem)) 0x007D9660)
#define pGetUIChaosMachine						((int(__thiscall*)(int a1)) 0x008612C0)
#define playSound								((int(__cdecl*)(int sound, int o, int a3))0x006D6C20)
#define World1									*(DWORD*)0xE61E18
#define GetStepClass							((BYTE(__cdecl*)(BYTE byClass)) 0x005875C0)
#define ResetMouseLButton						((void(__cdecl*)()) 0x0083C080)
#define GetInventSourceLinealPos				((int(__stdcall*)(int thisa, int a2))0x0083C480)
#define DeleteBug							((void (__cdecl*)(int Owner)) 0x005012D0)
#define Character_Machine						*(DWORD*)0x8128AC4
#define PartyNumber								*(DWORD*)0x81F6B6C
#define RenderNumArrow							((bool(__thiscall*)(int thisa, int iX, int iY)) 0x007E02B0)
#define FontHeight								*(DWORD *)0x81C0380
#define RenderEquipedPetLife					((bool(__thiscall*)(int thisa, int iX, int iY)) 0x007E0180)
#define RenderSummonMonsterLife					((bool(__thiscall*)(int thisa, int iX, int iY)) 0x007E0220)

//--RuneEfecto para los Pentagramas
#define GetBMDModel								((int(__thiscall*)(int thisa, int Type)) 0x00969C50)
#define BMDthisa								((int(*)( )) 0x004CDA10)
#define RenderTerrainAlphaBitmap1				((int(__cdecl*)(int Texture,float xf,float yf,float SizeX,float SizeY, vec3_t Light, float Rotation,float Alpha, float Height, bool acti)) 0x005DAD80)


char* GlobalText(int iNum, bool custom = false);
int GetUI_NewChatLogWindow();





























