#pragma once
#define HEIGHT_STRENGTH					120
#define HEIGHT_DEXTERITY				175
#define HEIGHT_VITALITY					240
#define HEIGHT_ENERGY					295
#define HEIGHT_CHARISMA					350
#define ConvertZ(y)						((y/(134.f/66.f))
#define GetInstance						((int(*)()) 0x00861110)
#define getNewSkillList					((int(__thiscall*)(int This)) 0x00861200)
#define pChangeButtonInfo				((void(__thiscall*)(BYTE* This, int x, int y, int sx, int sy)) 0x00779410)
#define SendAutoPote					((void(__thiscall*)(int This)) 0x0095E980)
#define RenderImageE					((void(__cdecl*)(GLuint uiImageType, float x, float y, float width, float height, float su, float sv, DWORD color)) 0x00790F20)
#define sub_778FA0						((void(__thiscall*)(BYTE* This, int x, int y)) 0x00778FA0)
#define sub_778FD0						((void(__thiscall*)(BYTE* This, int sx, int sy)) 0x00778FD0)
#define MsgBox_GetPos					((const POINT& (__thiscall*)(int This)) 0x00823DA0)

#define MainFrame_SetBtnState			((void(__thiscall*)(int This, int iBtnType, bool bStateDown)) 0x00815130)

enum ITEM_COLORSTATE
{
	ITEM_COLOR_NORMAL = 0,
	ITEM_COLOR_DURABILITY_50,
	ITEM_COLOR_DURABILITY_70,
	ITEM_COLOR_DURABILITY_80,
	ITEM_COLOR_DURABILITY_100,
	ITEM_COLOR_TRADE_WARNING,
};

class CNewUIMainFrame
{
public:
	CNewUIMainFrame(void);
	virtual ~CNewUIMainFrame(void);

	void Init(void);
	void setFrameInfo();

	static void LoadImages();
	static void RenderFrame(int This);
	static void RenderHeroShield(int This);
	static void RenderHeroEnergy(int This);
	static void RenderHeroLifeMana(int This);
	static void RenderTipTextExp(int sx, int sy, LPCSTR Text);

	static void __thiscall ButtonCashShop(BYTE* This, int x, int y, int sx, int sy);
	static void __thiscall ButtonCharacterInfo(BYTE* This, int x, int y, int sx, int sy);
	static void __thiscall ButtonInventory(BYTE* This, int x, int y, int sx, int sy);
	static void __thiscall ButtonFriend(BYTE* This, int x, int y, int sx, int sy);
	static void __thiscall ButtonMenuWindows(BYTE* This, int x, int y, int sx, int sy);

	static bool __thiscall Create_ItemHotKey(int This);
	static bool __thiscall Create(int This, DWORD* pNewUIMng, DWORD* pNewUI3DRenderMng);


	static void __thiscall RenderMixFrame(int This);
	static void __thiscall RenderOptFrame(int This);
	static void __thiscall RenderCharFrame(int This);

	static void __thiscall SystemMenuMsgBox_Render(int This);
	static void __thiscall ChangeButtonInfoD(BYTE* This, int x, int y, int sx, int sy);




	static void __thiscall Guild_OpenProcess(int This);
	static void __thiscall Guild_CloseProcess(int This);
	static void __thiscall Party_OpenProcess(int This);
	static void __thiscall Party_CloseProcess(int This);

public:
	double fExpBarY;
	double fExpBarX;
	double fProgress;
	double fExpHeight;
	double fExpBarNumX;
	double fExpBarNumY;
	float KeyCommon[4][4];
};

extern CNewUIMainFrame g_pNewUIMainFrame;