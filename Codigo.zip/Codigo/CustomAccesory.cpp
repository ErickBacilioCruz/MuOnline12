// CustomItem.cpp: implementation of the CCustomAccess class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomAccesory.h"
#include "Defines.h"
#include "Util.h"

CCustomAccess gCustomAccess;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomAccess::CCustomAccess() // OK
{
	this->Init();
}

CCustomAccess::~CCustomAccess() // OK
{

}

void CCustomAccess::Init() // OK
{
	this->m_CustomAccessInfo.clear();
}

void CCustomAccess::Load(CUSTOM_ACCESSORY_INFO* info) // OK
{
	for (int n = 0; n < MAX_ACESSORY_ITEM; n++)
	{
		if (info[n].Index < 0 || info[n].Index >= MAX_ACESSORY_ITEM)
		{
			return;
		}

		this->m_CustomAccessInfo.insert(std::pair<int, CUSTOM_ACCESSORY_INFO>(info[n].ItemIndex, info[n]));
	}
}

bool CCustomAccess::CheckItem(int ItemIndex)
{
	for (std::map<int, CUSTOM_ACCESSORY_INFO>::iterator it = this->m_CustomAccessInfo.begin(); it != this->m_CustomAccessInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex)
		{
			return 1;
		}
	}

	return 0;
}

bool CCustomAccess::CheckItemTypeRing(int ItemIndex)
{
	for (std::map<int, CUSTOM_ACCESSORY_INFO>::iterator it = this->m_CustomAccessInfo.begin(); it != this->m_CustomAccessInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex)
		{
			if (it->second.Type == 0)
			{
				return true;
			}
		}
	}

	return 0;
}

bool CCustomAccess::CheckItemTypePendant(int ItemIndex)
{
	for (std::map<int, CUSTOM_ACCESSORY_INFO>::iterator it = this->m_CustomAccessInfo.begin(); it != this->m_CustomAccessInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex)
		{
			if (it->second.Type == 1)
			{
				return true;
			}
		}
	}

	return 0;
}


bool CCustomAccess::GetItemColor(int ItemIndex, float* ItemColor)
{
	std::map<int, CUSTOM_ACCESSORY_INFO>::iterator it = this->m_CustomAccessInfo.find(ItemIndex);

	if (it != this->m_CustomAccessInfo.end())
	{
		ItemColor[0] = (float)(it->second.ColorR / 255.0f);
		ItemColor[1] = (float)(it->second.ColorG / 255.0f);
		ItemColor[2] = (float)(it->second.ColorB / 255.0f);

		return 1;
	}
	return 0;
}

__declspec(naked) void ItemConvertRings()
{
	static DWORD m_SetOptionsRing = 0x0058DD2E;
	static DWORD m_ReturnOptionsRing = 0x0058DE42;
	static DWORD m_IndexNewRingsOptions = 0;

	_asm
	{
		MOV m_IndexNewRingsOptions, ECX
	}

	if (m_IndexNewRingsOptions >= ITEM(13, 21) && m_IndexNewRingsOptions <= ITEM(13, 24) || gCustomAccess.CheckItemTypeRing(m_IndexNewRingsOptions))
	{
		_asm
		{
			JMP[m_SetOptionsRing];
		}
	}
	else
	{
		_asm
		{
			JMP[m_ReturnOptionsRing];
		}
	}
}

__declspec(naked) void ItemConvertPendants()
{
	static DWORD m_SetOptionsPendants = 0x0058DE98;
	static DWORD m_ReturnOptionsPendants = 0x0058E0C5;
	static DWORD m_IndexNewPendantsOptions2 = 0;

	_asm
	{
		MOV m_IndexNewPendantsOptions2, ECX;
	}
	if (m_IndexNewPendantsOptions2 >= ITEM(13, 25) && m_IndexNewPendantsOptions2 <= ITEM(13, 28) || gCustomAccess.CheckItemTypePendant(m_IndexNewPendantsOptions2))
	{
		_asm
		{
			JMP[m_SetOptionsPendants];
		}
	}
	else
	{
		_asm
		{
			JMP[m_ReturnOptionsPendants];
		}
	}
}

void InitAccessoryItem()
{
	MemorySet(0x0058DD11, 0x90, 12);
	SetCompleteHook(0xE9, 0x0058DD11, &ItemConvertRings);

	MemorySet(0x0058DE7B, 0x90, 12);
	SetCompleteHook(0xE9, 0x0058DE7B, &ItemConvertPendants);
}