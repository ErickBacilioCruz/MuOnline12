#include "StdAfx.h"
#include "Util.h"
#include "SEASON3B.h"
#include "Protect.h"
#include "NewUIFrame.h"
#include "WideScremS6.h"
#include "CSCharacterS13.h"
#include "Import.h"
#include "NewUISystem.h"


CGFxFrame::CGFxFrame(void)
{
}

CGFxFrame::~CGFxFrame(void)
{
}

void CGFxFrame::InitWideScreen()
{
	this->fScreenWin = GetWindowsX;
	this->fScreenHigh = GetWindowsY;
	this->fScreen_High = GetWindowsY;
	this->fScreen_Width = GetWindowsX;
	this->fScreen_fHigh = GetWindowsY;
	this->fScreen_fWidth = GetWindowsX;
	//--
	int Win1 = (int)GetWindowsX - 190;
	int Win2 = (int)GetWindowsX - 380;
	int Win3 = (int)GetWindowsX - 570;
	int WinC = (int)setPosCenterX(230);

	static float minmapframeposX;
	minmapframeposX = GetWindowsX - 176.f;
	SetDword(0x0086BDA6 + 2, (DWORD)&minmapframeposX);

	SetDword(0x005C7281 + 3, Win1);
	SetDword(0x005C72BD + 3, Win1);
	SetDword(0x005C6F65 + 3, Win2);
	SetDword(0x005C6FB0 + 3, Win2);
	SetDword(0x005C6FE6 + 3, Win2);
	SetDword(0x005C7007 + 3, Win2);
	SetDword(0x005C72B4 + 3, Win2);
	SetDword(0x005C7304 + 3, Win2);
	SetDword(0x005C72FB + 3, Win3);
	SetDword(0x005C7322 + 3, Win3);
	SetDword(0x00842A13 + 1, (int)setPosCenterX(0)); //-- render monster name

	SetDword(0x005C72C6 + 3, (int)GetWindowsX);
	SetDword(0x00943A57 + 3, (int)GetWindowsX); //-- x cash shop
	SetDword(0x004D06F4 + 6, (int)GetWindowsX); //-- Cursor Limite
	SetDword(0x004D0700 + 6, (int)GetWindowsX); //-- Cursor Limite
	SetDword(0x0040F7B7 + 1, (int)GetWindowsX); //-- Store Dialog
	SetDword(0x0048BC81 + 2, (int)GetWindowsX); //-- friend list
	SetDword(0x0048BC8C + 1, (int)GetWindowsX); //-- friend list
	SetDword(0x0048BDCC + 2, (int)GetWindowsX); //-- friend list
	SetDword(0x0048BDD7 + 1, (int)GetWindowsX); //-- friend list
	SetDword(0x004D7D6F + 2, (int)GetWindowsX); //-- Texto Server copy
	SetDword(0x004D7D8B + 2, (int)GetWindowsX); //-- Texto copy
	SetDword(0x004D7E04 + 2, (int)GetWindowsX); //-- Texto copy
	SetDword(0x004D7E8A + 2, (int)GetWindowsX); //-- Texto copy
	SetDword(0x006359C2 + 1, (int)GetWindowsX); //-- ItemModel 640
	SetDword(0x00779CCD + 3, (int)GetWindowsX); //-- Tooltip Limite
	SetDword(0x00779CD9 + 2, (int)GetWindowsX); //-- Tooltip Limite
	SetDword(0x0082B769 + 1, (int)GetWindowsX); //-- CheckInMouse Map
	SetDword(0x00635B5A + 2, (int)GetWindowsX); //-- PlayerDialog
	//--
	SetDword(0x004D071D + 6, (int)GetWindowsY); //-- Cursor Limite 480
	SetDword(0x004D0729 + 6, (int)GetWindowsY); //-- Cursor Limite 480
	SetDword(0x0040F7DC + 1, (int)GetWindowsY); //-- Store Dialog 480
	SetDword(0x004D7D7D + 1, (int)GetWindowsY); //-- Texto Server copy
	SetDword(0x004D7E12 + 1, (int)GetWindowsY); //-- Texto Server copy
	SetDword(0x004D7E98 + 1, (int)GetWindowsY); //-- Texto copy
	SetDword(0x006359D8 + 1, (int)GetWindowsY); //-- ItemModel 480
	SetDword(0x00635B71 + 2, (int)GetWindowsY); //-- PlayerDialog
	//--
	SetDword(0x00943A49 + 3, (int)GetWindowsY - 51); //-- y cash shop
	SetDword(0x0048BCEC + 2, (int)GetWindowsY - 51); //-- friend list
	SetDword(0x0048BCF7 + 1, (int)GetWindowsY - 51); //-- friend list
	SetDword(0x0048BE6D + 1, (int)GetWindowsY - 51); //-- friend list
	SetDword(0x0048BE77 + 1, (int)GetWindowsY - 51); //-- friend list
	SetDword(0x0048C08E + 3, (int)GetWindowsY - 51); //-- friend list
	//--
	SetDword(0x005B4951 + 1, (int)setPosDown(429)); //-- Check Mouse Attack
	SetDword(0x005B833F + 1, (int)setPosDown(429)); //-- Check Mouse target
	SetDword(0x007D4539 + 1, (int)setPosDown(429)); //-- Check Mouse Pick
	SetDword(0x008346F1 + 1, (int)setPosDown(429)); //-- Check Mouse Drop
	SetDword(0x00597927 + 1, (int)setPosDown(300)); //-- Notice
	//--
	SetDword(0x0059792D + 1, (int)setPosCenterX(0));   //-- Notice
	SetDword(0x0087262F + 3, (int)setPosCenterX(0)); //-- RenderMatchResult
	SetDword(0x008737DF + 3, (int)setPosCenterX(0)); //-- RenderMatchResult
	SetDword(0x004E7A4C + 1, (int)setPosCenterX(0)); //-- text status Event
	SetDword(0x0085A10F + 1, (int)setPosCenterX(225)); //-- WindowsOption
	SetDword(0x0085BCC4 + 1, (int)setPosCenterX(230)); //-- TempleEnterWindow
	SetDword(0x0085BDE9 + 1, (int)setPosCenterX(230)); //-- TempleResultWindow
	//--
	SetDword(0x008192CE + 6, (int)setPosMidDown(55));   //-- MasterSkill Tree1
	SetDword(0x008192E8 + 6, (int)setPosMidDown(55));   //-- MasterSkill Tree2
	SetDword(0x00819302 + 6, (int)setPosMidDown(55));   //-- MasterSkill Tree3
	SetDword(0x0042B031 + 1, (int)setPosMidDown(360));  //-- TextBox(CashShop)
	SetDword(0x008192C1 + 6, (int)setPosMidRight(11));  //-- MasterSkill Tree1
	SetDword(0x0081A5EA + 1, (int)setPosMidRight(458)); //-- Check Masterskill tooltip
	SetDword(0x0081A652 + 1, (int)setPosMidRight(474)); //-- tooltip
	SetDword(0x0042B036 + 1, (int)setPosMidRight(490)); //-- TextBox(CashShop)
	SetDword(0x009448A8 + 2, (int)setPosMidRight(162)); //-- Buttons(BUY)InGameShop
	SetDword(0x004D7D99 + 1, (int)setPosMidRight(335)); //-- Texto Copy
	SetDword(0x004D7E1D + 1, (int)setPosMidRight(335)); //-- Texto Copy
	SetDword(0x008192DB + 6, (int)setPosMidRight(221)); //-- MasterSkill Tree2
	SetDword(0x008192F5 + 6, (int)setPosMidRight(431)); //-- MasterSkill Tree3
	SetDword(0x00819440 + 1, (int)setPosMidRight(611)); //-- Button Closed MasterSkill
	//--

	SetDword(0x004E7756 + 1, (int)(GetWindowsX - 115));  //-- 
	SetDword(0x004E7688 + 1, (int)(GetWindowsX - 115));  //-- 


	SetDword(0x0082AAAD + 1, (int)(GetWindowsX - 27));  //-- Button Close Map
	SetDword(0x0085B31A + 1, (int)(GetWindowsX - 99));  //-- BloodCastleTimer
	SetDword(0x0085C39B + 1, (int)(GetWindowsX - 57));  //-- DuelWatchUserListWindow
	SetDword(0x00428E87 + 1, (int)(GetWindowsX - 175)); //-- CDeclareGuildListBox
	SetDword(0x004283CA + 1, (int)(GetWindowsX - 175)); //-- CDeclareGuildListBox
	SetDword(0x00426CFD + 1, (int)(GetWindowsX - 176)); //-- CDeclareGuildListBox
	SetDword(0x0042622D + 1, (int)(GetWindowsX - 176)); //-- CDeclareGuildListBox
	SetDword(0x0085B445 + 1, (int)(GetWindowsX - 131)); //-- WarScore
	SetDword(0x0085B9EF + 1, (int)(GetWindowsX - 131)); //-- DuelScore
	SetDword(0x0085C55E + 1, (int)(GetWindowsX - 227)); //-- BloodCastleTimer
	SetDword(0x0085B3B1 + 1, (int)(GetWindowsX - 127)); //-- ChaosCastle
	SetDword(0x0085BB11 + 1, (int)(GetWindowsX - 154)); //-- CastleSiege
	SetDword(0x0041F537 + 1, (int)(GetWindowsX - 365)); //-- Socket List
	SetDword(0x0085B167 + 1, (int)(GetWindowsX - 127)); //-- BloodCastleTimer
	SetDword(0x0085ECA6 + 1, (int)(GetWindowsX - 250)); //-- WindowsFriends
	SetDword(0x0085C84C + 1, (int)(GetWindowsX - 133)); //-- BloodCastleTimer
	SetDword(0x0085B601 + 1, (int)(GetWindowsX - 112)); //-- BloodCastleTimer
	SetDword(0x0086859A + 3, (int)(GetWindowsX - 112)); //-- CNewUIWindowMenu
	//--
	SetDword(0x0085B315 + 1, (int)(GetWindowsY - 129)); //-- WarScore
	SetDword(0x0085B5FC + 1, (int)(GetWindowsY - 171)); //-- WarScore
	SetDword(0x0085B440 + 1, (int)(GetWindowsY - 121)); //-- WarScore
	SetDword(0x0085B9EA + 1, (int)(GetWindowsY - 121)); //-- DuelScore
	SetDword(0x007C3210 + 1, (int)(GetWindowsY - 221)); //-- WindowsFriends
	SetDword(0x007C3217 + 1, (int)(GetWindowsY - 221)); //-- WindowsFriends
	SetDword(0x0085ECA1 + 1, (int)(GetWindowsY - 221)); //-- WindowsFriends
	SetDword(0x0085B3AC + 1, (int)(GetWindowsY - 132)); //-- ChaosCastle
	SetDword(0x0085BB0C + 1, (int)(GetWindowsY - 246)); //-- CastleSiege
	SetDword(0x0085C559 + 1, (int)(GetWindowsY - 138)); //-- BloodCastleTimer
	SetDword(0x0085C847 + 1, (int)(GetWindowsY - 138)); //-- BloodCastleTimer
	SetDword(0x0085B162 + 1, (int)(GetWindowsY - 132)); //-- BloodCastleTimer
	SetDword(0x008685A4 + 3, (int)(GetWindowsY - 196)); //-- CNewUIWindowMenu
	//--
	static float TapMap_Mid;
	static float Modelscale;
	static float Frame_Down;
	static float bloodtext_cy;
	static float TapMap_height;
	static float ModelPickscale;
	static double TapMap_Height;

	TapMap_Height = (float)GetWindowsY;
	TapMap_height = (float)GetWindowsY;
	TapMap_Mid = (float)setPosMidRight(230.f);
	Frame_Down = (float)GetWindowsY - 95.0f;
	bloodtext_cy = (float)GetWindowsY - 70.0f;

	SetDword(0x004E77E5 + 2, (DWORD)&bloodtext_cy); //-- BloodCastle text status
	SetDword(0x00868AFA + 2, (DWORD)&Frame_Down);   //-- CNewUIWindowMenu
	//--
	SetDword(0x0082AFED + 2, (DWORD)&TapMap_Mid);
	SetDword(0x0080F903 + 2, (DWORD)&TapMap_Height);
	SetDword(0x0082B38F + 2, (DWORD)&TapMap_Height); //-- fill map
	SetDword(0x0082B31E + 2, (DWORD)&TapMap_Height); //-- fill map
	SetDword(0x0082B0DB + 2, (DWORD)&TapMap_Height); //-- fill map
	//-- double
	SetDword(0x0082ABE8 + 2, (DWORD)&TapMap_height);
	SetDword(0x005B97B8 + 2, (DWORD)&TapMap_height);
	SetDword(0x005B9828 + 2, (DWORD)&TapMap_height);
	SetDword(0x005B98E0 + 2, (DWORD)&TapMap_height);
	SetDword(0x008C2DEB + 2, (DWORD)&TapMap_height);
	SetDword(0x008C2E5B + 2, (DWORD)&TapMap_height);
	SetDword(0x008CC6EF + 2, (DWORD)&TapMap_height);
	SetDword(0x008CC764 + 2, (DWORD)&TapMap_height);
	SetDword(0x008D9994 + 2, (DWORD)&TapMap_height);
	SetDword(0x008D9A09 + 2, (DWORD)&TapMap_height);
	SetDword(0x008EF457 + 2, (DWORD)&TapMap_height);
	SetDword(0x008EF4C9 + 2, (DWORD)&TapMap_height);
	SetDword(0x008EF5A1 + 2, (DWORD)&TapMap_height);
	SetDword(0x00914FA5 + 2, (DWORD)&TapMap_height);
	SetDword(0x0091501A + 2, (DWORD)&TapMap_height);
	SetDword(0x008EF636 + 2, (DWORD)&TapMap_height);
	//--
	float RateH = (float)GetWindowsY / 480.f;
	Modelscale = (0.15f * RateH);
	ModelPickscale = (0.075f * RateH);   //--MoldeScale En ItemTRSData.cpp   //--Fix para los faltantes

	SetDword(0x005CA158 + 2, (DWORD)&Modelscale);
	SetDword(0x005CA137 + 2, (DWORD)&ModelPickscale);




	SetDword(0x004D931E + 6, (int)(GetWindowsY - 51)); //-- MouseOnWindow

	if (WindowWidth > 800) //-- texto map
	{
		SetDword(0x00830D47 + 2, 800);
		SetDword(0x00830D4F + 2, (DWORD)&this->fScreenWin);
	}
	else
	{
		SetDword(0x00830D47 + 2, 640);
		SetDword(0x00830D4F + 2, 0xE61E58);
	}

	//-- ext700 test
	//-- System Chat
	SetDword(0x0085A425 + 1, (int)setPosDown(382)); //-- posicion y chat input
	SetDword(0x0085A09D + 1, (int)setPosDown(382)); //-- posicion y chat log
}

void CGFxFrame::MainFrame()
{
	g_pNewUIMainFrame.setFrameInfo();
}

void CGFxFrame::M34CryWolf()
{
	//-- M34CryWolf1st
	static float MainWolf1st[2] = { 0.0, };
	static float NumberWolf1st[5][2] = { 0.0, };
	static float barWolf1st[2] = { 0.0, };
	static float Dark_Elf_Icon[2] = { 0.0, };
	static float Wolf1stVal_Icon[2] = { 0.0, };
	static float Mvp_HP_Wolf1st_Y;
	static double Mvp_HP_Wolf1st_X;

	Mvp_HP_Wolf1st_X = setPosRight(548.f);
	Mvp_HP_Wolf1st_Y = setPosDown(323.f);
	MainWolf1st[0] = setPosRight(518.f);
	MainWolf1st[1] = setPosDown(278.f);
	NumberWolf1st[0][1] = setPosDown(280.f);
	NumberWolf1st[1][1] = setPosDown(282.f);
	NumberWolf1st[2][1] = setPosDown(286.f);
	NumberWolf1st[3][1] = setPosDown(294.f);
	NumberWolf1st[4][1] = setPosDown(306.f);
	NumberWolf1st[0][0] = setPosRight(565.f);
	NumberWolf1st[1][0] = setPosRight(582.f);
	NumberWolf1st[2][0] = setPosRight(598.f);
	NumberWolf1st[3][0] = setPosRight(613.f);
	NumberWolf1st[4][0] = setPosRight(625.f);
	Dark_Elf_Icon[0] = setPosRight(623.f);
	Dark_Elf_Icon[1] = setPosDown(358.f);
	Wolf1stVal_Icon[0] = setPosRight(623.f);
	Wolf1stVal_Icon[1] = setPosDown(379.f);
	//-- balgas
	SetDword(0x0088D863 + 1, setPosDown(380));
	SetDword(0x0088D868 + 1, setPosRight(600));
	SetDword(0x0088D8E5 + 1, setPosDown(388));
	SetDword(0x0088D8EA + 1, setPosRight(548));
	SetDword(0x0088D6C5 + 1, setPosDown(392));
	SetDword(0x0088D775 + 1, setPosDown(359));
	SetDword(0x0088D6CA + 1, setPosRight(538));
	SetDword(0x0088D77A + 1, setPosRight(582));
	//--
	SetDword(0x0088CDCA + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CE27 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CE84 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CCC0 + 1, setPosMidDown(0x0BC));
	SetDword(0x0088CEE0 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CF3D + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CF9A + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CFF6 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088D053 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088D0B0 + 1, setPosMidDown(0x0EB));
	SetDword(0x0088D10C + 1, setPosMidDown(0x0EB));
	SetDword(0x0088CBE9 + 1, setPosMidDown(0x0BC));
	SetDword(0x0088CB9C + 1, setPosMidDown(0x096));
	SetDword(0x0088DD07 + 6, setPosMidDown(0x0FA));
	SetDword(0x0088DD86 + 1, setPosMidDown(0x0CE));
	SetDword(0x0088DE1C + 1, setPosMidDown(0x0FA));
	SetDword(0x0088DE7B + 1, setPosMidDown(0x0FA));
	SetDword(0x0088DEC9 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088DF65 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088DFC7 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088E018 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088E042 + 6, setPosMidDown(0x0EF));
	SetDword(0x0088E057 + 6, setPosMidDown(0x0E3));
	SetDword(0x0088E0FC + 1, setPosMidDown(0x0CE));
	SetDword(0x0088E139 + 6, setPosMidDown(0x0FA));
	SetDword(0x0088E149 + 6, setPosMidDown(0x118));
	SetDword(0x0088E192 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088E1F2 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088E241 + 1, setPosMidDown(0x0FA));
	SetDword(0x0088E269 + 6, setPosMidDown(0x0EF));
	SetDword(0x0088E27E + 6, setPosMidDown(0x0E3));
	SetDword(0x0088E2C5 + 1, setPosMidDown(0x0EE));
	SetDword(0x0088CDD5 + 2, setPosMidRight(0x0C8));
	SetDword(0x0088CE32 + 2, setPosMidRight(0x17C));
	SetDword(0x0088CE8F + 1, setPosMidRight(0x16D));
	SetDword(0x0088CCC5 + 1, setPosMidRight(0x172));
	SetDword(0x0088CEEB + 2, setPosMidRight(0x15E));
	SetDword(0x0088CF48 + 2, setPosMidRight(0x14F));
	SetDword(0x0088CFA5 + 1, setPosMidRight(0x140));
	SetDword(0x0088D001 + 2, setPosMidRight(0x131));
	SetDword(0x0088D05E + 2, setPosMidRight(0x122));
	SetDword(0x0088D0BB + 1, setPosMidRight(0x113));
	SetDword(0x0088D117 + 2, setPosMidRight(0x104));
	SetDword(0x0088CBF3 + 1, setPosMidRight(0x0FA));
	SetDword(0x0088CBA1 + 1, setPosMidRight(0x0E6));
	SetDword(0x0088C9F1 + 1, setPosMidRight(0x096));
	SetDword(0x0088CA64 + 2, setPosMidRight(0x096));
	SetDword(0x0088C9AB + 2, setPosMidRight(0x1DF));
	SetDword(0x0088CA94 + 2, setPosMidRight(0x1DF));
	SetDword(0x0088DD11 + 3, setPosMidRight(0x14A));
	SetDword(0x0088DD8B + 1, setPosMidRight(0x0D4));
	SetDword(0x0088E075 + 1, setPosMidRight(0x13D));
	SetDword(0x0088E0A3 + 1, setPosMidRight(0x13D));
	SetDword(0x0088E101 + 1, setPosMidRight(0x0D4));
	SetDword(0x0088E119 + 6, setPosMidRight(0x122));
	SetDword(0x0088E129 + 6, setPosMidRight(0x158));
	SetDword(0x0088E197 + 1, setPosMidRight(0x122));
	SetDword(0x0088E1F7 + 1, setPosMidRight(0x122));
	SetDword(0x0088E246 + 1, setPosMidRight(0x122));
	SetDword(0x0088E29C + 1, setPosMidRight(0x13D));
	SetDword(0x0088E2CA + 1, setPosMidRight(0x13D));
	//--
	SetDword(0x0088C6DB + 2, (DWORD)&MainWolf1st[0]);
	SetDword(0x0088C6E7 + 2, (DWORD)&MainWolf1st[1]);
	SetDword(0x0088C83A + 2, (DWORD)&Dark_Elf_Icon[0]);
	SetDword(0x0088C846 + 2, (DWORD)&Dark_Elf_Icon[1]);
	SetDword(0x0088DCC0 + 2, (DWORD)&Mvp_HP_Wolf1st_X);
	SetDword(0x0088DCB1 + 2, (DWORD)&Mvp_HP_Wolf1st_Y);
	SetDword(0x0088C882 + 2, (DWORD)&Wolf1stVal_Icon[0]);
	SetDword(0x0088C88E + 2, (DWORD)&Wolf1stVal_Icon[1]);
	SetDword(0x0088C723 + 2, (DWORD)&NumberWolf1st[0][0]);
	SetDword(0x0088C762 + 2, (DWORD)&NumberWolf1st[1][0]);
	SetDword(0x0088C798 + 2, (DWORD)&NumberWolf1st[2][0]);
	SetDword(0x0088C7CE + 2, (DWORD)&NumberWolf1st[3][0]);
	SetDword(0x0088C804 + 2, (DWORD)&NumberWolf1st[4][0]);
	SetDword(0x0088C72F + 2, (DWORD)&NumberWolf1st[0][1]);
	SetDword(0x0088C76B + 2, (DWORD)&NumberWolf1st[1][1]);
	SetDword(0x0088C7A1 + 2, (DWORD)&NumberWolf1st[2][1]);
	SetDword(0x0088C7D7 + 2, (DWORD)&NumberWolf1st[3][1]);
	SetDword(0x0088C80D + 2, (DWORD)&NumberWolf1st[4][1]);
}

void CGFxFrame::M45Temple()
{
	static float minmapframeposX;
	static float minmapframeposY;
	static float RenderSkill0_X;
	static float RenderSkill0_Y;
	static float RenderSkill1_X;
	static float RenderSkill1_Y;
	static float RenderSkill2_Y;
	static float RenderSkill3_X;
	static float RenderSkill3_Y;
	static float RenderSkill4_X;
	static float RenderSkill5_X;
	static float RenderGameTime1_X;
	static float RenderGameTime1_Y;
	static float RenderGameTime2_X;
	static float RenderGameTime2_Y;
	static float RenderGameTime3_Y;
	static float RenderMiniMap1_X;
	static float RenderMiniMap1_Y;
	static float RenderMiniMap2_Y;
	static float RenderMiniMap3_Y;
	static float RenderMiniMap4_X;
	static float RenderMiniMap4_Y;
	static float RenderMiniMap5_X;
	static float RenderMiniMap6_X;
	static float RenderResultPanel;

	minmapframeposX = SubWindowsX(176.f);
	minmapframeposY = SubWindowsY(181.f);
	RenderSkill0_X = SubWindowsX(101.f);
	RenderSkill0_Y = SubWindowsY(280.f);
	RenderSkill1_X = SubWindowsX(78.f);
	RenderSkill1_Y = SubWindowsY(279.f);
	RenderSkill2_Y = SubWindowsY(266.f);
	RenderSkill3_X = SubWindowsX(100.f);
	RenderSkill3_Y = SubWindowsY(277.f);
	RenderSkill4_X = SubWindowsX(45.f);
	RenderSkill5_X = SubWindowsX(23.f);
	RenderMiniMap1_X = SubWindowsX(128.f);
	RenderMiniMap1_Y = SubWindowsY(301.f);
	RenderMiniMap2_Y = SubWindowsY(217.f);
	RenderMiniMap3_Y = SubWindowsY(248.f);
	RenderMiniMap4_X = SubWindowsX(108.f);
	RenderMiniMap4_Y = SubWindowsY(234.f);
	RenderMiniMap5_X = SubWindowsX(57.f);
	RenderMiniMap6_X = SubWindowsX(13.f);
	RenderGameTime1_X = SubWindowsX(134.f);
	RenderGameTime1_Y = SubWindowsY(87.f);
	RenderGameTime2_X = SubWindowsX(65.5f);
	RenderGameTime2_Y = SubWindowsY(72.5f);
	RenderGameTime3_Y = SubWindowsY(75.5f);
	RenderResultPanel = setPosCenterX(351.f);
	//-- NewUICursedTempleResult
	SetDword(0x0086A4B6 + 2, (DWORD)&RenderResultPanel);  //-- CursedTempleResult
	SetDword(0x0086A4F9 + 2, (DWORD)&RenderResultPanel);  //-- CursedTempleResult
	//-- RenderMiniMap
	SetDword(0x0086E98A + 2, (DWORD)&RenderMiniMap1_X);  //-- UICursedTemple
	SetDword(0x0086E993 + 2, (DWORD)&RenderMiniMap1_Y);  //-- UICursedTemple
	SetDword(0x0086EA13 + 2, (DWORD)&RenderMiniMap1_X);  //-- UICursedTemple
	SetDword(0x0086EA1C + 2, (DWORD)&RenderMiniMap2_Y);  //-- UICursedTemple
	SetDword(0x0086EA82 + 2, (DWORD)&RenderMiniMap1_X);  //-- UICursedTemple
	SetDword(0x0086EA8B + 2, (DWORD)&RenderMiniMap3_Y);  //-- UICursedTemple
	SetDword(0x0086F253 + 2, (DWORD)&RenderMiniMap4_X);  //-- UICursedTemple
	SetDword(0x0086F28F + 2, (DWORD)&RenderMiniMap5_X);  //-- UICursedTemple
	SetDword(0x0086F2CB + 2, (DWORD)&RenderMiniMap6_X);  //-- UICursedTemple
	SetDword(0x0086F249 + 2, (DWORD)&RenderMiniMap4_Y);  //-- UICursedTemple
	SetDword(0x0086F285 + 2, (DWORD)&RenderMiniMap4_Y);  //-- UICursedTemple
	SetDword(0x0086F2C1 + 2, (DWORD)&RenderMiniMap4_Y);  //-- UICursedTemple
	//-- RenderGameTime
	SetDword(0x0086E668 + 2, (DWORD)&RenderGameTime1_X);  //-- UICursedTemple
	SetDword(0x0086E671 + 2, (DWORD)&RenderGameTime1_Y);  //-- UICursedTemple
	SetDword(0x0086E6F1 + 2, (DWORD)&RenderGameTime2_X);  //-- UICursedTemple
	SetDword(0x0086E6FA + 2, (DWORD)&RenderGameTime2_Y);  //-- UICursedTemple
	SetDword(0x0086E7F6 + 2, (DWORD)&RenderGameTime2_X);  //-- UICursedTemple
	SetDword(0x0086E7FF + 2, (DWORD)&RenderGameTime3_Y);  //-- UICursedTemple
	SetDword(0x0086E898 + 2, (DWORD)&RenderGameTime2_X);  //-- UICursedTemple
	SetDword(0x0086E8A1 + 2, (DWORD)&RenderGameTime3_Y);  //-- UICursedTemple
	//-- RenderSkill
	SetDword(0x0086BDA6 + 2, (DWORD)&minmapframeposX);  //-- UICursedTemple
	SetDword(0x0086BDAF + 2, (DWORD)&minmapframeposY);  //-- UICursedTemple
	SetDword(0x0086DF67 + 2, (DWORD)&RenderSkill0_X);   //-- UICursedTemple
	SetDword(0x0086DF70 + 2, (DWORD)&RenderSkill0_Y);   //-- UICursedTemple
	SetDword(0x0086E117 + 2, (DWORD)&RenderSkill1_X);   //-- UICursedTemple
	SetDword(0x0086E120 + 2, (DWORD)&RenderSkill1_Y);   //-- UICursedTemple
	SetDword(0x0086E182 + 2, (DWORD)&RenderSkill1_X);   //-- UICursedTemple
	SetDword(0x0086E18B + 2, (DWORD)&RenderSkill2_Y);   //-- UICursedTemple
	SetDword(0x0086E1ED + 2, (DWORD)&RenderSkill3_X);   //-- UICursedTemple
	SetDword(0x0086E1F6 + 2, (DWORD)&RenderSkill3_Y);   //-- UICursedTemple
	SetDword(0x0086E3B5 + 2, (DWORD)&RenderSkill4_X);   //-- UICursedTemple
	SetDword(0x0086E3BE + 2, (DWORD)&RenderSkill3_Y);   //-- UICursedTemple
	SetDword(0x0086E4DC + 2, (DWORD)&RenderSkill5_X);   //-- UICursedTemple
	SetDword(0x0086E4E5 + 2, (DWORD)&RenderSkill3_Y);   //-- UICursedTemple
	//-- INT
	SetDword(0x0085B31A + 1, (int)SubWindowsX(99));    //-- UIKanturuInfoWindow
	SetDword(0x0086D5B3 + 1, (int)SubWindowsY(242));   //-- UICursedTemple
	SetDword(0x0086D5B8 + 1, (int)SubWindowsX(127));   //-- UICursedTemple
	SetDword(0x0086DCF2 + 1, (int)SubWindowsY(301));   //-- UICursedTemple
	SetDword(0x0086DCF7 + 1, (int)SubWindowsX(128));   //-- UICursedTemple
	SetDword(0x0085B601 + 1, (int)SubWindowsX(112));   //-- UIKanturuInfoWindow
	SetDword(0x0085B286 + 1, (int)setPosCenterX(230)); //-- UIKanturu2ndEnter
	SetDword(0x0085BCC4 + 1, (int)setPosCenterX(230)); //-- CursedTempleEnter
	SetDword(0x0085BDE9 + 1, (int)setPosCenterX(230)); //-- CursedTempleResult
}

void CGFxFrame::CreateWindows()
{
	((void (*)())0x004D0FC0)();
	//--
	if (WindowWidth > 1360)
	{
		g_fScreenRate_x = 1.6f;
		g_fScreenRate_y = 1.6f;
	}
	else
	{
		g_fScreenRate_x = 1.25f;
		g_fScreenRate_y = 1.25f;
	}
	//--
	int Win1 = (int)GetWindowsX - 190;
	int Win2 = (int)GetWindowsX - 380;
	int Win3 = (int)GetWindowsX - 570;
	int WinC = (int)setPosCenterX(230);
	//-- Open Windows 1
	SetDword((0x0085A6A8 + 1), Win1);
	SetDword((0x0085A8AE + 1), Win1);
	SetDword((0x0085A92D + 1), Win1);
	SetDword((0x0085A9AC + 1), Win1);
	SetDword((0x0085AA2B + 1), Win1);
	SetDword((0x0085AB41 + 1), Win1);
	SetDword((0x0085ABCF + 1), Win1);
	SetDword((0x0085AD78 + 1), Win1);
	SetDword((0x0085AE06 + 1), Win1);
	SetDword((0x0085AE94 + 1), Win1);
	SetDword((0x0085AFB0 + 1), Win1);
	SetDword((0x0085B048 + 1), Win1);
	SetDword((0x0085B0D6 + 1), Win1);
	SetDword((0x0085B4D9 + 1), Win1);
	SetDword((0x0085B56D + 1), Win1);
	SetDword((0x0085C020 + 1), Win1);
	SetDword((0x0085C0B4 + 1), Win1);
	SetDword((0x0085C270 + 1), Win1);
	SetDword((0x0085C4C0 + 1), Win1);
	SetDword((0x0085C5F2 + 1), Win1);
	SetDword((0x0085C686 + 1), Win1);
	SetDword((0x0085C71A + 1), Win1);
	SetDword((0x0085C7AE + 1), Win1);
	SetDword((0x0085C977 + 1), Win1);
	SetDword((0x007F8277 + 3), Win1);		//-- skill helper
	SetDword((0x0085CC36 + 1), Win1);		//-- Helper Windows
	SetDword((0x0085F78B + 1), Win1);
	SetDword((0x0085F87A + 1), Win1);
	SetDword((0x0085FA1A + 1), Win1);
	SetDword((0x0085FA45 + 1), Win1);
	SetDword((0x0085FA8B + 1), Win1);
	SetDword((0x0085FD25 + 1), Win1);
	SetDword((0x0085FE8D + 1), Win1);
	SetDword((0x00860033 + 1), Win1);
	//-- Open Windows 2
	SetDword((0x0085A731 + 1), Win2);
	SetDword((0x0085A7B0 + 1), Win2);
	SetDword((0x0085A82F + 1), Win2);
	SetDword((0x0085AAB3 + 1), Win2);
	SetDword((0x0085AC5F + 1), Win2);
	SetDword((0x0085ACEA + 1), Win2);
	SetDword((0x0085B1F5 + 1), Win2);
	SetDword((0x0085C148 + 1), Win2);
	SetDword((0x0085C1DC + 1), Win2);
	SetDword((0x0085CA15 + 1), Win2);
	SetDword((0x0085CAA9 + 1), Win2);
	SetDword((0x0085CB3D + 1), Win2);
	SetDword((0x0085CCCA + 1), Win2);
	SetDword((0x0085ED59 + 1), Win2);
	SetDword((0x0085EDF7 + 1), Win2);
	SetDword((0x0085EE7E + 1), Win2);
	SetDword((0x0085EEAB + 1), Win2);
	SetDword((0x0085F0F1 + 1), Win2);
	SetDword((0x0085F7B6 + 1), Win2);
	SetDword((0x007D5953 + 1), Win2);
	SetDword((0x007D5997 + 1), Win2);		//-- Viewport
	SetDword((0x007D59BB + 1), Win2);
	SetDword((0x007D59FF + 2), Win2);		//-- Viewport
	SetDword((0x007D5A24 + 1), Win2);
	SetDword((0x007D5A68 + 2), Win2);		//-- Viewport
	SetDword((0x007D5A8D + 1), Win2);
	SetDword((0x007D5AD1 + 1), Win2);		//-- Viewport
	SetDword((0x007D5AF5 + 1), Win2);
	SetDword((0x007D5B39 + 2), Win2);		//-- Viewport
	SetDword((0x007D5B5E + 1), Win2);
	SetDword((0x007D5BA2 + 2), Win2);		//-- Viewport
	SetDword((0x007D5BC9 + 1), Win2);
	SetDword((0x007D5C0D + 1), Win2);		//-- Viewport
	SetDword((0x007D5C59 + 2), Win2);		//-- Viewport
	SetDword((0x007D5C89 + 1), Win2);
	SetDword((0x007D5CB5 + 1), Win2);		//-- segunda ventana de 3

	static float HeightTitleImp;
	HeightTitleImp = GetWindowsY;

	int discount1 = setPosDown(430.f);
	int discount2 = 25.f;

	SetDword(0x0040F2F7 + 2, (DWORD)&HeightTitleImp); //Size OpenGL
	SetDword(0x0040F30B + 2, (DWORD)&HeightTitleImp); //Size OpenGL
	//--
	SetByte(0x004D7A17 + 1, (int)discount2); //Size OpenGL
	SetByte(0x004D7182 + 1, (int)discount2); //Size OpenGL
	SetDword(0x004D7178 + 1, discount1); //Size OpenGL
	SetDword(0x004D7A0D + 1, discount1); //Size OpenGL

	/*if(g_Protect->m_MainInfo.SelectServerType == 1)
	{
		discount2 = 90.f;
		discount1 = setPosDown(300.f);
		SetByte(0x004D7A17  + 1, discount2); //Size OpenGL
		SetDword(0x004D7A0D + 1, discount1); //Size OpenGL
	}
	if(g_Protect->m_MainInfo.SelectCharacterType == 1)
	{
		//-- select char
		SetByte(0x004D7182  + 1, 0); //Size OpenGL
		SetDword(0x004D7178 + 1, setPosDown(480.f)); //Size OpenGL
	}*/
	//--
	SetDword(0x004833DE + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x0084C516 + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x004D717D + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x004D7A12 + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x00636492 + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x006364BE + 1, (int)GetWindowsX); //Size OpenGL
	SetDword(0x004833D9 + 1, (int)GetWindowsY); //Size OpenGL
	SetDword(0x0084C511 + 1, (int)GetWindowsY); //Size OpenGL
	SetDword(0x006364A8 + 1, (int)GetWindowsY); //Size Background
	SetDword(0x006364D4 + 1, (int)GetWindowsY); //Size Background
	SetDword(0x004D9746 + 3, (int)GetWindowsY); //Size Background

	CGFxFrame::Instance()->MainFrame();

	CGFxFrame::Instance()->M45Temple();
	
	CGFxFrame::Instance()->M34CryWolf();

	CGFxFrame::Instance()->InitWideScreen();
}

int CGFxFrame::GetScreenWidth()
{
	return GetWindowsX;
}

int CGFxFrame::FrameBeginOpengl()
{
	if (m_Resolution > 1)
	{
		return GetWindowsX;
	}
	return CGetScreenWidth3();
}

float CGFxFrame::Convertx(float x)
{
	return (float)(x * g_fScreenRate_x);
}

float CGFxFrame::Converty(float x)
{
	return (float)(x * g_fScreenRate_y);
}

int MasterSkill_SetInfo(int This)
{
	*(DWORD*)(This + 20) = setPosMidRight(0);
	*(DWORD*)(This + 24) = setPosMidDown(0);
	*(DWORD*)(This + 28) = 640;
	*(DWORD*)(This + 32) = 428;
	NewUIBase_Show(This, 0);
	return This;
}

int CGFxFrame::TreeType1(int This, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{
	return pRender_rendertext(This, setPosMidRight(iPos_x), setPosMidDown(iPos_y), pszText, iBoxWidth, iBoxHeight, iSort, lpTextSize);
}

void MasterSkill_Render(GLuint uiImageType, float x, float y, float width, float height)
{
	RenderImageB(uiImageType, x, y, width, 428);
}

int CashShop_RenderItem3D(float PosX, float PosY, float Width, float Height, int ItemID, int a6, int a7, int a8, char a9)
{
	int This = *(DWORD*)(GetInstance() + 252);

	return CRenderItem3D(PosX + *(DWORD*)(This + 36), *(DWORD*)(This + 40) + PosY, Width, Height, ItemID, a6, a7, a8, a9);
}

void CashShop_RenderColor(float x, float y, float w, float h, float arg5, int arg6)
{
	RenderColor1(x, y, GetWindowsX, GetWindowsY, arg5, arg6);
}

bool CashShop_CheckInMouse(int x, int y, int w, int h)
{
	int v4 = *(DWORD*)(GetInstance() + 252);

	return pCheckInMouse(*(DWORD*)(v4 + 36) + x, *(DWORD*)(v4 + 40) + y, w, h);
}

void CashShop_RenderBanner(int ImageID, float PosX, float PosY, float Width, float Height)
{
	int v4 = *(DWORD*)(GetInstance() + 252);

	RenderImageB(ImageID, *(DWORD*)(v4 + 36) + PosX, *(DWORD*)(v4 + 40) + PosY, Width, Height);
}

BYTE CGFxFrame::CashShop_Init(int This, int a2, int x, int y)
{
	return SetInfoCashShop(This, a2, setPosMidRight(x), setPosMidDown(y));
}

void CGFxFrame::CashShop_ButtonBuy(BYTE* This, int x, int y, int Width, int Height)
{

	return NewUIChangeButtonInfo(This, x, setPosMidDown(y), Width, Height);
}

void CGFxFrame::InvExt_OpenFrame(int This, int cx, int cy)
{
	SetInfoInvExt(This, setPosRight(cx), cy);
}

void CGFxFrame::Trade_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoTrade(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::BaultExt_OpenFrame(int This, int cx, int cy)
{
	SetInfoBaulExt(This, setPosRight(cx), cy);
}

void CGFxFrame::Baul_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoBaul(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::Lucky_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoLucky(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::OtherStore_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoOtherStore(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::Store_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoStore(This, setPosRight(cx), cy, Ext);
}

int CGFxFrame::Chaos_OpenFrame(int This, int cx, int cy, int Ext)
{
	return SetInfoChaos(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::Shop_OpenFrame(int This, int cx, int cy, int Ext)
{
	SetInfoShop(This, setPosRight(cx), cy, Ext);
}

void CGFxFrame::ViewPort_SetInfo(int This, int cx, int cy)
{
	SetInfoviewControl(This, setPosRight(cx), cy);
}

void CGFxFrame::ButtonGens(BYTE* This, int x, int y, int Width, int Height)
{
	return NewUIChangeButtonInfo(This, setPosRight(x), y, Width, Height);
}

void CGFxFrame::SceneMuLogo(int Texture, float x, float y, float Width, float Height, float u, float v, float uWidth, float vHeight, bool Scale, bool StartScale, float Alpha)
{
	/*if(g_Protect->m_MainInfo.SelectCharacterType == 4)
	{
		if(Texture == 31019)
		{
			Texture = 531019;
		}
		else if(Texture == 31018)
		{
			Texture = 531018;
		}
	}*/
	CRenderBitmaps(Texture, setPosMidRight(x), y, Width, Height, u, v, uWidth, vHeight, Scale, StartScale, Alpha);
}

bool CGFxFrame::CreateMessageBox(void* This, int sx, int sy, int cx, int cy, float Deeplayer)
{
	return CreatMessageBox(This, setPosCenterX(cx), setPosCenterY(cy), cx, cy, Deeplayer);
}

bool CGFxFrame::CheckBaulExt(int x, int y, int w, int h)
{
	bool Arc = 0;

	int This = *(DWORD*)(GetInstance() + 304);
	int sx = *(DWORD*)(This + 16);
	int sy = *(DWORD*)(This + 20);

	if ((pCheckInMouse(x, y, w, h) == TRUE) || (g_pNewUISystem->IsVisible(78) && pCheckInMouse(sx, sy, w, h) == TRUE))  //--Revisar
	{
		Arc = TRUE;
	}

	return Arc;
}

__declspec(naked) void CreatefCameraDistanceFar3D()
{
	static dword var_jmp = 0x004D8520;
	static float lbl_D27BFC = 35.f;

	if (SceneFlag == CHARACTER_SCENE)
	{
		_asm
		{
			fld     dword ptr ds : [lbl_D27BFC]
				fstp    dword ptr ds : [0xE61E40]
					jmp     var_jmp
		}
	}
	else if (SceneFlag == MAIN_SCENE)
	{
		_asm
		{
			fld     dword ptr ds : [oCam_Zoom]
				fstp    dword ptr ds : [0xE61E40]
					jmp     var_jmp
		}
	}
}

__declspec(naked) void ChangeRadioFrustrum()
{
	static dword var_jmp = 0x005DBAE4;
	static double lbl_D232F0 = 0.91;
	static double lbl_D232F4 = 0.45;

	if (SceneFlag == 5)
	{
		_asm
		{
			fmul    qword ptr ds : [lbl_D232F0]
				jmp     var_jmp
		}
	}
	else
	{
		_asm
		{
			fmul    qword ptr ds : [lbl_D232F4]
				jmp     var_jmp
		}
	}
}

float M34CryWolf1stNumber2D(float x, float y, int Num, float Width, float Height)
{
	return ((float(__cdecl*)(float, float, int, float, float)) 0x00637680)(setPosRight(x), setPosDown(y), Num, Width, Height);
}

void DuelWatchMainFrameRender()
{
	float frame_cx = setPosMidRight(0.0);
	float frame_cy = GetWindowsY - 51.f;

	RenderImageB(31639, frame_cx, frame_cy, 256.0, 51.0);
	RenderImageB(31640, frame_cx + 256.f, frame_cy, 128.0, 51.0);
	RenderImageB(31641, frame_cx + 384.f, frame_cy, 256.0, 51.0);
}

void DuelWatchMainFrame1(int id, float x, float y, float width, float height)
{
	RenderImageB(id, setPosMidRight(x), setPosDown(y), width, height);
}

void DuelWatchMainFrame3(int id, float x, float y, float width, float height)
{
	RenderImageB(id, setPosMidRight(x), setPosDown(y), width, height);
}

void DuelWatchMainFrame2(int id, float x, float y, float width, float height, float su, float sv, float uw, float vh, DWORD color)
{
	RenderImageA(id, setPosMidRight(x), setPosDown(y), width, height, su, sv, uw, vh, color);
}

void CGFxFrame::BaseMatch_SetPosition(int This, int ix, int iy)
{
	((void(__thiscall*)(int, int, int)) 0x004E7BA0)(This, ix, setPosMidDown(iy));
}

bool DumpExceptionFilter(EXCEPTION_POINTERS* info) // OK
{
	char path[MAX_PATH];

	SYSTEMTIME SystemTime;

	GetLocalTime(&SystemTime);

	wsprintf(path, "%d-%d-%d_%dh%dm%ds.dmp", SystemTime.wYear, SystemTime.wMonth, SystemTime.wDay, SystemTime.wHour, SystemTime.wMinute, SystemTime.wSecond);

	HANDLE file = CreateFile(path, GENERIC_WRITE, FILE_SHARE_WRITE, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);

	if (file != INVALID_HANDLE_VALUE)
	{
		MINIDUMP_EXCEPTION_INFORMATION mdei;

		mdei.ThreadId = GetCurrentThreadId();

		mdei.ExceptionPointers = info;

		mdei.ClientPointers = 0;

		if (MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), file, (MINIDUMP_TYPE)(MiniDumpScanMemory + MiniDumpWithIndirectlyReferencedMemory), &mdei, 0, 0) != 0)
		{
			CloseHandle(file);
			return EXCEPTION_EXECUTE_HANDLER;
		}
	}
	CloseHandle(file);

	return EXCEPTION_CONTINUE_SEARCH;
}

void CGFxFrame::Init()
{
	static float GL_Zoom = 35.0;
	static float Gl_Cam = 2000.0;
	static float Gl_CamY = 2400.0;

	SetFloat(oCam_Zoom, 37.f);
	SetFloat(oCam_ClipGL, 2500.0); //-- GL_CAM
	SetFloat(oCam_ClipY, 2500.0); //-- GL_CAMY
	//SetFloat(oCam_ClipGY, 2500.0); //-- GL_CAMY
	SetDword(0x0048E1FF + 2, (DWORD)&Gl_Cam);
	SetDword(0x00772968 + 2, (DWORD)&Gl_Cam);
	SetDword(0x007C709E + 2, (DWORD)&Gl_Cam);
	SetDword(0x0085458D + 2, (DWORD)&Gl_Cam);
	SetDword(0x008CC613 + 2, (DWORD)&Gl_Cam);
	SetDword(0x00943C6E + 2, (DWORD)&Gl_Cam);
	SetDword(0x0062CA65 + 2, (DWORD)&Gl_CamY);
	SetDword(0x0062CAC6 + 2, (DWORD)&Gl_CamY);
	SetDword(0x0062CB15 + 2, (DWORD)&Gl_CamY);
	//SetDword(0x004D8514 + 2, (DWORD)&GL_Zoom); 
	SetDword(0x00574FCB + 2, (DWORD)&GL_Zoom);
	SetDword(0x00575099 + 2, (DWORD)&GL_Zoom);
	SetDword(0x00575243 + 2, (DWORD)&GL_Zoom);
	SetDword(0x00575278 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0057538C + 2, (DWORD)&GL_Zoom);
	SetDword(0x005753C1 + 2, (DWORD)&GL_Zoom);
	SetDword(0x005754D5 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0057550A + 2, (DWORD)&GL_Zoom);
	SetDword(0x0057568C + 2, (DWORD)&GL_Zoom);
	SetDword(0x00575754 + 2, (DWORD)&GL_Zoom);
	SetDword(0x005758C3 + 2, (DWORD)&GL_Zoom);
	SetDword(0x005758F8 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0058885A + 2, (DWORD)&GL_Zoom);
	SetDword(0x005B9B5F + 2, (DWORD)&GL_Zoom);
	SetDword(0x005B9C65 + 2, (DWORD)&GL_Zoom);
	SetDword(0x005DD584 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0062C9F5 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0063D254 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0063D495 + 2, (DWORD)&GL_Zoom);
	SetDword(0x007EF348 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0081B01F + 2, (DWORD)&GL_Zoom);
	SetDword(0x0081B04E + 2, (DWORD)&GL_Zoom);
	SetDword(0x0081B071 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0081B0D8 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0081B104 + 2, (DWORD)&GL_Zoom);
	SetDword(0x0082AC89 + 2, (DWORD)&GL_Zoom);
	//-- multiplicador
	//SetCompleteHook(0xE9, 0x004D8514, &CreatefCameraDistanceFar3D); //-- cargar dis camera
	SetCompleteHook(0xE9, 0x004D1CF0, &DumpExceptionFilter);
	SetDword(0x0042025E + 2, (DWORD)&this->fScreen_Width); //-- crear bitmap text
	SetDword(0x0042053D + 2, (DWORD)&this->fScreen_Width); //-- write bitmap text
	SetDword(0x0082B1E5 + 2, (DWORD)&this->fScreen_Width); //-- MiniMap
	SetDword(0x0082B2B6 + 2, (DWORD)&this->fScreen_Width); //-- MiniMap
	SetDword(0x0082B3A2 + 2, (DWORD)&this->fScreen_Width); //-- MiniMap
	SetDword(0x008B4FAB + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x008B50CB + 2, (DWORD)&this->fScreen_Width);
	//-- divisores
	SetDword(0x004D146C + 2, (DWORD)&this->fScreen_Width); //-- CreateFrustrum
	SetDword(0x004D7197 + 2, (DWORD)&this->fScreen_Width); //-- CreateFrustrum
	SetDword(0x004D7A2F + 2, (DWORD)&this->fScreen_Width); //-- CreateFrustrum
	SetDword(0x004D990D + 2, (DWORD)&this->fScreen_Width);
	//--
	SetDword(0x005DB1BB + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB240 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB333 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB3B8 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB47E + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB4BE + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB4E6 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB545 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB5D5 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB639 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x005DB69D + 2, (DWORD)&this->fScreen_Width);
	//--
	SetDword(0x00596B89 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x006387B7 + 2, (DWORD)&this->fScreen_Width); //-- MiniMap
	SetDword(0x00779A7A + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x00779C57 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x0077A646 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x00787A5E + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x007918B0 + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x0082B93E + 2, (DWORD)&this->fScreen_Width);
	SetDword(0x0088E31E + 2, (DWORD)&this->fScreen_Width);
	//-- multiplicador
	SetDword(0x00420275 + 2, (DWORD)&this->fScreen_High); //-- crear bitmap text
	SetDword(0x00420551 + 2, (DWORD)&this->fScreen_High); //-- write bitmap text
	SetDword(0x007C0563 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0080F903 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0082B38F + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x0082B31E + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x0082B0DB + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x008B4FBD + 2, (DWORD)&this->fScreen_High);
	SetDword(0x008B50DD + 2, (DWORD)&this->fScreen_High);
	//-- divisores heigh
	SetDword(0x004D1494 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x00596B95 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x006387F0 + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x00638828 + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x006388BC + 2, (DWORD)&this->fScreen_High); //-- MiniMap
	SetDword(0x00779AA0 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x00779C7D + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0077A66C + 2, (DWORD)&this->fScreen_High);
	SetDword(0x00787A93 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x007918D6 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0082B963 + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0088E34E + 2, (DWORD)&this->fScreen_High);
	SetDword(0x0082ABF2 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x00824019 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x005B97C2 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x005B9832 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x005B98EA + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008C2DF5 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008C2E65 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008CC6F9 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008CC76E + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008D999E + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008D9A13 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008EF461 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008EF4D3 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008EF5AB + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x008EF640 + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x00914FAF + 2, (DWORD)&this->fScreen_fWidth);
	SetDword(0x00915024 + 2, (DWORD)&this->fScreen_fWidth);
	//--
	SetCompleteHook(0xE8, 0x0086F25C, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0086F298, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0086F2D4, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088D9F3, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DA2F, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DA79, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DABD, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DB41, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DB74, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DBA7, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x0088DBDA, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x008DBF89, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x008DBFCA, &M34CryWolf1stNumber2D); //-- RenderNumber2D
	SetCompleteHook(0xE8, 0x008DC00A, &M34CryWolf1stNumber2D); //-- RenderNumber2D

	SetCompleteHook(0xE8, 0x007BF4E8, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BF54F, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFDDF, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFD44, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFD8D, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFC87, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFCCA, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C0094, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFFC1, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C0029, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFED2, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFF2E, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C02C0, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C0225, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C026E, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C0168, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007C01AB, &DuelWatchMainFrame1); //-- ok
	SetCompleteHook(0xE8, 0x007BFBB3, &DuelWatchMainFrame2); //-- ok
	SetCompleteHook(0xE8, 0x007BFA42, &DuelWatchMainFrame2); //-- ok
	SetCompleteHook(0xE8, 0x007BFAFE, &DuelWatchMainFrame2); //-- ok
	SetCompleteHook(0xE8, 0x007BF8C4, &DuelWatchMainFrame2); //-- ok
	SetCompleteHook(0xE8, 0x007BF968, &DuelWatchMainFrame2); //-- ok
	SetCompleteHook(0xE8, 0x007BF3E3, &DuelWatchMainFrameRender); //-- ok
	//--
	SetCompleteHook(0xE9, 0x00636420, &CGFxFrame::Convertx);
	SetCompleteHook(0xE9, 0x00636450, &CGFxFrame::Converty);
	SetCompleteHook(0xE8, 0x00857746, &CGFxFrame::CheckBaulExt); //-- baul check
	SetCompleteHook(0xE8, 0x004D2180, &CGFxFrame::CreateWindows);
	SetCompleteHook(0xE8, 0x004E7690, &CGFxFrame::BaseMatch_SetPosition); //-- pop up bc
	SetCompleteHook(0xE8, 0x004E775E, &CGFxFrame::BaseMatch_SetPosition); //-- pop up dc

	//-- Master Skill
	SetCompleteHook(0xE8, 0x0081A146, &MasterSkill_Render);				//-- Letter Print
	SetCompleteHook(0xE8, 0x0081A199, &MasterSkill_Render);				//-- Letter Print
	SetCompleteHook(0xE8, 0x00819415, &MasterSkill_SetInfo);			//-- Letter Print
	SetCompleteHook(0xE8, 0x0081AA9C, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081AA42, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081A9E8, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081A977, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081A944, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081A73D, &CGFxFrame::TreeType1);			//-- Texto masterskill
	SetCompleteHook(0xE8, 0x0081A6F4, &CGFxFrame::TreeType1);			//-- Texto masterskill
	//-- CashShop
	SetCompleteHook(0xE8, 0x00943D7F, &CashShop_RenderItem3D);			//-- ItemModel CashShop
	SetCompleteHook(0xE8, 0x008240A9, &CashShop_RenderColor);			//-- Letter Print
	SetCompleteHook(0xE8, 0x00945114, &CashShop_RenderBanner);			//-- Model CashShop
	SetCompleteHook(0xE8, 0x00945180, &CashShop_CheckInMouse);			//-- Model CashShop
	SetCompleteHook(0xE8, 0x0085C446, &CGFxFrame::CashShop_Init);		//-- Letter Print
	SetCompleteHook(0xE8, 0x009448C2, &CGFxFrame::CashShop_ButtonBuy);	//-- Letter Print
	SetCompleteHook(0xE8, 0x0081944B, &CGFxFrame::CashShop_ButtonBuy);	//-- Boton close master skill
	//-- fix extra
	SetCompleteHook(0xE8, 0x007C57B9, &CGFxFrame::ButtonGens);			//-- Boton Gens
	SetCompleteHook(0xE8, 0x004D7C0D, &CGFxFrame::SceneMuLogo);			//-- Logo SelectServer
	SetCompleteHook(0xE8, 0x004D7C98, &CGFxFrame::SceneMuLogo);			//-- Logo SelectServer
	//-- Check Open Windows 3
	SetCompleteHook(0xE8, 0x007D5E92, &CGFxFrame::Shop_OpenFrame);		//-- Shop
	SetCompleteHook(0xE8, 0x007D60B0, &CGFxFrame::Baul_OpenFrame);		//-- Baul
	SetCompleteHook(0xE8, 0x007D5DF4, &CGFxFrame::Chaos_OpenFrame);		//-- Chaos
	SetCompleteHook(0xE8, 0x007D5D56, &CGFxFrame::Store_OpenFrame);		//-- Store
	SetCompleteHook(0xE8, 0x007D6150, &CGFxFrame::Trade_OpenFrame);		//-- Trade
	SetCompleteHook(0xE8, 0x007D5FCE, &CGFxFrame::Lucky_OpenFrame);		//-- Lucky
	SetCompleteHook(0xE8, 0x007D6060, &CGFxFrame::InvExt_OpenFrame);	//-- Ext
	SetCompleteHook(0xE8, 0x00856486, &CGFxFrame::BaultExt_OpenFrame);	//-- BaultExt
	SetCompleteHook(0xE8, 0x0085F1B9, &CGFxFrame::BaultExt_OpenFrame);	//-- BaultExt
	SetCompleteHook(0xE8, 0x007D5F30, &CGFxFrame::OtherStore_OpenFrame);//-- OtherStore
	//--
	SetCompleteHook(0xE8, 0x007D5EE0, &CGFxFrame::ViewPort_SetInfo);	//-- Shop
	SetCompleteHook(0xE8, 0x007D5E42, &CGFxFrame::ViewPort_SetInfo);	//-- Chaos
	SetCompleteHook(0xE8, 0x007D5DA4, &CGFxFrame::ViewPort_SetInfo);	//-- Store
	SetCompleteHook(0xE8, 0x007D61EF, &CGFxFrame::ViewPort_SetInfo);	//-- Trade
	SetCompleteHook(0xE8, 0x007D6100, &CGFxFrame::ViewPort_SetInfo);	//-- Baul
	SetCompleteHook(0xE8, 0x007D601C, &CGFxFrame::ViewPort_SetInfo);	//-- Lucky
	SetCompleteHook(0xE8, 0x007D619E, &CGFxFrame::ViewPort_SetInfo);	//-- Trade
	SetCompleteHook(0xE8, 0x007D5F7E, &CGFxFrame::ViewPort_SetInfo);	//-- OtherStore
	//--
	SetCompleteHook(0xE8, 0x007F3F87, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x007F4A63, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x0085F90C, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x008605BF, &CGFxFrame::GetScreenWidth);
	//-- Paint ViewPort Player
	SetCompleteHook(0xE8, 0x0040F2E9, &CGFxFrame::FrameBeginOpengl); //-- render shop store
	SetCompleteHook(0xE8, 0x004D714E, &CGFxFrame::FrameBeginOpengl);
	SetCompleteHook(0xE8, 0x004D79E7, &CGFxFrame::FrameBeginOpengl);
	SetCompleteHook(0xE8, 0x004D9756, &CGFxFrame::FrameBeginOpengl);
	//-- Pain Frustrum
	SetCompleteHook(0xE8, 0x005DB1AA, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB22F, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB322, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB3A7, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB46D, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB4AD, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB4D5, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB534, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB5C4, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB628, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB68C, &CGFxFrame::GetScreenWidth);
	SetCompleteHook(0xE8, 0x005DB6ED, &CGFxFrame::GetScreenWidth);
	//--
	SetCompleteHook(0xE8, 0x00791BD0, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x00791C40, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x00792E80, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x00792F30, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A0C58, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A229F, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A3534, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A47CC, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A557C, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A703E, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A8227, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A8ED1, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A9331, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A9A11, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007A9EC7, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007AAB57, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007AB8EF, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007AC60F, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007AD597, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007ADDF7, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007AE642, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B26C2, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B2FF2, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B3AA2, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B4632, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B5332, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B5D22, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B670E, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B74C7, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x007B85C2, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x00947A52, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x00948814, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094A2B4, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094B4AF, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094BDD5, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094C8A4, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094DA92, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094F0F2, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0094FE84, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x0095093C, &CGFxFrame::CreateMessageBox);
	SetCompleteHook(0xE8, 0x009515B9, &CGFxFrame::CreateMessageBox);
}