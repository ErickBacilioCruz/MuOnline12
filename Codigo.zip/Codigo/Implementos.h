#pragma once


class ImplementosS6
{
public:
	ImplementosS6();
	virtual ~ImplementosS6();

	void InitImplementos();

};


extern ImplementosS6 gImplementos;