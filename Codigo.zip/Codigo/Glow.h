extern void InitScreenGlow(void);
extern void RenderScreenGlow(void);

extern bool g_bEnabled;