#pragma once
#define MAX_BUTTERFLES					10
#define MAX_BUFF_SLOT_INDEX				16
#define MAX_ID_SIZE						10
#define EQUIPMENT_LENGTH				17

typedef struct {
	BYTE         Header[4];
	BYTE         Value;
} PWHEADER_DEFAULT_WORD, * LPPWHEADER_DEFAULT_WORD;

//receive other map character
typedef struct {
	BYTE         KeyH;
	BYTE         KeyL;
	BYTE         PositionX;
	BYTE         PositionY;
	BYTE         Class;
	BYTE         Equipment[EQUIPMENT_LENGTH];
	BYTE         ID[MAX_ID_SIZE];
	BYTE         Target_X;
	BYTE         Target_Y;
	BYTE         Path;
	BYTE         PetItem1[2];
	BYTE         PetItem2[2];
	BYTE         Amulet[2];
	BYTE         s_BuffCount;
	BYTE         s_BuffEffectState[MAX_BUFF_SLOT_INDEX];
} PCREATE_CHARACTER, * LPPCREATE_CHARACTER;

typedef struct
{
	BYTE         KeyH;
	BYTE         KeyL;
	BYTE         PositionX;
	BYTE         PositionY;
	BYTE         TypeH;
	BYTE         TypeL;
	BYTE         ID[MAX_ID_SIZE];
	BYTE         Target_X;
	BYTE         Target_Y;
	BYTE         Path;
	BYTE         Class;
	BYTE         Equipment[EQUIPMENT_LENGTH];
	BYTE         PetItem1[2];
	BYTE         PetItem2[2];
	BYTE         Amulet[2];
	BYTE         s_BuffCount;
	BYTE		 s_BuffEffectState[MAX_BUFF_SLOT_INDEX];
} PCREATE_TRANSFORM, * LPPCREATE_TRANSFORM;

typedef struct //-- Get Item Modify
{
	BYTE         Header[3];
	BYTE         SubCode;
	BYTE         Index;
	BYTE         Item[MAX_ITEM_INFO];
	BYTE         ID[MAX_ID_SIZE];
} PHEADER_SUBCODE_ITEM, * LPPHEADER_SUBCODE_ITEM;

#define AssignChat						((void (__cdecl*)(char *ID,const char* Text,int Flag)) 0x005999F0)
#define StrCopy							((void*(__thiscall*)(void *thisa, void *a4))0x00409AF0)
#define CreateBugSub					((bool(__cdecl*)(int Type, int Position, int Owner, int o, int SubType, int LinkBone)) 0x005013B0)
#define CReceiveEquipmentItem			((BOOL (__cdecl*)(BYTE *ReceiveBuffer, BOOL bEncrypted)) 0x0064B860)
#define CreatePlayerViewport			((void(__cdecl*)(BYTE *ReceiveBuffer, int size)) 0x00641A50)
#define CreateTransformViewport			((void(__cdecl*)(BYTE *ReceiveBuffer)) 0x00642130)
#define	RenderHPUI						((int(__stdcall*)(int PosX, int PosY, char * name, int currentLife, int MaxLife, bool a6)) 0x007DFA60)

void DelectMuunBug(int Owner);
void DelectFlyBug(int Owner);
void CreateMuunBug(int Type, int Position, int Owner, int SubType, int LinkBone);
void CreateFlyBug(int Type, int Position, int Owner, int SubType, int LinkBone);

class CNewUIPetInfoWindow
{
public:
	CNewUIPetInfoWindow();
	virtual ~CNewUIPetInfoWindow();

	void Init();
	static void __thiscall RenderLeft(int thisa);
	static bool __thiscall TMessageText(int thisa, int strID, int strText, DWORD MsgType);
};

extern CNewUIPetInfoWindow g_pNewUIPetInfo;