#pragma once

void InitResolution();
void ResolutionSwitch();
void ResolutionSwitchFont();
void ResolutionMoveList();
