#pragma once 

void InitReduceCPU();