#include "stdafx.h"
#include "PetTooltip.h"

cPetTooltip gTooltip;


void InitLoad()
{
}