#include "StdAfx.h"
#include "Util.h"
#include "SEASON3B.h"
#include "CustomPet.h"
#include "CSPetSystem.h"

CSPetSystem g_PetSystem;

CSPetSystem::CSPetSystem(void)
{
}

CSPetSystem::~CSPetSystem(void)
{
}

void CSPetSystem::CreatePetPointer(int This, int Type, unsigned char PositionX, unsigned char PositionY, float Rotation)
{
	SPetSystem_Create(This, Type, PositionX, PositionY, Rotation);

	int itemType = Type - 1171;

	CUSTOM_PET_INFO* PetInfo = gCustomPet2.GetPickItem(itemType);

	if (PetInfo)
	{
		int o = This + 788;
		*(float*)(o + 96) = PetInfo->Scale_View;
	}
}

void CSPetSystem::Init()
{
	SetCompleteHook(0xE9, 0x004F921D, 0x004F9238); //-- Set PET_CMD_DEFAULT
	SetCompleteHook(0xE9, 0x0063F040, 0x0063F058); //-- Set PET_CMD_DEFAULT
	SetCompleteHook(0xE8, 0x004F131E, &CSPetSystem::CreatePetPointer);
}