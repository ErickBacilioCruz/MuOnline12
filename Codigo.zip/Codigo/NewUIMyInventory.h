#pragma once
#include "_struct.h"
#include "NewUISystem.h"
#include "CharacterMachine.h"

#define MyInventory_SetEquipmentSlotInfo		((void(__thiscall*)(UIMyInventory* thisa))0x00836510)
#define MyInventory_RenderFrame					((void(__thiscall*)(UIMyInventory* thisa))0x00836EC0)
#define MyInventory_RenderEquippedItem			((void(__thiscall*)(UIMyInventory* thisa)) 0x00837000)
#define MyInventory_RenderItemToolTip			((void(__thiscall*)(int* thisa, int SlotIndex)) 0x0083B860)
#define MyInventory_GetSquarePosAtPt			((int(__thiscall*)(void* thisa, int x, int y, int *tip)) 0x0083C7B0)
#define MyInventory_FindManaItemIndex			((int(__thiscall*)(void* thisa)) 0x0083C000)


#define MyInventory_Update						((bool(__thiscall*)(void *thisa)) 0x007DB160)
#define MyInventory_EquipmentWindowProcess		((bool(__thiscall*)(UIMyInventory* thisa)) 0x00837A30)
#define calcMaxDurability						((WORD(__cdecl*)(int ip, ITEM_ATTRIBUTE *p, int Level)) 0x005C2170)
#define RenderRepairInfo						((void(__cdecl*)(int sz, int sy, int ip, bool Sell)) 0x005C3D70)
#define g_pNewItemMng_DeleteItem				((void(__thiscall*)(int thisa, ITEM* ip)) 0x007E1ED0)
#define RenderItemInfo_							((void(__thiscall*)(int thisa, int sx,int sy,int ip,bool Sell, int Inventype, bool bItemTextListBoxUse)) 0x007E3E30)
#define CreatePetDarkSpirit						((void(__cdecl*)(int c)) 0x004F8C30)
#define PetManager_GetPetInfo					((int*(__cdecl*)(int item)) 0x004F9930)
#define PetSystem_SetPetInfo					((void(__thiscall*)(int Class, int* Pet)) 0x004FA780)

#define LuckyItemWnd_Check_LuckyItem_InWnd		((bool(__thiscall*)(int This)) 0x007EFC20)
#define LuckyItemWnd_Check_LuckyItem			((bool(__thiscall*)(int This, int _pItem)) 0x007EFC50)
#define LuckyItemWnd_SetWndAction				((int(__thiscall*)(int This, int _eType)) 0x007EEC60)
#define Check_LuckyItem_InWnd					((bool(__thiscall*)(int This)) 0x007EFC20)
#define Get_NewUILuckyItemWnd					((int(__thiscall*)(int This)) 0x00861A40)
#define FindBaseIndexByITEM						((int(__thiscall*)(void* This, int citem)) 0x007DAB80)


class CNewUIMyInventory
{
public:
	CNewUIMyInventory();
	virtual ~CNewUIMyInventory();
	void Init();
	//--
	static bool __thiscall Update(DWORD* a1);
	static void __thiscall SetButtonInfo(DWORD* thisa);
	//-- Protocolo
	void ReceiveInventory(BYTE* ReceiveBuffer);
	void ReceiveDropItem(BYTE* ReceiveBuffer);
	void ReceiveDurability(BYTE* ReceiveBuffer);
	void ReceiveItemChange(BYTE* ReceiveBuffer);
	void ReceiveDeleteInventory(BYTE* ReceiveBuffer);

	static bool __thiscall NewUIManager_Render(int thls);
	//--
	static void LoadImages();
	static void Backup_PickedItem();
	static bool __thiscall InventoryProcess(int thisa);
	static void __thiscall Render3D(signed int* thisa);
	static void __thiscall RenderFrame(UIMyInventory* thisa);
	static void __thiscall RenderEquippedItem(UIMyInventory* thisa);
	static void __thiscall SetEquipmentSlotInfo(UIMyInventory* thisa);
	static void __thiscall RenderItemToolTip(int thisa, int iSlotIndex);
	static bool __thiscall EquipmentWindowProcess(UIMyInventory* thisa);
	static void __thiscall InventoryCtrl_SetPos(int thisa, int x, int y);
	static void RenderEquipped(GLuint uiImageType, float x, float y, float width, float height);
	static void __thiscall InventoryCtrl_Create(char* thisa, char* pNew3DRenderMng, char* pNewItemMng, char* pOwner, int x, int y, int nColumn, int nRow);
	static void __thiscall RenderDetailsText(int thisa, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize);
};

extern CCharacterMachine* Character_Machin;
extern CNewUIMyInventory g_pMyInventory;