#define sub_587950			((signed int(__cdecl*)(int ViewPortId)) 0x00587950)
//----- (0054EA00) --------------------------------------------------------
#define sub_54EA00			((signed int(__thiscall*)(int ViewPortId)) 0x0054EA00)
#define sub_899CA0			((char(__cdecl*)(int a5, int a6)) 0x00899CA0)
#define sub_897DC0			((int(__stdcall*)()) 0x00897DC0)
#define sub_89E2C0			((bool(__stdcall*)(int a1, int a2)) 0x0089E2C0)

#define sub_8A28A0			((char(__cdecl*)(int a1, int a2)) 0x008A28A0)

#define sub_8A82B0			((bool(__cdecl*)(int a1, int a2)) 0x008A82B0)

#define sub_8B43C0			((bool(__cdecl*)(int a1, int a2)) 0x008B43C0)
#define sub_8CAE70			((bool(__cdecl*)(int a1, int a2)) 0x008CAE70)
#define sub_8CF620			((char(__cdecl*)(int a1, int a2)) 0x008CF620)
#define sub_8DC0E0			((bool(__cdecl*)(int a1, int a2)) 0x008DC0E0)
#define sub_90B970			((char(__cdecl*)(int a1, int a2)) 0x0090B970)

#define sub_901B00			((char(__cdecl*)(int a1, int a2)) 0x00901B00)

#define sub_91C9D0			((void *(__cdecl*)()) 0x0091C9D0)
#define sub_91CD60			((bool(__stdcall*)(int a1, int a2)) 0x0091CD60)
#define sub_9141D0			((char(__cdecl*)(int a1, int a2)) 0x009141D0)
#define sub_91ACC0			((char(__cdecl*)(int a1, int a2)) 0x0091ACC0)
#define pSkillRenderEffect				((void(__cdecl*)(int a1, int a2, int a3, float * a4, int a5, int a6, __int16 a7, __int16 a8, __int16 a9, __int16 a10, float a11, __int16 a12)) 0x6D9070)
#define pActionPlayerSend			((char(__cdecl*)(int ViewPortId,int ActionId,bool Some)) 0x00542310)
//----- (005509C0) -------------------------------------------------------
#define sub_5509C0			((int(__cdecl*)()) 0x005509C0)

#define sub_51A220			((int(__thiscall*)(int This, int a2)) 0x0051A220)
#define sub_542050			((__int16(__cdecl*)(int This, int a2)) 0x00542050)
#define sub_541CF0			((__int16(__cdecl*)(int This, int a2)) 0x00541CF0)


int PlayerAnimationOneHit(int a1);
__int16 PlayerAnimationMonturaSkill (int a3);

void initmontura();