// CustomItem.h: interface for the CCustomItem class.
//
//////////////////////////////////////////////////////////////////////

#pragma once
#include <map>

#define MAX_ACESSORY_ITEM 100

struct CUSTOM_ACCESSORY_INFO
{
	int Index;
	int ItemIndex;
	int Type;
	int ColorR;
	int ColorG;
	int ColorB;
	char ModelName[32];
};

void InitAccessoryItem();

class CCustomAccess
{
public:
	CCustomAccess();
	virtual ~CCustomAccess();
	void Init();
	void Load(CUSTOM_ACCESSORY_INFO* info);
	bool CheckItemTypeRing(int ItemIndex);
	bool CheckItemTypePendant(int ItemIndex);
	bool CheckItem(int ItemIndex);
	bool GetItemColor(int ItemIndex, float* ItemColor);
public:
	std::map<int, CUSTOM_ACCESSORY_INFO> m_CustomAccessInfo;
};

extern CCustomAccess gCustomAccess;
