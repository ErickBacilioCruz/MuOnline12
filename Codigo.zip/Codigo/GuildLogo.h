#pragma once

void InitGuildIcon();
void DrawLogo(int x, int y, DWORD a3);