#define sub_535C90 ((char(__thiscall*)(int a1)) 0x00535C90)
#define sub_536030 ((char(__thiscall*)(int a1)) 0x00536030)
#define sub_535CD0 ((void(__thiscall*)(int a5, int a6, int a7, int a8)) 0x00535CD0)
#define sub_535990 ((void(__thiscall*)(int a4,int a5, int a6, int a7)) 0x00535990)

void InitBookLoad();