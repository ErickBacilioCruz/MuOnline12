#include "StdAfx.h"
#include "Util.h"
#include "SEASON3B.h"
#include "UIControl.h"
#include "SItemOption.h"
#include "Pet.h"
#include "CustomPet.h"
#include "Protocol.h"
#include "NewUISystem.h"
#include "GIPetManager.h"
#include "NewUIMyInventory.h"
#include "NewUIPetInfoWindow.h"
#include "CChatEx.h"

CNewUIPetInfoWindow g_pNewUIPetInfo;
BYTE ButterMuun[648 * MAX_BUTTERFLES];
BYTE ButterFly[648 * MAX_BUTTERFLES];
int ItemStreem = NULL;

CNewUIPetInfoWindow::CNewUIPetInfoWindow(void)
{
}

CNewUIPetInfoWindow::~CNewUIPetInfoWindow(void)
{
}

void CreateMuunBug(int Type, int Position, int Owner, int SubType, int LinkBone)
{
	if (InChaosCastle(World1) != true && (*(DWORD*)(Owner + 48) == MODEL_PLAYER || Type == MODEL_HELPER))
	{
		for (int i = 0; i < MAX_BUTTERFLES; i++)
		{
			if (CreateBugSub(Type, Position, Owner, (int)&ButterMuun[648 * i], SubType, LinkBone) == FALSE) return;
		}
	}
}

void CreateFlyBug(int Type, int Position, int Owner, int SubType, int LinkBone)
{
	if (InChaosCastle(World1) != true && (*(DWORD*)(Owner + 48) == MODEL_PLAYER || Type == MODEL_HELPER))
	{
		for (int i = 0; i < MAX_BUTTERFLES; i++)
		{
			if (CreateBugSub(Type, Position, Owner, (int)&ButterFly[648 * i], SubType, LinkBone) == FALSE) return;
		}
	}
}





void DelectMuunBug(int Owner)
{
	BYTE* o;
	for (int i = 0; i < MAX_BUTTERFLES; ++i)
	{
		o = &ButterMuun[648 * i];
		if (ButterMuun[648 * i + 4])
		{
			if (*((DWORD*)o + 118) == Owner) { o[4] = false; }
		}
	}
}

void DelectFlyBug(int Owner)
{
	BYTE* o;
	for (int i = 0; i < MAX_BUTTERFLES; ++i)
	{
		o = &ButterFly[648 * i];
		if (ButterFly[648 * i + 4])
		{
			if (*((DWORD*)o + 118) == Owner) { o[4] = false; }
		}
	}
}

void RenderMuunBugs()
{
	for (int i = 0; i < MAX_BUTTERFLES; i++)
	{
		if (RenderPetScale((int)&ButterFly[648 * i], false) == FALSE) { break; }
	}
	for (int i = 0; i < MAX_BUTTERFLES; i++)
	{
		if (RenderPetScale((int)&ButterMuun[648 * i], false) == FALSE) { break; }
	}

	((void(__cdecl*)()) 0x00503950)();
}

void MoveMuunBugs()
{
	for (int i = 0; i < MAX_BUTTERFLES; i++)
	{
		if (gCustomPet.PetsMovement((int)&ButterFly[648 * i], false) == FALSE) { break; }
	}
	for (int i = 0; i < MAX_BUTTERFLES; i++)
	{
		if (gCustomPet.PetsMovement((int)&ButterMuun[648 * i], false) == FALSE) { break; }
	}
	((void(__cdecl*)()) 0x00503720)();
}

void CreateEquipMuun(WORD Type, OBJECT* o, CHARACTER c)
{
	if (Type == 0xFFFF)
	{
		DelectMuunBug((int)o);
	}
	else
	{
		int Helper_Type = MODEL_ITEM + Type;

		if (gCustomPet2.GetInfoPetType(Type) == 10)
		{
			giPetManager::Create_PetDarkSpirit((int)c, Helper_Type);
		}
		else
		{
			CreateMuunBug(Helper_Type, (int)&o->Position, (int)o, 0, 0);
		}
	}
}

void CreateEquipFly(WORD Type, OBJECT* o, CHARACTER c)
{
	if (Type == 0xFFFF)
	{
		DelectFlyBug((int)o);
	}
	else
	{
		DelectFlyBug((int)o);
		int Helper_Type = MODEL_ITEM + Type;
		CreateFlyBug(Helper_Type, (int)&o->Position, (int)o, 0, 0);
	}
}

void ClearCharacters_DelectBug(int Key)
{
	for (int i = 0; i < 400; i++)
	{
		int c = CharactersClient(CList(), i);
		OBJECT* o = (OBJECT*)(c + 776);

		if (o->Live && *(WORD*)(c + 126) != Key)
		{
			DelectMuunBug((int)o);
			DelectFlyBug((int)o);
		}
	}
	((void(__cdecl*)(int)) 0x0057D620)(Key);
}

void DeleteCharacter_DelectBug(int Key)
{
	for (int i = 0; i < 400; i++)
	{
		int c = CharactersClient(CList(), i);
		OBJECT* o = (OBJECT*)(c + 776);

		if (o->Live && *(WORD*)(c + 126) == Key)
		{
			DelectMuunBug((int)o);
			DelectFlyBug((int)o);
		}
	}
	((void(__cdecl*)(int)) 0x0057D760)(Key);
}

void DeleteCharacter_DelectMuun(int c, int o)
{
	DelectMuunBug(o);
	DelectFlyBug(o);
	((void(__cdecl*)(int, int)) 0x0057D8B0)(c, o);
}

void Teleport_DelectBug(OBJECT* Owner)
{
	DelectMuunBug(Hero + 776);
	DelectFlyBug(Hero + 776);
	DeleteBug((int)Owner);
}

void insertTextChatList(char* strID, char* strText, int MsgType, int ip)
{
	BYTE str_ID[28];
	BYTE str_Text[28];

	CharToString(&str_ID, strID);
	CharToString(&str_Text, strText);

	ItemStreem = ip;
	ChatLog_AddText(GetUI_NewChatLogWindow(), str_ID, str_Text, MsgType, 0);
	ItemStreem = NULL;
}

void ShowItemPublisher(int thisa)
{
	int ip = *(int*)(thisa + 60);

	if (ip != NULL)
	{
		RenderItemInfo_(GetUI3D(GetInstance()), 150, 25, ip, false, 0, false);

		if (*(DWORD*)(thisa + 56) == 0x8)
		{
			g_pRenderText->SetFont(g_hFontBold);
		}
	}
}

__declspec(naked) void GetpvecMsgs()
{
	static DWORD addr = 0x00788FC9;

	_asm
	{
		mov     ecx, dword ptr ss : [ebp - 0x2C]
		push    ecx
		call[ShowItemPublisher]
			push    0xB4
				push    0x1E
				push    0x1E
				JMP[addr]
	}
}

bool CNewUIPetInfoWindow::TMessageText(int thisa, int strID, int strText, DWORD MsgType)
{
	if (MsgType < 10)
	{
		StrCopy((void*)thisa, (void*)strID);
		StrCopy((void*)(thisa + 28), (void*)strText);
		*(DWORD*)(thisa + 56) = MsgType;
		*(int*)(thisa + 60) = ItemStreem;
		return true;
	}
	return false;
}

BOOL ReceiveEquipmentItem(BYTE* ReceiveBuffer, BOOL bEncrypted)
{
	LPPHEADER_SUBCODE_ITEM Data = (LPPHEADER_SUBCODE_ITEM)ReceiveBuffer;

	if (Data->SubCode == 40)
	{
		EquipmentItem = false;
		Character_Machin->EquipItem(Data->Index, Data->Item);
		return TRUE;
	}
	else if (Data->SubCode == 50)
	{
		if (strcmp((char*)Data->ID, (char*)(Hero + 56)) == 0 && EquipmentItem)
		{
			EquipmentItem = false;
		}
		zITEM* ip = CreateItem(Data->Item);

		if (ip != NULL)
		{
			ITEM_ATTRIBUTE* p = ItemAttribute(ip->Type);

			char Text[100] = { '\0' };

			int Level = (ip->Level >> 3) & 15;

			char TextName[64];

			if (gCItemSetOption.GetSetItemName(TextName, ip->Type, ip->ExtOption))
			{
				strcat(TextName, p->Name);
			}
			else
			{
				strcpy(TextName, p->Name);
			}

			if ((ip->Option1 & 63) > 0)
			{
				if (Level == 0)
					sprintf_s(Text, "[SELL] %s %s", GlobalText(620), TextName);
				else
					sprintf_s(Text, "[SELL] %s %s +%d", GlobalText(620), TextName, Level);
			}
			else
			{
				if (Level == 0)
					sprintf_s(Text, "[SELL] %s", TextName);
				else
					sprintf_s(Text, "[SELL] %s +%d", TextName, Level);
			}

			char ID[MAX_ID_SIZE + 1];
			memset(ID, 0, MAX_ID_SIZE + 1);
			memcpy(ID, (char*)Data->ID, MAX_ID_SIZE);

			AssignChat(ID, Text, 0);
			insertTextChatList(ID, Text, 8, (int)ip);

			PlayBuffer(38, 0, 0);
		}
		return TRUE;
	}
	return CReceiveEquipmentItem(ReceiveBuffer, bEncrypted);
}

void ReceiveCreatePlayerViewport(BYTE* ReceiveBuffer, int size)
{
	CreatePlayerViewport(ReceiveBuffer, size);

	LPPWHEADER_DEFAULT_WORD Data = (LPPWHEADER_DEFAULT_WORD)ReceiveBuffer;
	int Offset = sizeof(PWHEADER_DEFAULT_WORD);

	for (int i = 0; i < Data->Value; i++)
	{
		LPPCREATE_CHARACTER Data2 = (LPPCREATE_CHARACTER)(ReceiveBuffer + Offset);
		WORD Key = ((WORD)(Data2->KeyH) << 8) + Data2->KeyL;
		Key &= 0x7FFF;

		int iIndex = FindCharacterIndex(Key);
		CHARACTER c = (CHARACTER)CharactersClient(CList(), iIndex);
		//--
		if (c)
		{
			OBJECT* o = &c->Object;
			WORD Pet1 = MAKE_NUMBERW(Data2->PetItem1[0], Data2->PetItem1[1]);
			WORD Pet2 = MAKE_NUMBERW(Data2->PetItem2[0], Data2->PetItem2[1]);
			WORD Amulet = MAKE_NUMBERW(Data2->Amulet[0], Data2->Amulet[1]);

			if ((int)c == Hero)
			{
				DelectMuunBug(Hero + 776);
				DelectFlyBug(Hero + 776);
			}

			CreateEquipMuun(Pet1, o, c);
			CreateEquipFly(Pet2, o, c);

			if (Amulet != 0xFFFF)
			{
				*(WORD*)((int)c + 592) = Amulet + 1171;
			}
			else
			{
				*(WORD*)((int)c + 592) = 0xFFFF;
			}
		}
		Offset += (sizeof(PCREATE_CHARACTER) - (sizeof(BYTE) * (MAX_BUFF_SLOT_INDEX - Data2->s_BuffCount)));
	}
}

void ReceiveCreateTransformViewport(BYTE* ReceiveBuffer)
{
	CreateTransformViewport(ReceiveBuffer);
	LPPWHEADER_DEFAULT_WORD Data = (LPPWHEADER_DEFAULT_WORD)ReceiveBuffer;
	int Offset = sizeof(PWHEADER_DEFAULT_WORD);

	for (int i = 0; i < Data->Value; i++)
	{
		LPPCREATE_TRANSFORM Data2 = (LPPCREATE_TRANSFORM)(ReceiveBuffer + Offset);
		WORD Key = ((WORD)(Data2->KeyH) << 8) + Data2->KeyL;
		Key &= 0x7FFF;

		int iIndex = FindCharacterIndex(Key);
		CHARACTER c = (CHARACTER)CharactersClient(CList(), iIndex);


		if (c)
		{
			OBJECT* o = &c->Object;
			WORD Pet1 = MAKE_NUMBERW(Data2->PetItem1[0], Data2->PetItem1[1]);
			WORD Pet2 = MAKE_NUMBERW(Data2->PetItem2[0], Data2->PetItem2[1]);
			WORD Amulet = MAKE_NUMBERW(Data2->Amulet[0], Data2->Amulet[1]);

			if ((int)c == Hero)
			{
				DelectMuunBug(Hero + 776);
				DelectFlyBug(Hero + 776);
			}

			CreateEquipMuun(Pet1, o, c);
			CreateEquipFly(Pet2, o, c);

			if (Amulet != 0xFFFF)
			{
				*(WORD*)((int)c + 592) = Amulet + 1171;
			}
			else
			{
				*(WORD*)((int)c + 592) = 0xFFFF;
			}
		}
		Offset += (sizeof(PCREATE_TRANSFORM) - (sizeof(BYTE) * (MAX_BUFF_SLOT_INDEX - Data2->s_BuffCount)));
	}
}

bool PetEquipedHPBar(int iX, int iY)
{
	WORD Helper_Type = *(WORD*)(Hero + 556);

	if (Helper_Type >= MODEL_HELPER && Helper_Type <= MODEL_HELPER + 4
		|| Helper_Type == MODEL_HELPER + 64
		|| Helper_Type == MODEL_HELPER + 65
		|| Helper_Type == MODEL_HELPER + 67
		|| Helper_Type == MODEL_HELPER + 80
		|| Helper_Type == MODEL_HELPER + 106
		|| Helper_Type == MODEL_HELPER + 123
		|| Helper_Type == MODEL_HELPER + 37
		|| (Helper_Type >= MODEL_HELPER + 200
			&& Helper_Type < MODEL_HELPER + 512))
	{
		char szText[256] = { NULL, };
		WORD Type = Helper_Type - 1171;
		ITEM_ATTRIBUTE* p = ItemAttribute(Type);


		switch (Helper_Type)
		{
		case MODEL_HELPER:
		{
			sprintf_s(szText, GlobalText(353));
		}break;
		case MODEL_HELPER + 1:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 2:
		{
			sprintf_s(szText, GlobalText(355));
		}break;
		case MODEL_HELPER + 3:
		{
			sprintf_s(szText, GlobalText(354));
		}break;
		case MODEL_HELPER + 4:
		{
			sprintf_s(szText, GlobalText(1187));
		}break;
		case MODEL_HELPER + 37:
		{
			sprintf_s(szText, GlobalText(1916));
		}break;
		case MODEL_HELPER + 64:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 65:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 67:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 80:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 106:
		{
			sprintf_s(szText, p->Name);
		}break;
		case MODEL_HELPER + 123:
		{
			sprintf_s(szText, p->Name);
		}break;
		default:
			sprintf_s(szText, p->Name);
			break;
		}

		int iLife = *(BYTE*)(Character_Machine + 5550);

		RenderHPUI(iX, iY, szText, iLife, 255, false);

		return true;
	}

	return false;
}

bool RenderEquipedMuunLife(int sx, int sy, int Slot)
{
	zITEM* IP = NULL;

	if (Slot == EQUIPMENT_PENTAGRAM1 || Slot == EQUIPMENT_PENTAGRAM2)
	{
		IP = &Character_Machin->Equipment[Slot];
	}

	if (IP != NULL && IP->Type != 0xFFFF)
	{
		char szText[256] = { NULL, };
		ITEM_ATTRIBUTE* p = ItemAttribute(IP->Type);

		sprintf_s(szText, p->Name);
		RenderHPUI(sx, sy, szText, IP->Durability, 255, false);
		return true;
	}

	return false;
}

void CNewUIPetInfoWindow::RenderLeft(int This)
{
	int iNextPosY = *(DWORD*)(This + 20) - 12;
	int StartPosX = CGetScreenWidth2() - ((PartyNumber > 0) ? 140 : 60);

	if (GetBaseClass(*(BYTE*)(Hero + 19)) == 2 && RenderNumArrow(This, StartPosX, iNextPosY))
		iNextPosY += (int)(FontHeight / g_fScreenRate_y);

	if (PetEquipedHPBar(StartPosX, iNextPosY))
		iNextPosY += 24;
	if (RenderEquipedMuunLife(StartPosX, iNextPosY, EQUIPMENT_PENTAGRAM1))
		iNextPosY += 24;
	if (RenderEquipedMuunLife(StartPosX, iNextPosY, EQUIPMENT_PENTAGRAM2))
		iNextPosY += 24;

	if (GetBaseClass(*(BYTE*)(Hero + 19)) == 4 && RenderEquipedPetLife(This, StartPosX, iNextPosY))
		iNextPosY += 24;

	if (GetBaseClass(*(BYTE*)(Hero + 19)) == 2 && RenderSummonMonsterLife(This, StartPosX, iNextPosY))
		iNextPosY += 24;
}

void ReceiveEquipment(int ReceiveBuffer)
{
	int Key;

	Key = FindCharacterIndex(*(BYTE*)(ReceiveBuffer + 5) + (*(BYTE*)(ReceiveBuffer + 4) << 8));
	int c = CharactersClient(CList(), Key);

	if (c != NULL)
	{
		DelectMuunBug(c + 776);
		DelectFlyBug(c + 776);
	}

	((void(__cdecl*)(int)) 0x00641140)(ReceiveBuffer);
}

void CNewUIPetInfoWindow::Init()
{
	//SetCompleteHook(0xE8, 0x00663F65, &ReceiveEquipment);
	//--
	SetCompleteHook(0xE8, 0x004D6EA5, &MoveMuunBugs);
	SetCompleteHook(0xE8, 0x004D7787, &MoveMuunBugs);
	SetCompleteHook(0xE8, 0x004D9568, &MoveMuunBugs);
	SetCompleteHook(0xE8, 0x004D7348, &RenderMuunBugs);
	SetCompleteHook(0xE8, 0x004D7A98, &RenderMuunBugs);
	SetCompleteHook(0xE8, 0x004D9A65, &RenderMuunBugs);
	SetCompleteHook(0xE8, 0x00641777, &Teleport_DelectBug);
	//--
	SetCompleteHook(0xE8, 0x005604CA, &DeleteCharacter_DelectMuun);
	SetCompleteHook(0xE8, 0x0056F5B3, &DeleteCharacter_DelectMuun);
	//--
	SetCompleteHook(0xE8, 0x004E17F3, &DeleteCharacter_DelectBug);
	SetCompleteHook(0xE8, 0x004F6E1F, &DeleteCharacter_DelectBug);
	SetCompleteHook(0xE8, 0x0063D4AC, &DeleteCharacter_DelectBug);
	SetCompleteHook(0xE8, 0x0063D626, &DeleteCharacter_DelectBug);
	SetCompleteHook(0xE8, 0x0064365B, &DeleteCharacter_DelectBug);
	//--
	SetCompleteHook(0xE8, 0x004D7955, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x004EF6A1, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x0062EAC3, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x006312D3, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x006316B4, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x00634659, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x0063EC49, &ClearCharacters_DelectBug);
	SetCompleteHook(0xE8, 0x00640BF5, &ClearCharacters_DelectBug);
	//--
	SetCompleteHook(0xE8, 0x0066424B, &ReceiveEquipmentItem);
	//-- ReceiveCreatePlayerViewport
	SetByte(0x00642098 + 3, sizeof(PCREATE_CHARACTER) - 16); //-- buffList
	SetByte(0x006420AB + 3, sizeof(PCREATE_CHARACTER) - 16); //-- buffList
	SetByte(0x00642083 + 3, sizeof(PCREATE_CHARACTER) - 17); //-- buffcount
	SetByte(0x006420DB + 3, sizeof(PCREATE_CHARACTER) - 17); //-- buffcount
	SetDword(0x006420E6 + 1, sizeof(PCREATE_CHARACTER)); //-- 70
	SetCompleteHook(0xE8, 0x0066419E, &ReceiveCreatePlayerViewport);
	//-- ReceiveCreateTransforViewport
	SetByte(0x006423CC + 3, sizeof(PCREATE_TRANSFORM) - 16); //-- buffList
	SetByte(0x006423B9 + 3, sizeof(PCREATE_TRANSFORM) - 16); //-- buffList
	SetByte(0x006423A4 + 3, sizeof(PCREATE_TRANSFORM) - 17); //-- buffcount
	SetByte(0x006425A3 + 3, sizeof(PCREATE_TRANSFORM) - 17); //-- buffcount
	SetDword(0x006425AE + 1, sizeof(PCREATE_TRANSFORM)); //-- 54
	SetCompleteHook(0xE8, 0x006641D1, &ReceiveCreateTransformViewport);
	//--
	SetCompleteHook(0xE9, 0x00788FC0, &GetpvecMsgs);
	SetCompleteHook(0xE9, 0x0078BFE0, &CNewUIPetInfoWindow::TMessageText);
	//--
	SetCompleteHook(0xE8, 0x007DF83E, &CNewUIPetInfoWindow::RenderLeft);
}