#pragma once
#define SetInfoCashShop							((BYTE(__thiscall*)(int This, int a5, int x, int y)) 0x00942E80)
#define SetInfoHelper							((void(__thiscall*)(int This, int a5, int x, int y)) 0x007F0C80)
#define SetInfoMaster							((void(__thiscall*)(int This)) 0x00819510)
#define SetInfoTrade							((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x00863F10)
#define SetInfoBaulExt							((void(__thiscall*)(int This, int PosX, int PosY)) 0x008564F0)
#define SetInfoBaul								((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x00857200)
#define SetInfoInvExt							((void(__thiscall*)(int This, int PosX, int PosY)) 0x007D4E70)
#define SetInfoLucky							((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x007F0460)
#define SetInfoOtherStore						((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x0084FA90)
#define SetInfoShop								((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x00846B90)
#define SetInfoChaos							((int (__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x0082C340)
#define SetInfoStore							((void(__thiscall*)(int This, int PosX, int PosY, int Ext)) 0x00840D80)
#define SetInfoviewControl						((void(__thiscall*)(int This, int PosX, int PosY)) 0x007DC240)
//--
#define CreatMessageBox							((bool(__thiscall*)(void *This, int sx, int sy, int cx, int cy, float Deeplayer)) 0x00823CA0)
#define sub_7D6270								((bool (__thiscall*)(int This, int Ext)) 0x007D6270)
#define sub_861A60								((int (__thiscall*)(int This)) 0x00861A60)
#define RenderImageA							((void(__cdecl*)(GLuint uiImageType, float x, float y, float width, float height, float su, float sv,float uw, float vh, DWORD color)) 0x00790DF0)
#define pRender_rendertext						((int(__thiscall*)(int This, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth , int iBoxHeight , int iSort, OUT SIZE * lpTextSize)) 0x00420150)
#define NewUIChangeButtonInfo					((void(__thiscall*)(BYTE *thisa, int x, int y, int sx, int sy)) 0x00779410)
#define NewUIChangeButtonImgState				((void(__thiscall*)(BYTE *thisa, bool imgregister, int imgindex, bool overflg, bool isimgwidth, bool bClickEffect)) 0x00779350)
#define NewUIUpdateMouseEvent					((bool(__thiscall*)(BYTE *thisa)) 0x00779860)
#define NewUIButtonChangeColor					((int(__thiscall*)(BYTE *thisa, DWORD Color)) 0x007C1C80)
#define NewUIButtonRender						((bool(__thiscall*)(BYTE *thisa, bool RendOption)) 0x007798F0)
#define NewUIButtonChangeImgColor				((void(__thiscall*)(BYTE *thisa,int eventstate, unsigned int color))0x00779740)
#define NewUIButtonSetFont						((void(__thiscall*)(BYTE *thisa, HFONT hFont))0x007909D0)
#define ChartoString							((void *(__thiscall*)(void *thisa, char *a4))0x00409A50)
#define NewUIButtonGetBTState					((int(__thiscall*)(BYTE * thisa))0x0077E610)
#define NewUIButtonChangeText					((void(__thiscall*)(BYTE *thisa, int a1, int a2, int a3, int a4, int a5, int a6, int a7))0x00790970)
#define NewUIButtonSetTooltip					((void(__thiscall*)(BYTE * thisa, int a1, int a2, int a3, int a4, int a5, int a6, int a7, bool a8))0x007853F0)
#define NewUIBase_Show							((void(__thiscall*)(int This, bool bShow)) 0x00777610)


class CGFxFrame
{
public:
	CGFxFrame(void);
	virtual ~CGFxFrame(void);
public:
	static CGFxFrame* Instance()
	{
		static CGFxFrame tc; return &tc;
	};

	void Init();
	void MainFrame();
	void M45Temple();
	void M34CryWolf();
	void InitWideScreen();
	//--
	static void CreateWindows();
	static int GetScreenWidth();
	static int FrameBeginOpengl();
	static float Convertx(float var_1);
	static float Converty(float var_1);
	static bool CheckBaulExt(int x, int y, int Width, int Height);
	//--
	static void __thiscall BaseMatch_SetPosition(int This, int ix, int iy);
	static BYTE __thiscall CashShop_Init(int thisa, int a2, int x, int y);
	static bool __thiscall CreateMessageBox(void* thisa, int sx, int sy, int cx, int cy, float Deeplayer);
	static void __thiscall ViewPort_SetInfo(int thisa, int cx, int cy);
	static void __thiscall InvExt_OpenFrame(int thisa, int cx, int cy);
	static void __thiscall Trade_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall BaultExt_OpenFrame(int thisa, int cx, int cy);
	static void __thiscall Baul_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall Lucky_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall OtherStore_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall Store_OpenFrame(int thisa, int cx, int cy, int Ext);
	static int  __thiscall Chaos_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall Shop_OpenFrame(int thisa, int cx, int cy, int Ext);
	static void __thiscall CashShop_ButtonBuy(BYTE* thisa, int X, int Y, int Width, int Height);
	static void __thiscall ButtonGens(BYTE* thisa, int X, int Y, int Width, int Height);
	static void SceneMuLogo(int Texture, float x, float y, float Width, float Height, float u, float v, float uWidth, float vHeight, bool Scale, bool StartScale, float Alpha);
	static int __thiscall TreeType1(int thisa, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize);
public:
	int fScreenWin;
	int fScreenHigh;
	float fScreen_fWidth;
	float fScreen_fHigh;
	double fScreen_Width;
	double fScreen_High;
};